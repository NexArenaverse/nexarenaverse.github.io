// Progressive enhancement: content is never hidden while waiting for JavaScript.
// No navigation interception, game-square animation, scroll loop or media request.
const root = document.documentElement;
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const KEY = 'na-motion-effects';
const STYLE_KEY = 'na-motion-style';
const entranceStyles = ['zoom','slide','prism','soft'];
function savedStyle() { try { const value = localStorage.getItem(STYLE_KEY); return entranceStyles.includes(value) ? value : 'zoom'; } catch { return 'zoom'; } }
let entranceStyle = savedStyle();
root.dataset.motionStyle = entranceStyle;
const heroes = '.world-cinematic-hero,.premium-hero,.market-hero,.hero,.sports-hub-hero,.sport-world-hero,.today-hero,.arcade-hero,.kids-hero,.edu-hero,.lobby-intro';
const cards = '.premium-product,.premium-new-card,.market-card,.sport-world-card,.sport-skill-card,.card,.lab-look';
const sections = '.premium-feature,.premium-data-banner,.premium-test-banner,.homepage-sports-feature,.market-panel,.lobby-options,.welcome-card,.academy-arcade-banner';
const candidates = `${heroes},${cards},${sections}`;
const excluded = '.board,.sq,.showcase-board,.studio-board,.lab-review-board,.tactics-court,.arcade-stage,.kids-visual,.edu-answers,dialog,#overlay,[hidden]';
const seen = new WeakSet(), animations = new Set(), pending = new Set();
let observer, scheduled = false, control, effectsButton, effectsDialog;
function saved() { try { return localStorage.getItem(KEY) !== 'off'; } catch { return true; } }
let desired = saved();
function enabled() { return desired && !reduced.matches && root.dataset.dataSaver !== 'on'; }
function applyPreference() {
 const on = enabled();
 root.dataset.motionEffects = on ? 'on' : 'off';
 if (!on) for (const animation of animations) animation.cancel();
 if (control) {
  control.setAttribute('aria-pressed', String(on));
  control.textContent = `Motion: ${on ? 'on' : 'off'}`;
  control.disabled = reduced.matches || root.dataset.dataSaver === 'on';
  control.title = reduced.matches ? 'Your device requests reduced motion.' : root.dataset.dataSaver === 'on' ? 'Decorative motion is off in Data Saver.' : 'Turn entrance animations and decorative effects on or off.';
 }
 updateEffectsPanel();
}
function mountControl() {
 if (control?.isConnected) return;
 const header = document.querySelector('header');
 if (!header) return;
 control = document.createElement('button');
 control.type = 'button'; control.className = 'na-motion-control';
 control.setAttribute('aria-label', 'Animation effects');
 control.addEventListener('click', () => {
  desired = !desired;
  try { localStorage.setItem(KEY, desired ? 'on' : 'off'); } catch {}
  applyPreference();
 });
 const controls = document.createElement('div'); controls.className = 'na-motion-controls';
 effectsButton = document.createElement('button'); effectsButton.type = 'button'; effectsButton.className = 'na-effects-open';
 effectsButton.textContent = 'Effects'; effectsButton.setAttribute('aria-label','Choose entrance effects');
 effectsButton.setAttribute('aria-haspopup','dialog'); effectsButton.setAttribute('aria-expanded','false');
 effectsButton.addEventListener('click', () => { mountEffectsPanel(); updateEffectsPanel(); effectsDialog.showModal(); effectsButton.setAttribute('aria-expanded','true'); });
 controls.append(control,effectsButton); header.append(controls); applyPreference();
}
function updateEffectsPanel() {
 if (!effectsDialog) return;
 for (const button of effectsDialog.querySelectorAll('[data-entrance-choice]')) button.setAttribute('aria-pressed', String(button.dataset.entranceChoice === entranceStyle));
 effectsDialog.querySelector('.na-effects-replay').disabled = !enabled() || !document.querySelector(heroes);
 effectsDialog.querySelector('.na-effects-note').textContent = reduced.matches ? 'Your device requests reduced motion. Your chosen style will be saved.' : root.dataset.dataSaver === 'on' ? 'Data Saver keeps motion off. Your chosen style will be saved.' : !desired ? 'Turn Motion on to replay an entrance. Your chosen style is saved.' : !document.querySelector(heroes) ? 'Open a world or return to a lobby to replay its entrance.' : 'Your choice is saved on this device. Replay it here or open another world.';
}
function mountEffectsPanel() {
 if (effectsDialog?.isConnected) return;
 effectsDialog = document.createElement('dialog'); effectsDialog.className = 'na-effects-panel';
 effectsDialog.setAttribute('aria-labelledby','na-effects-title');
 effectsDialog.innerHTML = `<div class="na-effects-heading"><div><p>MAKE AN ENTRANCE</p><h2 id="na-effects-title">Choose your signature.</h2></div><button class="na-effects-close" type="button" aria-label="Close entrance effects">×</button></div><p>Pick a style, then replay it here or open another world.</p><div class="na-effect-choices" role="group" aria-label="Entrance style">${[
  ['zoom','Zoom','Big camera push. Bold text.','Cinematic zoom entrance'],['slide','Slide','Fast movement. Clean landing.','Slide entrance'],['prism','Prism Wipe','A sharp reveal across the scene.','Prism wipe entrance'],['soft','Soft','A quieter, gentle arrival.','Soft entrance']
 ].map(([id,name,description,label])=>`<button type="button" data-entrance-choice="${id}" aria-label="${label}" aria-pressed="false"><span class="na-effect-preview" aria-hidden="true"></span><strong>${name}</strong><small>${description}</small></button>`).join('')}</div><button class="na-effects-replay" type="button">Replay entrance</button><p class="na-effects-note" role="status"></p>`;
 effectsDialog.querySelector('.na-effects-close').addEventListener('click',()=>effectsDialog.close());
 effectsDialog.addEventListener('close',()=>effectsButton?.setAttribute('aria-expanded','false'));
 for (const button of effectsDialog.querySelectorAll('[data-entrance-choice]')) button.addEventListener('click', () => {
  entranceStyle = button.dataset.entranceChoice; root.dataset.motionStyle = entranceStyle;
  try { localStorage.setItem(STYLE_KEY, entranceStyle); } catch {}
  updateEffectsPanel();
 });
 effectsDialog.querySelector('.na-effects-replay').addEventListener('click', () => {
  const hero = document.querySelector(heroes); if (!enabled() || !hero) return;
  effectsDialog.close();
  for (const animation of animations) animation.cancel();
  hero.classList.remove('na-scene-arrived');
  const rect = hero.getBoundingClientRect();
  if (rect.top < -80 || rect.top > innerHeight * .6) hero.scrollIntoView({block:'start',behavior:'instant'});
  requestAnimationFrame(() => requestAnimationFrame(() => enter(hero)));
 });
 document.body.append(effectsDialog);
}
function animate(el, keyframes, options) {
 if (!enabled() || typeof el.animate !== 'function') return;
 const animation = el.animate(keyframes, {duration: 600, easing: 'cubic-bezier(.2,.75,.2,1)', ...options});
 animations.add(animation);
 animation.finished.then(() => animations.delete(animation), () => animations.delete(animation));
}
function enter(el) {
 if (!enabled() || !el.isConnected || el.closest(excluded)) return;
 el.dataset.entrance = entranceStyle;
 if (el.matches(heroes)) {
  el.classList.add('na-scene-arrived');
  const copy = el.querySelector('.world-hero-copy,.premium-hero-copy') || el;
  const frames = entranceStyle === 'zoom' ? [{opacity:0,transform:'translateY(36px) scale(.78)',offset:0},{opacity:1,transform:'translateY(-3px) scale(1.025)',offset:.76},{opacity:1,transform:'none',offset:1}]
   : entranceStyle === 'slide' ? [{opacity:0,transform:'translateX(-100px) skewX(-3deg)'},{opacity:1,transform:'translateX(5px) skewX(0)',offset:.8},{opacity:1,transform:'none'}]
   : entranceStyle === 'prism' ? [{opacity:.2,clipPath:'polygon(0 0,0 0,0 100%,0 100%)',transform:'translateX(-24px)'},{opacity:1,clipPath:'polygon(0 0,100% 0,100% 100%,0 100%)',transform:'none'}]
   : [{opacity:.25,transform:'translateY(22px)'},{opacity:1,transform:'none'}];
  animate(copy, frames, {duration:entranceStyle === 'soft' ? 760 : 850});
  const art = el.querySelector('.world-hero-art,.premium-hero-art');
  // Animate only the photo, never a live chessboard or sports demonstration.
  if (art) animate(art, [{transform:entranceStyle === 'soft' ? 'scale(1.045)' : entranceStyle === 'slide' ? 'scale(1.12) translateX(28px)' : 'scale(1.22)'},{transform:'scale(1)'}], {duration:entranceStyle === 'soft' ? 1800 : 1200});
  const title = copy.querySelector('h1');
  if (title && copy !== el && entranceStyle !== 'soft') animate(title, [{opacity:0,transform:'translateY(22px) scale(1.09)'},{opacity:1,transform:'none'}],{duration:650,delay:90});
  const actions = copy.querySelector('.hero-actions');
  if (actions && entranceStyle !== 'soft') animate(actions,[{opacity:0,transform:'translateY(20px)'},{opacity:1,transform:'none'}],{duration:500,delay:230});
 } else {
  // Stagger siblings, with a strict cap so no section waits a long time.
  const siblings = [...(el.parentElement?.children || [])].filter(s => s.matches(candidates));
  const index = Math.max(siblings.indexOf(el),0), direction = index % 2 ? 1 : -1;
  const delay = Math.min(index,4) * 80;
  const frames = entranceStyle === 'zoom' ? [{opacity:0,transform:'translateY(32px) scale(.87)'},{opacity:1,transform:'translateY(-2px) scale(1.012)',offset:.8},{opacity:1,transform:'none'}]
   : entranceStyle === 'slide' ? [{opacity:0,transform:`translateX(${direction*55}px)`},{opacity:1,transform:'none'}]
   : entranceStyle === 'prism' ? [{opacity:.1,clipPath:'inset(0 100% 0 0)',transform:'translateY(18px)'},{opacity:1,clipPath:'inset(0 0 0 0)',transform:'none'}]
   : [{opacity:.3,transform:'translateY(20px)'},{opacity:1,transform:'none'}];
  animate(el,frames,{duration:650,delay});
 }
}
function prepare(el) {
 if (seen.has(el) || el.closest(excluded) || root.dataset.boot === 'loading') return;
 seen.add(el);
 if (el.matches(heroes) && !el.matches('.lobby-intro')) {
  el.classList.add('na-motion-scene');
  const art = document.createElement('div');
  art.className = 'na-motion-graphic'; art.setAttribute('aria-hidden', 'true');
  art.innerHTML = '<i></i><i></i><i></i><b class="na-motion-streak"></b><b class="na-motion-streak"></b>'; el.append(art);
 }
 if (observer) observer.observe(el); else enter(el);
}
function scan(node) {
 if (!(node instanceof Element) || node.closest(excluded)) return;
 if (node.matches(candidates)) prepare(node);
 for (const el of node.querySelectorAll(candidates)) prepare(el);
}
function flush() {
 scheduled = false; mountControl();
 for (const node of pending) if (node.isConnected) scan(node);
 pending.clear();
}
if ('IntersectionObserver' in window) observer = new IntersectionObserver(entries => {
 for (const entry of entries) if (entry.isIntersecting) { observer.unobserve(entry.target); enter(entry.target); }
}, {threshold: .08, rootMargin: '0px 0px -16px 0px'});
applyPreference(); mountControl(); scan(document.body);
new MutationObserver(records => {
 for (const record of records) for (const node of record.addedNodes) {
  if (!(node instanceof Element) || node.classList.contains('na-motion-graphic') || node.closest(excluded)) continue;
  // Ignore piece moves, clock text and other small game updates.
  if (node.matches(candidates) || node.querySelector(candidates)) pending.add(node);
 }
 if ((!control?.isConnected || pending.size) && !scheduled) { scheduled = true; requestAnimationFrame(flush); }
}).observe(document.body, {childList: true, subtree: true});
new MutationObserver(records => {
 if (records.some(r => r.attributeName === 'data-data-saver')) applyPreference();
 if (root.dataset.boot !== 'loading') { pending.add(document.body); if (!scheduled) { scheduled = true; requestAnimationFrame(flush); } }
}).observe(root, {attributes: true, attributeFilter: ['data-boot','data-data-saver']});
reduced.addEventListener('change', applyPreference);
addEventListener('storage', event => {
 if (event.key === KEY) { desired = saved(); applyPreference(); }
 if (event.key === STYLE_KEY) { entranceStyle = savedStyle(); root.dataset.motionStyle = entranceStyle; updateEffectsPanel(); }
});
document.addEventListener('visibilitychange', () => {
 root.dataset.pageHidden = String(document.hidden);
 for (const animation of animations) {
  if (document.hidden) animation.pause(); else if (enabled()) animation.play(); else animation.cancel();
 }
});
addEventListener('pagehide', () => { for (const animation of animations) animation.cancel(); });
