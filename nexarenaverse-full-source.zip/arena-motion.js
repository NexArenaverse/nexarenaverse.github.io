// Progressive enhancement: content is never hidden while waiting for JavaScript.
// No navigation interception, game-square animation, scroll loop or media request.
const root = document.documentElement;
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const KEY = 'na-motion-effects';
const heroes = '.world-cinematic-hero,.premium-hero,.market-hero,.hero,.sports-hub-hero,.sport-world-hero,.today-hero,.arcade-hero,.kids-hero,.edu-hero,.lobby-intro';
const cards = '.premium-product,.premium-new-card,.market-card,.sport-world-card,.sport-skill-card,.card,.lab-look';
const sections = '.premium-feature,.premium-data-banner,.premium-test-banner,.homepage-sports-feature,.market-panel,.lobby-options,.welcome-card,.academy-arcade-banner';
const candidates = `${heroes},${cards},${sections}`;
const excluded = '.board,.sq,.showcase-board,.studio-board,.lab-review-board,.tactics-court,.arcade-stage,.kids-visual,.edu-answers,dialog,#overlay,[hidden]';
const seen = new WeakSet(), animations = new Set(), pending = new Set();
let observer, scheduled = false, control;
function saved() { try { return localStorage.getItem(KEY) !== 'off'; } catch { return true; } }
let desired = saved();
function enabled() { return desired && !reduced.matches && root.dataset.dataSaver !== 'on'; }
function applyPreference() {
 const on = enabled();
 root.dataset.motionEffects = on ? 'on' : 'off';
 if (!on) for (const animation of animations) animation.cancel();
 if (control) {
  control.setAttribute('aria-pressed', String(on));
  control.textContent = `Motion: ${on ? 'on' : 'off'}`;
  control.disabled = reduced.matches || root.dataset.dataSaver === 'on';
  control.title = reduced.matches ? 'Your device requests reduced motion.' : root.dataset.dataSaver === 'on' ? 'Decorative motion is off in Data Saver.' : 'Turn entrance animations and decorative effects on or off.';
 }
}
function mountControl() {
 if (control?.isConnected) return;
 const header = document.querySelector('header');
 if (!header) return;
 control = document.createElement('button');
 control.type = 'button'; control.className = 'na-motion-control';
 control.setAttribute('aria-label', 'Animation effects');
 control.addEventListener('click', () => {
  desired = !desired;
  try { localStorage.setItem(KEY, desired ? 'on' : 'off'); } catch {}
  applyPreference();
 });
 header.append(control); applyPreference();
}
function animate(el, keyframes, options) {
 if (!enabled() || typeof el.animate !== 'function') return;
 const animation = el.animate(keyframes, {duration: 600, easing: 'cubic-bezier(.2,.75,.2,1)', ...options});
 animations.add(animation);
 animation.finished.then(() => animations.delete(animation), () => animations.delete(animation));
}
function enter(el) {
 if (!enabled() || !el.isConnected || el.closest(excluded)) return;
 if (el.matches(heroes)) {
  el.classList.add('na-scene-arrived');
  const copy = el.querySelector('.world-hero-copy,.premium-hero-copy') || el;
  animate(copy, [{opacity: .25, transform: 'translateY(22px)'}, {opacity: 1, transform: 'none'}], {duration: 760});
  const art = el.querySelector('.world-hero-art,.premium-hero-art');
  // Animate only the photo, never a live chessboard or sports demonstration.
  if (art) animate(art, [{transform: 'scale(1.045)'}, {transform: 'scale(1)'}], {duration: 1800});
 } else {
  // Stagger siblings, with a strict cap so no section waits a long time.
  const siblings = [...(el.parentElement?.children || [])].filter(s => s.matches(candidates));
  const delay = Math.min(Math.max(siblings.indexOf(el), 0), 4) * 65;
  animate(el, [{opacity: .3, transform: 'translateY(20px)'}, {opacity: 1, transform: 'none'}], {delay});
 }
}
function prepare(el) {
 if (seen.has(el) || el.closest(excluded) || root.dataset.boot === 'loading') return;
 seen.add(el);
 if (el.matches(heroes) && !el.matches('.lobby-intro')) {
  el.classList.add('na-motion-scene');
  const art = document.createElement('div');
  art.className = 'na-motion-graphic'; art.setAttribute('aria-hidden', 'true');
  art.innerHTML = '<i></i><i></i><i></i>'; el.append(art);
 }
 if (observer) observer.observe(el); else enter(el);
}
function scan(node) {
 if (!(node instanceof Element) || node.closest(excluded)) return;
 if (node.matches(candidates)) prepare(node);
 for (const el of node.querySelectorAll(candidates)) prepare(el);
}
function flush() {
 scheduled = false; mountControl();
 for (const node of pending) if (node.isConnected) scan(node);
 pending.clear();
}
if ('IntersectionObserver' in window) observer = new IntersectionObserver(entries => {
 for (const entry of entries) if (entry.isIntersecting) { observer.unobserve(entry.target); enter(entry.target); }
}, {threshold: .08, rootMargin: '0px 0px -16px 0px'});
applyPreference(); mountControl(); scan(document.body);
new MutationObserver(records => {
 for (const record of records) for (const node of record.addedNodes) {
  if (!(node instanceof Element) || node.classList.contains('na-motion-graphic') || node.closest(excluded)) continue;
  // Ignore piece moves, clock text and other small game updates.
  if (node.matches(candidates) || node.querySelector(candidates)) pending.add(node);
 }
 if ((!control?.isConnected || pending.size) && !scheduled) { scheduled = true; requestAnimationFrame(flush); }
}).observe(document.body, {childList: true, subtree: true});
new MutationObserver(records => {
 if (records.some(r => r.attributeName === 'data-data-saver')) applyPreference();
 if (root.dataset.boot !== 'loading') { pending.add(document.body); if (!scheduled) { scheduled = true; requestAnimationFrame(flush); } }
}).observe(root, {attributes: true, attributeFilter: ['data-boot','data-data-saver']});
reduced.addEventListener('change', applyPreference);
addEventListener('storage', event => { if (event.key === KEY) { desired = saved(); applyPreference(); } });
document.addEventListener('visibilitychange', () => {
 root.dataset.pageHidden = String(document.hidden);
 for (const animation of animations) {
  if (document.hidden) animation.pause(); else if (enabled()) animation.play(); else animation.cancel();
 }
});
addEventListener('pagehide', () => { for (const animation of animations) animation.cancel(); });
