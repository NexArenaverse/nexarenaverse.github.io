import {extraChapters,extraQuestions} from './premium-adventure-extra.js';
export const premiumFeatures = [
  {id:'coach',path:'/plus/coach/',name:'AI Game Coach',tag:'REVIEW · UNDERSTAND · IMPROVE',text:'Review chess moves with a local engine and build a practice plan. Explore guided strategy for Ludo, Whot and word games.',symbol:'♞'},
  {id:'clubs',path:'/plus/clubs/',name:'Private Clubs & Leagues',tag:'YOUR PEOPLE · YOUR COMPETITION',text:'Create a private club, share an invite code and run a round-robin league with confirmed results.',symbol:'✺'},
  {id:'challenges',path:'/plus/challenges/',name:'Sports Skill Challenges',tag:'A LITTLE BETTER EVERY DAY',text:'Pick a sport, set your difficulty and track drills, streaks and personal practice badges.',symbol:'⚡'},
  {id:'adventures',path:'/plus/adventures/',name:'Learning Adventures',tag:'CURIOSITY HAS A NEW HOME',text:'Travel through maths, word and strategy missions on separate children’s and adult learning paths.',symbol:'✦'}
];
export const arenaLooks = [
 {id:'Lava',name:'Lava Kingdom',color:'#281712',pattern:'embers',a:'#d5793e',b:'#30211e'},
 {id:'Ice',name:'Ice World',color:'#142a3c',pattern:'frost',a:'#d8f4ff',b:'#578eb0'},
 {id:'Neon',name:'Cyber City',color:'#102733',pattern:'grid',a:'#b2eee1',b:'#19434e'},
 {id:'Galaxy',name:'Cosmic Glass',color:'#1c1536',pattern:'stars',a:'#b8a6dd',b:'#352b58'},
 {id:'Jungle',name:'Jungle Temple',color:'#152c23',pattern:'leaves',a:'#b6c991',b:'#315744'},
 {id:'Desert',name:'Desert Gold',color:'#362b20',pattern:'dunes',a:'#efcf94',b:'#ad794c'},
 {id:'Walnut',name:'Grandmaster Walnut',color:'#18251f',pattern:'solid',a:'#edcf9e',b:'#86623f'},
 {id:'Midnight',name:'Midnight Arena',color:'#080d20',pattern:'electric',a:'#a9bfcc',b:'#384a64'}
];
const sports = {
 basketball:[['Controlled crossover','Alternate a low dribble between hands. Keep your head up and change direction after every five transfers.','transfers'],['Spot shooting','Use a comfortable shooting distance. Reset your feet and follow through. Count makes out of attempts.','attempts'],['Footwork square','Use four safe floor markers. Step, stop in balance and pivot without crossing your feet.','circuits'],['Weak-hand control','Dribble with your non-dominant hand at waist height or below. Keep a comfortable stance.','bounces']],
 football:[['Inside-outside touch','Use the inside then outside of one foot to move the ball around a safe marker. Alternate feet.','touches'],['Target passing','Pass towards a floor marker or a safe wall target. Count accurate passes. Keep the area clear.','passes'],['Sole-roll control','Roll the ball sideways with your sole, then stop it with the other foot. Stay balanced.','rolls'],['Slalom course','Dribble around four markers at walking speed, then increase pace when control is steady.','circuits']],
 tennis:[['Shadow forehand','Without a ball, turn your shoulders, swing smoothly and recover to ready position. Keep space around the racket.','swings'],['Split-step recovery','Make a small split step, move sideways and return to your ready position. Use a non-slip surface.','cycles'],['Racket balance','Balance a ball on your racket, walk slowly and recover if it rolls.','steps'],['Gentle target rally','With a partner or safe practice wall, use short controlled strokes towards a marked area. Count target hits.','shots']],
 badminton:[['Ready-position recovery','Split step, take two controlled side steps and return to base. Keep your knees soft.','cycles'],['Shadow net lunge','Lunge towards an imaginary shuttle, recover and change sides. Keep the front knee aligned with your foot.','lunges'],['Grip changes','Slowly switch between a relaxed forehand grip and thumb-led backhand grip.','switches'],['Target service','Serve gently towards a marked service target. Count serves landing in the target.','serves']],
 'table-tennis':[['Shadow drive','Practise a compact forehand drive without a ball, then recover to ready position.','strokes'],['Ball balance','Balance a ball on the racket while taking slow steps in a clear area.','steps'],['Side-step rhythm','Take two short side steps left and right, staying in a comfortable ready stance.','cycles'],['Target serve','Serve safely towards a marked area on a table and count accurate landings.','serves']],
 athletics:[['Walking rhythm','Walk comfortably on a clear, level route. Keep your shoulders relaxed and your breathing easy.','minutes'],['Marching posture','March slowly in place, raising each knee comfortably. Keep your torso tall.','steps'],['Balance control','Stand near a stable support and balance on each leg. Use support whenever needed.','seconds'],['Easy intervals','Alternate one minute of easy walking with one minute at a slightly brisker pace. No sprinting is required.','minutes']]
};
export const sportChallenges = Object.entries(sports).flatMap(([sport,entries])=>entries.map(([name,detail,unit],i)=>({id:sport+'-'+i,sport,name,detail,unit,target:unit==='minutes'?4:unit==='seconds'?15:10,accuracy:['attempts','passes','shots','serves'].includes(unit)})));
export function challengeTarget(challenge,level) { return challenge.target + Math.max(0,Math.min(9,Math.floor(Number(level)||1)-1))*(challenge.unit==='minutes'?1:challenge.unit==='seconds'?5:3); }
export function lagosDay(time=Date.now()) {return new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Lagos',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(time));}
export function practiceStreak(logs,now=Date.now()) {const days=new Set(logs.map(x=>x.day));let n=0,t=now;if(!days.has(lagosDay(t)))t-=86400000;while(days.has(lagosDay(t))){n++;t-=86400000;}return n;}
export const adventureChapters = [
 {id:'number-port',name:'Number Harbour',theme:'maths',story:'Your airship reaches a floating harbour. Solve the supply puzzles to fuel your next journey.'},
 {id:'word-grove',name:'Word Grove',theme:'words',story:'The forest gates respond to language. Find the right words to light a path through the trees.'},
 {id:'logic-vault',name:'The Logic Vault',theme:'logic',story:'A hidden vault protects the city’s energy crystal. Look carefully for patterns and unlock its five seals.'}
];
adventureChapters.push(...extraChapters);
const Q=(question,choices,answer,explanation)=>({question,choices,answer,explanation});
export function adventureQuestions(mode,chapter) {
 if(!['child','adult'].includes(mode)||!adventureChapters.some(x=>x.id===chapter))throw Error('Choose a learning path and chapter.');
 if(extraQuestions[chapter])return extraQuestions[chapter][mode];
 const adult=mode==='adult';
 if(chapter==='number-port')return adult?[
 Q('A pass costs ₦1,500. What is the cost after a 20% discount?',['₦1,200','₦1,300','₦1,000'],0,'20% of ₦1,500 is ₦300. Subtract ₦300 to get ₦1,200.'),
 Q('A journey is 180 km. At 60 km/h, how long does it take?',['2 hours','3 hours','4 hours'],1,'Time = distance ÷ speed = 180 ÷ 60 = 3 hours.'),
 Q('What is 3/4 + 1/8?',['4/12','1/2','7/8'],2,'Convert 3/4 to 6/8, then add 1/8 to get 7/8.'),
 Q('Supplies cost ₦2,400 for 6 packs. What does one pack cost?',['₦400','₦600','₦300'],0,'₦2,400 divided by 6 is ₦400 per pack.'),
 Q('Which is larger, 0.65 or 3/5?',['They are equal','0.65','3/5'],1,'3/5 is 0.60. Therefore 0.65 is larger.')]:[
 Q('The harbour has 7 boats. Three more arrive. How many now?',['9','10','11'],1,'Start with 7 and add 3. There are 10 boats.'),
 Q('You have 12 apples and give away 5. How many remain?',['7','8','6'],0,'12 minus 5 is 7 apples.'),
 Q('Four boxes hold 2 stars each. How many stars?',['6','4','8'],2,'Four groups of two make 8 stars.'),
 Q('Share 15 coins equally among 3 captains. Each gets…',['3','5','6'],1,'15 divided into 3 equal groups gives 5 coins per captain.'),
 Q('Which fraction is half of a whole?',['1/2','1/3','1/4'],0,'One out of two equal parts is one half.')];
 if(chapter==='word-grove')return adult?[
 Q('Choose the clearest sentence.',['Neither of the players are ready.','Neither of the players is ready.','Neither players is ready.'],1,'“Neither” is singular here, so it takes “is”.'),
 Q('Which word means a conclusion drawn from evidence?',['Decoration','Interruption','Inference'],2,'An inference is a conclusion reached by reasoning from evidence.'),
 Q('“The coach was meticulous.” This means the coach was…',['Careful and thorough','Careless','Always late'],0,'Meticulous means showing close attention to detail.'),
 Q('Which sentence uses “its” correctly?',["The club changed it’s name.",'The club changed its name.','The club changed its’ name.'],1,'“Its” shows possession. “It’s” means “it is” or “it has”.'),
 Q('A reliable summary should…',['Repeat every sentence','Add unsupported claims','Keep the main ideas accurately'],2,'A summary preserves the main meaning while leaving out unnecessary detail.')]:[
 Q('Which word is the opposite of “brave”?',['Quick','Afraid','Bright'],1,'Someone who is afraid feels fear. “Brave” describes facing fear with courage.'),
 Q('Choose the correct sentence.',['She runs fast.','She run fast.','She running fast.'],0,'With “she” in the simple present, use “runs”.'),
 Q('Which word is a naming word, or noun?',['Quickly','Jump','Garden'],2,'“Garden” names a place, so it is a noun.'),
 Q('Which word rhymes with “light”?',['Night','Late','Leaf'],0,'“Light” and “night” end with the same sound.'),
 Q('Complete the sentence. “We ___ a team.”',['is','are','am'],1,'Use “are” with “we”. We are a team.')];
 return adult?[
 Q('Every rook is a chess piece. Which must be true?',['Every chess piece is a rook.','Some chess pieces are rooks.','No rooks are chess pieces.'],1,'Rooks are members of the larger set of chess pieces; the reverse does not follow.'),
 Q('What comes next? 2, 6, 12, 20, …',['28','32','30'],2,'The gaps are 4, 6 and 8. The next gap is 10, so the next number is 30.'),
 Q('A bag has 3 red and 2 blue counters. What is the chance of blue?',['2/5','3/5','1/2'],0,'Two of the five equally likely counters are blue.'),
 Q('A player wins after changing shoes. This alone proves…',['The shoes caused the win.','Only that the events occurred together.','The shoes guarantee future wins.'],1,'An association alone does not prove causation.'),
 Q('If A is taller than B and B taller than C, then…',['C is tallest.','B is taller than A.','A is taller than C.'],2,'The order is A, then B, then C.')]:[
 Q('What comes next? 2, 4, 6, 8, …',['9','10','12'],1,'Add 2 each time. After 8 comes 10.'),
 Q('What comes next? Star, moon, star, moon, …',['Star','Sun','Moon'],0,'The two shapes alternate. After moon comes star.'),
 Q('A square has how many corners?',['3','5','4'],2,'A square has four corners and four equal sides.'),
 Q('Ada is ahead of Ben in a line. Ben is ahead of Chi. Who is first?',['Ben','Ada','Chi'],1,'The order is Ada, Ben, Chi. Ada is first.'),
 Q('Which does not belong?',['Triangle','Circle','Banana'],2,'Triangle and circle are shapes. Banana is a fruit.')];
}
export function leagueStandings(members,fixtures){const table=new Map(members.map(m=>[m.player,{...m,played:0,wins:0,draws:0,points:0}]));for(const f of fixtures){if(f.status!=='confirmed')continue;const a=table.get(f.a),b=table.get(f.b);if(!a||!b)continue;a.played++;b.played++;if(f.result==='draw'){a.draws++;b.draws++;a.points++;b.points++;}else{const w=f.result==='a'?a:b;w.wins++;w.points+=3;}}return [...table.values()].sort((a,b)=>b.points-a.points||b.wins-a.wins||a.alias.localeCompare(b.alias));}
