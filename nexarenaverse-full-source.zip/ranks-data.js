const rankNames=['Newcomer','Spark','Scout','Apprentice','Tactician','Contender','Challenger','Pathfinder','Strategist','Vanguard','Expert','Elite','Champion','Master','Grandmaster','Titan','Legend','Mythic','Celestial','Immortal','Sovereign','World Guardian','Arena Eternal'];
// Local practice keeps its familiar ladder. Competitive ranks use the harder gates below.
export const practiceRanks=rankNames.map((name,i)=>({level:i+1,name,points:[0,100,300,600,1000,1800,3000,5000,8000,12000,18000,26000,38000,54000,75000,100000,135000,180000,240000,320000,420000,550000,750000][i],games:[0,1,3,6,10,18,30,45,65,90,120,160,210,280,360,450,550,680,820,1000,1200,1500,2000][i],wins:[0,0,1,2,4,7,12,18,26,36,48,64,84,112,144,180,220,272,328,400,480,600,800][i],variety:i<4?0:i<9?1:i<14?2:i<19?3:5}));
export const rankedGames={'chess':'Chess','ludo':'Ludo','whot':'Whot','checkers':'Checkers','tic-tac-toe':'Tic-tac-toe'};
// At least 10x the old cumulative points/matches; the multiplier rises to 15x.
// Every new step has a bigger points, match and total-win gap than the previous step.
export const ranks=practiceRanks.map((r,i)=>({...r,points:i?Math.ceil(r.points*10*(44+i)/44/100)*100:0,games:Math.ceil(r.games*10*(44+i)/44),wins:i?Math.max(i*5,Math.ceil(r.wins*10*(44+i)/44)):0,variety:i===0?0:i<5?2:i<10?3:i<16?4:5,gameWins:i?Math.ceil(i*i/2):0}));
const rankCount=value=>Number.isFinite(Number(value))?Math.max(0,Math.floor(Number(value))):0;
export const rankRequirements=(player={},tier=ranks[0])=>{
  const games=Object.entries(rankedGames).map(([id,name])=>({id,name,current:rankCount(player.gameWins?.[id]),target:tier.gameWins||0,met:rankCount(player.gameWins?.[id])>=(tier.gameWins||0)}));
  const checks=['points','games','wins','variety'].map(key=>({key,current:rankCount(player[key]),target:tier[key],met:rankCount(player[key])>=tier[key]}));
  const mastery={current:games.filter(g=>g.met).length,target:tier.variety,winsPerGame:tier.gameWins||0,games};
  mastery.met=!tier.gameWins||mastery.current>=mastery.target;
  const fractions=checks.filter(c=>c.target).map(c=>Math.min(1,c.current/c.target));
  if(tier.gameWins){const best=games.map(g=>Math.min(1,g.current/g.target)).sort((a,b)=>b-a).slice(0,tier.variety);fractions.push(best.reduce((a,b)=>a+b,0)/tier.variety)}
  return {checks,mastery,met:checks.every(c=>c.met)&&mastery.met,percent:Math.floor(100*(fractions.length?Math.min(...fractions):1))};
};
export const rankFor=(player,ladder=ranks)=>{let earned=ladder[0];for(const tier of ladder.slice(1)){if(!rankRequirements(player,tier).met)break;earned=tier}return earned};
