const extra={
'football/scoring':[
['Instep finish','Approach a stationary ball with short steps.','Place the supporting foot beside the ball and keep the kicking ankle firm.','Strike with the laces and follow through toward a broad target.','Take 10 gentle laces shots from close range, alternating feet.'],
['First-touch finish','Ask a partner for a slow ground pass.','Use one touch to settle the ball into comfortable shooting space.','Finish with a controlled inside-foot strike.','Repeat 10 pass-control-finish sequences without rushing.'],
['Placed far-corner finish','Set a wide target on one side of a safe goal.','Open your hips slightly and use the inside of your foot.','Aim for placement at comfortable power, then reset your balance.','Take 5 shots toward each side from a short distance.']],
'football/passing':[
['One-two combination','Pass gently to a partner a few metres away.','Move into an open lane immediately after your pass.','Receive the return under control and reset.','Complete 10 pass-move-return combinations.'],
['Receive across the body','Stand side-on as a gentle pass approaches.','Use the foot farther from the ball to guide it across your body.','Turn into space and pass back with control.','Receive and return 10 passes on each side.'],
['Pass through a gate','Place two markers 1 metre apart.','Point your supporting foot at the gate.','Use a firm inside-foot pass, keeping the ball along the ground.','Make 20 short passes through the gate and count successes.']],
'football/defence':[
['Jockey the attacker','Stand between an imagined attacker and the goal.','Move backward in small steps with knees bent.','Keep a little space and avoid reaching for the ball.','Shadow a walking partner for 4 rounds of 20 seconds without tackling.'],
['Show toward the sideline','Set a marker as an imaginary goal.','Stand slightly angled to guide a walking attacker away from the centre.','Adjust using short steps without crossing your feet.','Walk through 5 slow defending sequences on each side.'],
['Recovery and goal-side position','Start a few steps beside a partner.','Jog back toward the goal marker as they move forward slowly.','Finish between the attacker and goal, then slow into a balanced stance.','Complete 6 low-speed recoveries with no contact.']],
'basketball/shooting':[
['Right-side layup footwork','Walk toward the basket from the right.','Rehearse right-foot then left-foot steps after gathering the ball.','Rise gently from the left foot and release with the right hand.','Walk through 10 repetitions without jumping high or rushing.'],
['Left-side layup footwork','Walk toward the basket from the left.','After gathering, rehearse left-foot then right-foot steps.','Rise gently from the right foot and release with the left hand.','Complete 10 slow close-range layup attempts.'],
['Set-shot follow-through','Stand close to the hoop with feet balanced.','Place the shooting hand under the ball and guide hand at its side.','Extend smoothly and hold a relaxed wrist finish briefly.','Take 15 short shots and record how many finish with balanced form.']],
'basketball/passing':[
['Bounce pass to a moving partner','Face a partner walking slowly across your view.','Step toward the space they are moving into.','Bounce the ball so it rises comfortably toward their hands.','Complete 10 gentle leading bounce passes each way.'],
['Overhead pass','Hold the ball above the forehead with both hands.','Step toward a nearby target without leaning backward.','Extend both arms forward and release a controlled pass.','Make 15 short overhead passes to a partner or suitable wall.'],
['Pivot and pass','Hold the ball in a balanced stance.','Keep one pivot foot planted while turning to face a new target.','Step with the free foot and make a controlled chest pass.','Practise 5 pivots and passes in each direction.']],
'basketball/footwork':[
['Controlled closeout','Start a few metres from a marker.','Move toward it, then shorten your steps before arriving.','Finish balanced with hands up, without jumping into the marker.','Complete 8 gentle closeouts and stop under control.'],
['Drop-step recovery','Begin in a defensive stance.','Turn the foot on the new direction side backward to open your hips.','Move into the new direction and recover into a balanced stance.','Practise 5 slow recoveries each way without crossing awkwardly.'],
['Slide and recover','Slide two steps to one side.','Stop with feet apart and weight balanced.','Slide back to the start, keeping the chest upright.','Do 4 rounds of 20 seconds with rests.']],
 'tennis/forehand':[
['Mini-court forehand','Start close to the service line with a partner.','Use a short backswing and gentle low-to-high contact.','Aim for a cooperative rally rather than speed.','Try 5 mini-court rallies of 6 shots.'],
['Cross-court forehand','Position comfortably behind a gentle feed.','Contact in front and guide the ball diagonally across court.','Recover toward a central ready position.','Hit 15 easy feeds toward a broad diagonal target.'],
['Forehand after a bounce feed','Drop the ball in front of your hitting side.','Let it bounce into a comfortable contact height.','Swing smoothly and finish balanced.','Play 20 self-fed forehands into a large safe target area.']],
 'tennis/backhand':[
['Backhand shadow turn','Begin with both hands on the racket.','Turn the shoulders and place your feet comfortably.','Swing slowly through an imagined contact point in front.','Rehearse 15 relaxed swings without a ball.'],
['Mini-court backhand','Stand near the service line opposite a partner.','Use a compact backhand action on gentle feeds.','Guide the ball back and reset the racket in front.','Complete 5 cooperative rallies aiming for 5 backhands each.'],
['Backhand recovery step','Move sideways to an easy feed.','Hit a controlled two-handed backhand.','Take small recovery steps toward your starting position.','Complete 12 feed-hit-recover repetitions.']],
 'tennis/serve':[
['Toss consistency','Stand comfortably with your non-racket arm forward.','Lift and release the ball gently rather than flicking the wrist.','Let it descend and catch it near the same comfortable position.','Make 20 tosses without swinging a racket.'],
['Short-court gentle serve','Start closer to the service line for practice.','Use a small consistent toss and a relaxed overhead action.','Send the ball gently into the opposite diagonal service box.','Attempt 15 short-distance serves at comfortable effort.'],
['Serve and recover','Rehearse a gentle serve with a consistent toss.','Finish balanced inside a safe practice area.','Recover into a ready stance with the racket in front.','Complete 10 slow serve-and-ready sequences.']],
 'tennis/movement':[
['Split-step timing','Stand comfortably with the racket ready.','Make a small light readiness hop or rise as an imaginary opponent contacts the ball.','Land softly and take a controlled step toward the next marker.','Practise 15 soft split-step-and-move repetitions.'],
['Side-step recovery','Move sideways to a marker using small controlled steps.','Shadow a shot with balanced spacing.','Return using short side steps without rushing.','Complete 5 trips to each side, recovering to the centre after every shadow shot.'],
['Forward approach and reset','Start behind a marker.','Move forward with short steps to an imaginary short ball.','Shadow a gentle shot, stop under control and recover.','Complete 10 slow approach-and-recover sequences.']],
 'table-tennis/control':[
['Forehand bat bounce','Hold the racket face roughly level in front.','Bounce the ball gently from the forehand surface.','Adjust the bat underneath the ball using small movements.','Count your longest controlled run in 3 rounds of 30 seconds.'],
['Backhand bat bounce','Turn the racket to use the backhand face.','Keep the wrist relaxed and the bat steady.','Use small controlled lifts to keep the ball near the centre.','Try 3 rounds of 20 bounces and reset your grip between rounds.'],
['Alternating-face control','Begin with a gentle forehand bounce.','Turn the racket and receive the next bounce on its backhand face.','Alternate slowly, allowing time to reset.','Aim for 10 alternating contacts without chasing the ball.']],
 'table-tennis/forehand':[
['Forehand placement','Begin with a compact ready stance.','Play gentle forehand returns toward a broad diagonal area.','Recover after each shot instead of holding the finish.','Return 20 partner feeds and count accurate placements.'],
['Forehand after side step','Start one small step from your hitting position.','Side-step into comfortable spacing as a gentle feed approaches.','Use a compact forehand drive and reset.','Complete 10 slow feed-step-hit sequences.'],
['Forehand consistency rally','Agree with a partner to keep the ball slow.','Use short controlled forehand strokes.','Prioritise a repeatable contact point over power.','Attempt 5 rallies with a target of 10 cooperative shots.']],
 'table-tennis/backhand':[
['Backhand placement','Keep the racket in front of the body.','Use a short forward stroke toward a broad target.','Recover to the ready position after contact.','Return 20 easy feeds toward the same table half.'],
['Backhand block basics','Ask a partner for very gentle drives.','Keep a stable racket face in front of you.','Use a small movement to redirect the ball without a big swing.','Try 15 controlled blocks from easy feeds.'],
['Backhand-to-forehand transition','Begin in a neutral ready stance.','Play one compact backhand, then return the racket to the middle.','Adjust your feet for a gentle forehand feed.','Repeat 10 slow two-shot patterns with a partner.']],
 'table-tennis/serve':[
['Legal toss rehearsal','Rest the ball freely on the open palm of a stationary hand.','Toss near vertically at least 16 centimetres without adding spin.','Catch after the descent while keeping the ball visible.','Practise 20 clear tosses above table level and behind the end line.'],
['Short controlled serve','Use the open-palm toss and strike as the ball falls.','Choose a gentle contact so the ball bounces on your side first.','Aim for a short, low bounce on the receiver’s side while keeping service visible.','Make 20 gentle serves toward a broad front-table target.'],
['Deep placement serve','Start with the same visible open-palm service preparation.','Use a slightly firmer controlled contact after the toss.','Aim for a deeper receiver-side bounce without striking wildly.','Practise 10 serves toward each deep corner with no added spin target.']],
 'badminton/footwork':[
['Front-court lunge preparation','Step toward a front marker at walking pace.','Bend the leading knee comfortably while keeping it aligned with the foot.','Push back gently and recover to the starting position.','Complete 5 comfortable front-court approaches on each side.'],
['Side-court shuffle','Start balanced near a central marker.','Use small side steps to reach a wide marker.','Shadow a gentle shot and recover without crossing feet awkwardly.','Make 5 controlled trips to each side.'],
['Four-corner recovery','Arrange four markers in a comfortable area.','Visit one corner at a time and shadow a simple shot.','Return to centre before moving to the next corner.','Complete 3 slow rounds with full rests.']],
 'badminton/serve':[
['Backhand short-serve action','Hold the shuttle in front near the racket face.','Use a small controlled backhand push.','Guide the shuttle gently into the opposite diagonal service court.','Practise 20 easy serves without aiming for speed.'],
['Forehand underarm serve','Stand side-on in a balanced position.','Release the shuttle into a gentle underarm forward swing.','Follow through smoothly toward the diagonal service court.','Complete 15 comfortable forehand serves.'],
['Serve placement targets','Choose two broad target areas in the diagonal service box.','Use the same controlled underarm preparation each time.','Alternate targets while keeping the action relaxed.','Try 10 serves to each target and record landings.']],
 'badminton/clear':[
['Overhead shadow preparation','Turn the shoulders with the racket raised comfortably.','Reach upward through an imagined contact point.','Finish with a relaxed follow-through and recover.','Rehearse 15 slow overhead swings without a shuttle.'],
['High defensive clear','Move behind an easy partner feed early.','Use a smooth overhead swing and contact comfortably above you.','Aim high toward the back half of the opposing court.','Try 15 gentle fed clears with rests between sets.'],
['Clear and return to base','Prepare early for a gentle overhead feed.','Play a controlled clear without forcing power.','Recover toward the central marker before the next feed.','Complete 10 clear-and-recover sequences.']],
 'badminton/net-play':[
['Forehand net touch','Approach the shuttle slowly with the racket ready.','Use a short gentle forehand contact in front.','Recover without stepping into the net.','Exchange 15 easy forehand net feeds with a partner.'],
['Backhand net touch','Move under control toward the backhand side.','Keep the racket up and use a gentle short push.','Recover to a balanced stance after contact.','Return 15 gentle backhand net feeds.'],
['Net shot and recover','Start a comfortable step from the front court.','Approach and play a gentle net shot.','Push back toward a centre marker and reset.','Repeat 10 slow feed-touch-recover sequences.']],
 'athletics/running':[
['Easy walk-jog rhythm','Begin with several minutes of comfortable walking.','Jog gently with relaxed shoulders and natural arm swing.','Return to walking before breathing becomes strained.','Alternate 30 seconds of easy jogging and 60 seconds walking for 5 rounds.'],
['Arm-swing rehearsal','Stand tall with shoulders relaxed.','Bend the elbows comfortably and swing forward and back.','Keep the hands relaxed without forcing them across the body.','Practise 3 rounds of 20 seconds, then add an easy walk.'],
['Relaxed stride practice','Choose a clear level lane.','Start with easy short steps and an upright comfortable posture.','Jog through the lane, then slow gradually into a walk.','Do 4 easy 15-metre runs with walking recovery.']],
 'athletics/starts':[
['Standing start','Place one foot a little ahead of the other.','Shift weight gently forward and begin with a controlled first step.','Build pace gradually for a few steps rather than sprinting maximally.','Complete 6 comfortable starts over 10 metres.'],
['First-three-step rehearsal','Begin from a balanced standing position.','Take three purposeful but comfortable steps forward.','Slow down gradually and reset fully.','Practise 8 three-step starts with walking rests.'],
['Acceleration to controlled slowdown','Begin with an easy standing start.','Increase speed smoothly over a short clear lane.','Use several shorter steps to slow gradually, never stopping abruptly.','Do 4 gentle accelerations over 15 metres with plenty of stopping space.']],
 'athletics/pacing':[
['Talk-test pacing','Start with brisk walking after warming up.','Try an easy jog while staying able to speak in short sentences.','Slow back to walking if speech becomes uncomfortable.','Alternate 1 minute easy jog and 1 minute walk for 5 rounds.'],
['Even-effort intervals','Choose a short comfortable interval duration.','Keep the effort easy and similar each round.','Walk and recover fully before repeating.','Try 4 easy 45-second efforts with 60-second walking recoveries.'],
['Comfortable finish','Begin a short session at a deliberately easy pace.','Maintain relaxed breathing rather than chasing a distance target.','Finish with a few minutes of gentle walking.','Walk briskly for 5 minutes, jog easily for up to 2 minutes, then walk to cool down.']],
 'athletics/coordination':[
['Opposite-arm march','Stand upright and relaxed.','Lift one knee comfortably while moving the opposite arm forward.','Set the foot down softly and switch sides.','Complete 3 rounds of 30 seconds at a slow rhythm.'],
['Heel-to-toe walking control','Choose a clear flat lane with support nearby if needed.','Walk slowly, placing each foot down under control.','Use relaxed opposite-arm movement without overstriding.','Walk 5 metres and back 4 times at a comfortable pace.'],
['Gentle skipping rhythm','First establish a comfortable marching rhythm.','If comfortable, add a small step-hop action with opposite-arm movement.','Keep the hops low and land softly, returning to walking if needed.','Try 3 rounds of 10 seconds with walking rests.']]
};
export function extraTutorials(s,k){return (extra[s.id+'/'+k.id]||[]).map((x,i)=>({id:'technique-'+(i+1),name:x[0],steps:x.slice(1,4),drill:x[4],target:'Complete the drill with controlled form and comfortable effort before increasing difficulty.',stage:'Specific technique'}))}
