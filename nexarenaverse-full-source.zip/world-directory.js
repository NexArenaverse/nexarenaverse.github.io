// Public destinations only. No private profiles or account data.
export const worldDirectory = [
  {
    "id": "chess",
    "name": "Chess Club",
    "path": "/game/chess/",
    "category": "Games",
    "icon": "♞",
    "description": "Sculpted boards, computer levels and tactics.",
    "tags": "lichess chess.com chess puzzles",
    "label": "Open world"
  },
  {
    "id": "ludo",
    "name": "Ludo Lounge",
    "path": "/game/ludo/",
    "category": "Games",
    "icon": "⚄",
    "description": "Choose your atmosphere and race home.",
    "tags": "dice board friends",
    "label": "Open world"
  },
  {
    "id": "whot",
    "name": "Whot Social",
    "path": "/game/whot/",
    "category": "Games",
    "icon": "★",
    "description": "Match shapes, plan ahead and play your hand.",
    "tags": "cards",
    "label": "Open world"
  },
  {
    "id": "word-tiles",
    "name": "Word Workshop",
    "path": "/game/word-tiles/",
    "category": "Games",
    "icon": "ABC",
    "description": "Build words from your letter rack.",
    "tags": "scrabble word sprint vocabulary",
    "label": "Open world"
  },
  {
    "id": "tic-tac-toe",
    "name": "Neon Nine",
    "path": "/game/tic-tac-toe/",
    "category": "Games",
    "icon": "×○",
    "description": "A quick strategy duel.",
    "tags": "noughts crosses",
    "label": "Open world"
  },
  {
    "id": "checkers",
    "name": "Checkers House",
    "path": "/game/checkers/",
    "category": "Games",
    "icon": "◉",
    "description": "Plan your jumps and capture the board.",
    "tags": "draughts",
    "label": "Open world"
  },
  {
    "id": "sudoku",
    "name": "Logic Studio",
    "path": "/game/sudoku/",
    "category": "Games",
    "icon": "9",
    "description": "Number puzzles with one valid solution.",
    "tags": "logic numbers",
    "label": "Open world"
  },
  {
    "id": "memory-match",
    "name": "Memory Garden",
    "path": "/game/memory-match/",
    "category": "Games",
    "icon": "✿",
    "description": "Turn cards, remember places and find pairs.",
    "tags": "matching memory",
    "label": "Open world"
  },
  {
    "id": "education-math-sprint",
    "name": "Math Mission",
    "path": "/education/math-sprint/",
    "category": "Learning",
    "icon": "➗",
    "description": "Solve sums, products and missing-number equations.",
    "tags": "Maths education children adults",
    "label": "Open world"
  },
  {
    "id": "education-fraction-lab",
    "name": "Fraction Lab",
    "path": "/education/fraction-lab/",
    "category": "Learning",
    "icon": "½",
    "description": "Discover fractions, equivalent values and percentages.",
    "tags": "Maths education children adults",
    "label": "Open world"
  },
  {
    "id": "education-word-builder",
    "name": "Word Builder",
    "path": "/education/word-builder/",
    "category": "Learning",
    "icon": "ABC",
    "description": "Unscramble words using a definition as your clue.",
    "tags": "Language education children adults",
    "label": "Open world"
  },
  {
    "id": "education-word-links",
    "name": "Word Links",
    "path": "/education/word-links/",
    "category": "Learning",
    "icon": "↔",
    "description": "Find synonyms and build a stronger vocabulary.",
    "tags": "Language education children adults",
    "label": "Open world"
  },
  {
    "id": "education-grammar-quest",
    "name": "Grammar Quest",
    "path": "/education/grammar-quest/",
    "category": "Learning",
    "icon": "✍",
    "description": "Choose the words that make each sentence work.",
    "tags": "Language education children adults",
    "label": "Open world"
  },
  {
    "id": "education-science-explorer",
    "name": "Science Explorer",
    "path": "/education/science-explorer/",
    "category": "Learning",
    "icon": "🔬",
    "description": "Explore everyday science, nature and discovery.",
    "tags": "Science education children adults",
    "label": "Open world"
  },
  {
    "id": "education-world-explorer",
    "name": "World Explorer",
    "path": "/education/world-explorer/",
    "category": "Learning",
    "icon": "🌍",
    "description": "Travel through continents, oceans and capitals.",
    "tags": "Geography education children adults",
    "label": "Open world"
  },
  {
    "id": "education-pattern-code",
    "name": "Pattern Code",
    "path": "/education/pattern-code/",
    "category": "Learning",
    "icon": "123",
    "description": "Find the next number and explain the pattern.",
    "tags": "Reasoning education children adults",
    "label": "Open world"
  },
  {
    "id": "education-logic-detective",
    "name": "Logic Detective",
    "path": "/education/logic-detective/",
    "category": "Learning",
    "icon": "🔎",
    "description": "Use clues and deductions to find a valid conclusion.",
    "tags": "Reasoning education children adults",
    "label": "Open world"
  },
  {
    "id": "education-code-starter",
    "name": "Code Starter",
    "path": "/education/code-starter/",
    "category": "Learning",
    "icon": "⌘",
    "description": "Try binary numbers, conditions and small code puzzles.",
    "tags": "Computing education children adults",
    "label": "Open world"
  },
  {
    "id": "kids-count-stars",
    "name": "Star Counter",
    "path": "/kids/count-stars/",
    "category": "Children",
    "icon": "⭐",
    "description": "Count the stars and find the number.",
    "tags": "children kids",
    "label": "Open world"
  },
  {
    "id": "kids-number-buddies",
    "name": "Number Buddies",
    "path": "/kids/number-buddies/",
    "category": "Children",
    "icon": "➕",
    "description": "Add small numbers with friendly helpers.",
    "tags": "children kids",
    "label": "Open world"
  },
  {
    "id": "kids-colour-quest",
    "name": "Colour Quest",
    "path": "/kids/colour-quest/",
    "category": "Children",
    "icon": "🎨",
    "description": "Match colour names to bright swatches.",
    "tags": "children kids",
    "label": "Open world"
  },
  {
    "id": "kids-shape-safari",
    "name": "Shape Safari",
    "path": "/kids/shape-safari/",
    "category": "Children",
    "icon": "🔷",
    "description": "Discover circles, triangles and squares.",
    "tags": "children kids",
    "label": "Open world"
  },
  {
    "id": "kids-pattern-party",
    "name": "Pattern Party",
    "path": "/kids/pattern-party/",
    "category": "Children",
    "icon": "🧩",
    "description": "Find what comes next in a repeating pattern.",
    "tags": "children kids",
    "label": "Open world"
  },
  {
    "id": "kids-animal-pairs",
    "name": "Animal Pairs",
    "path": "/kids/animal-pairs/",
    "category": "Children",
    "icon": "🦊",
    "description": "Turn over cards and find animal friends.",
    "tags": "children kids",
    "label": "Open world"
  },
  {
    "id": "sport-football",
    "name": "Football Academy",
    "path": "/sport/football/",
    "category": "Sports",
    "icon": "⚽",
    "description": "Control the ball. Create the chance.",
    "tags": "sports skills tutorials soccer",
    "label": "Open world"
  },
  {
    "id": "arcade-football",
    "name": "Football Game Centre",
    "path": "/sports/games/football/",
    "category": "Sports",
    "icon": "✦",
    "description": "Eleven sports challenges with ten levels.",
    "tags": "guess player sports arcade quiz",
    "label": "Open world"
  },
  {
    "id": "sport-basketball",
    "name": "Basketball Academy",
    "path": "/sport/basketball/",
    "category": "Sports",
    "icon": "🏀",
    "description": "Find your handle. Own your shot.",
    "tags": "sports skills tutorials ",
    "label": "Open world"
  },
  {
    "id": "arcade-basketball",
    "name": "Basketball Game Centre",
    "path": "/sports/games/basketball/",
    "category": "Sports",
    "icon": "✦",
    "description": "Eleven sports challenges with ten levels.",
    "tags": "guess player sports arcade quiz",
    "label": "Open world"
  },
  {
    "id": "sport-tennis",
    "name": "Tennis Academy",
    "path": "/sport/tennis/",
    "category": "Sports",
    "icon": "🎾",
    "description": "Build the rally, one shot at a time.",
    "tags": "sports skills tutorials ",
    "label": "Open world"
  },
  {
    "id": "arcade-tennis",
    "name": "Tennis Game Centre",
    "path": "/sports/games/tennis/",
    "category": "Sports",
    "icon": "✦",
    "description": "Eleven sports challenges with ten levels.",
    "tags": "guess player sports arcade quiz",
    "label": "Open world"
  },
  {
    "id": "sport-table-tennis",
    "name": "Table tennis Academy",
    "path": "/sport/table-tennis/",
    "category": "Sports",
    "icon": "◈",
    "description": "Quick thinking. Precise touch.",
    "tags": "sports skills tutorials ",
    "label": "Open world"
  },
  {
    "id": "arcade-table-tennis",
    "name": "Table tennis Game Centre",
    "path": "/sports/games/table-tennis/",
    "category": "Sports",
    "icon": "✦",
    "description": "Eleven sports challenges with ten levels.",
    "tags": "guess player sports arcade quiz",
    "label": "Open world"
  },
  {
    "id": "sport-badminton",
    "name": "Badminton Academy",
    "path": "/sport/badminton/",
    "category": "Sports",
    "icon": "◈",
    "description": "Move light. Strike with purpose.",
    "tags": "sports skills tutorials ",
    "label": "Open world"
  },
  {
    "id": "arcade-badminton",
    "name": "Badminton Game Centre",
    "path": "/sports/games/badminton/",
    "category": "Sports",
    "icon": "✦",
    "description": "Eleven sports challenges with ten levels.",
    "tags": "guess player sports arcade quiz",
    "label": "Open world"
  },
  {
    "id": "sport-athletics",
    "name": "Athletics Academy",
    "path": "/sport/athletics/",
    "category": "Sports",
    "icon": "🏃",
    "description": "Build rhythm. Find your stride.",
    "tags": "sports skills tutorials running",
    "label": "Open world"
  },
  {
    "id": "arcade-athletics",
    "name": "Athletics Game Centre",
    "path": "/sports/games/athletics/",
    "category": "Sports",
    "icon": "✦",
    "description": "Eleven sports challenges with ten levels.",
    "tags": "guess player sports arcade quiz",
    "label": "Open world"
  },
  {
    "id": "games",
    "name": "Games Arena",
    "path": "/",
    "category": "Games",
    "icon": "♞",
    "description": "Choose from eight playable game worlds.",
    "tags": "games",
    "label": "Open world"
  },
  {
    "id": "education",
    "name": "Education Centre",
    "path": "/education/",
    "category": "Learning",
    "icon": "⌘",
    "description": "Ten learning games for children and adults.",
    "tags": "maths science geography coding english",
    "label": "Open world"
  },
  {
    "id": "children",
    "name": "Children’s Play Planet",
    "path": "/kids/",
    "category": "Children",
    "icon": "🌈",
    "description": "Six games for little explorers.",
    "tags": "kids",
    "label": "Open world"
  },
  {
    "id": "sports",
    "name": "Sports Academy",
    "path": "/sports/",
    "category": "Sports",
    "icon": "🏆",
    "description": "Six sport academies and step-by-step tutorials.",
    "tags": "sports",
    "label": "Open world"
  },
  {
    "id": "today",
    "name": "Sports Today",
    "path": "/sports/today/",
    "category": "Sports",
    "icon": "▶",
    "description": "Fixtures, results, standings and official highlights.",
    "tags": "nba football live scores recap",
    "label": "Open world"
  },
  {
    "id": "sports-arcade",
    "name": "Sports Game Centre",
    "path": "/sports/games/",
    "category": "Sports",
    "icon": "✦",
    "description": "Explore 66 sports challenges.",
    "tags": "guess player quiz arcade",
    "label": "Open world"
  },
  {
    "id": "premium",
    "name": "Premium Worlds",
    "path": "/plus/",
    "category": "Premium",
    "icon": "✧",
    "description": "All your extra worlds, together.",
    "tags": "plus",
    "label": "Open world"
  },
  {
    "id": "game-coach",
    "name": "AI Game Coach",
    "path": "/plus/coach/",
    "category": "Premium",
    "icon": "♛",
    "description": "PGN reviews, six tactics and saved practice plans.",
    "tags": "analysis chess",
    "label": "Practice preview"
  },
  {
    "id": "studio",
    "name": "Arena Studio",
    "path": "/plus/designs/",
    "category": "Premium",
    "icon": "◈",
    "description": "Lava, ice and cyber themes. Save and share looks.",
    "tags": "background boards designs",
    "label": "Practice preview"
  },
  {
    "id": "clubs",
    "name": "Private Clubs & Leagues",
    "path": "/plus/clubs/",
    "category": "Premium",
    "icon": "♜",
    "description": "Private club tools and a round-robin planner.",
    "tags": "friends league invitations",
    "label": "Practice preview"
  },
  {
    "id": "challenges",
    "name": "Sports Skill Challenges",
    "path": "/plus/challenges/",
    "category": "Premium",
    "icon": "◎",
    "description": "Timed drills, weekly goals and progress.",
    "tags": "training timer",
    "label": "Practice preview"
  },
  {
    "id": "adventures",
    "name": "Learning Adventures",
    "path": "/plus/adventures/",
    "category": "Premium",
    "icon": "✦",
    "description": "Six story islands and 60 explained questions.",
    "tags": "education adults children",
    "label": "Practice preview"
  },
  {
    "id": "coaches",
    "name": "Coach Centre",
    "path": "/coaches/",
    "category": "Premium",
    "icon": "◇",
    "description": "Search 100 public coaches, academies and creators.",
    "tags": "basketball tennis football coach contact",
    "label": "Open world"
  },
  {
    "id": "teach",
    "name": "Teach on NexArenaverse",
    "path": "/coaches/apply/",
    "category": "Tools",
    "icon": "◉",
    "description": "Learn how to apply to teach.",
    "tags": "coach application",
    "label": "Open world"
  },
  {
    "id": "data-saver",
    "name": "Data Saver",
    "path": "/plus/data-saver/",
    "category": "Tools",
    "icon": "↓",
    "description": "Save selected practice pages for offline use.",
    "tags": "download offline internet",
    "label": "Open world"
  },
  {
    "id": "membership",
    "name": "Arena Plus",
    "path": "/plus/membership/",
    "category": "Premium",
    "icon": "✧",
    "description": "Explore membership benefits and the free demo.",
    "tags": "subscription",
    "label": "Checkout preview"
  },
  {
    "id": "circle",
    "name": "Family & School Circle",
    "path": "/plus/circle/",
    "category": "Premium",
    "icon": "●",
    "description": "Explore private five-person Circle access.",
    "tags": "family group",
    "label": "Checkout preview"
  },
  {
    "id": "advertise",
    "name": "Advertising Studio",
    "path": "/advertise/",
    "category": "Tools",
    "icon": "▣",
    "description": "Request a campaign quote and try the demo.",
    "tags": "sponsor advertisement",
    "label": "Open world"
  },
  {
    "id": "install",
    "name": "Download App",
    "path": "/install/",
    "category": "Tools",
    "icon": "↓",
    "description": "Add NexArenaverse to your home screen.",
    "tags": "install pwa android iphone",
    "label": "Open world"
  }
];
export const worldCategories = ["All","Games","Sports","Learning","Children","Premium","Tools"];
const normalise = value => String(value||"").normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
export function findWorlds({query="",category="All",savedOnly=false}={},saved=[]){const terms=normalise(query).trim().split(/\s+/).filter(Boolean);return worldDirectory.filter(w=>(category==="All"||w.category===category)&&(!savedOnly||saved.includes(w.id))&&terms.every(term=>normalise([w.name,w.description,w.tags,w.category].join(" ")).includes(term)));}
