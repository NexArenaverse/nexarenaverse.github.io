import {coachingProviders} from './coaching-providers.js';
import {directories, sports} from './market-world-data.js';

const pageSize = 12;
const typeLabels = {individual:'Personal coach', academy:'Academy', creator:'Tutorial creator'};
const deliveryLabels = {online:'Online coaching', 'in-person':'In person', video:'Video tutorials'};
const sportName = sport => sport.replaceAll('-', ' ');
const storageKey = 'na-coach-shortlist';

export function filterCoaches(providers, filters, saved = []) {
  const term = (filters.q || '').trim().toLocaleLowerCase();
  return providers.filter(coach =>
    (!filters.sport || coach.sport === filters.sport) &&
    (!filters.country || coach.country === filters.country) &&
    (!filters.type || coach.type === filters.type) &&
    (!filters.delivery || coach.delivery.includes(filters.delivery)) &&
    (!filters.saved || saved.includes(coach.id)) &&
    (!term || [coach.name, coach.focus, coach.country, sportName(coach.sport)].join(' ').toLocaleLowerCase().includes(term))
  ).sort((a,b) => filters.sort === 'name' ? a.name.localeCompare(b.name) : a.sport.localeCompare(b.sport) || a.name.localeCompare(b.name));
}

export function renderCoachCentre(context) {
  const {app, button, esc, money, catalog, currency, api, date, purchase} = context;
  let saved;
  try { saved = JSON.parse(localStorage.getItem(storageKey) || '[]'); } catch {}
  saved = Array.isArray(saved) ? saved.filter(id => coachingProviders.some(coach => coach.id === id)) : [];
  let compared = [], page = 1, directoryView = 'all';
  const query = new URLSearchParams(location.search);
  const filters = Object.fromEntries(['q','sport','country','type','delivery','sort'].map(key => [key,query.get(key) || '']));
  const options = (items, all) => '<option value="">' + all + '</option>' +
    items.map(([value,label]) => `<option value="${esc(value)}">${esc(label)}</option>`).join('');
  app.className = 'premium-app coach-centre';
  app.dataset.world = 'amber';
  app.innerHTML = `<section class="coach-hero premium-hero">
    <div class="premium-hero-copy"><p class="premium-kicker">NEXARENAVERSE COACH CENTRE</p>
      <h1>Find your edge.<br><em>Meet your coach.</em></h1>
      <p>Explore ${coachingProviders.length} coaches, academies and tutorial creators across seven disciplines. Find the teaching style that fits you.</p>
      <div class="hero-actions">${button('Find a coach','#browse-coaches')}${button('Apply to teach','/coaches/apply/',true)}</div>
      <div class="hero-facts"><span>${coachingProviders.length} researched profiles</span><span>Personal · Academy · Video</span></div>
    </div><div class="coach-hero-note"><span>YOUR NEXT BREAKTHROUGH</span><p>A new skill.<br>A better game.</p></div>
  </section>
  <nav class="coach-tabs" aria-label="Coach Centre sections">
    <button type="button" class="active" data-directory-view="all" aria-pressed="true">Discover coaches</button>
    <button type="button" data-directory-view="saved" aria-pressed="false">Saved coaches <span id="saved-count">${saved.length}</span></button>
    <a href="#arena-lessons">NexArenaverse lessons</a><a href="#coaching-directories">More directories</a>
  </nav>
  <section id="browse-coaches" aria-label="Find a coach">
    <div class="coach-browser-heading"><div><p class="premium-kicker">YOUR COACH, YOUR WAY</p><h2>Explore the coaching world</h2></div>
      <a class="text-link" href="/coaches/apply/">Are you a coach? Join us</a></div>
    <p class="directory-explainer">These are public listings from coaches’ websites and teaching channels. Contact providers through their official pages for availability and prices. NexArenaverse lesson bookings appear separately below.</p>
    <form class="coach-search" id="directory-search" role="search">
      <label class="search-field">Search coaches<input name="q" type="search" placeholder="Name, skill, country or sport" maxlength="100" autocomplete="off"></label>
      <label>Sport<select name="sport">${options(sports.map(s=>[s,sportName(s)]),'All sports')}</select></label>
      <label>Teaching format<select name="delivery">${options(Object.entries(deliveryLabels),'All formats')}</select></label>
      <label>Coach type<select name="type">${options(Object.entries(typeLabels),'All types')}</select></label>
      <details class="more-coach-filters"><summary>More filters</summary><div>
        <label>Country<select name="country">${options([...new Set(coachingProviders.map(c=>c.country))].sort().map(c=>[c,c]),'All countries')}</select></label>
        <label>Sort by<select name="sort"><option value="">Sport, then name</option><option value="name">Name A–Z</option></select></label>
      </div></details>
      <button type="reset" class="reset-filters">Reset filters</button>
    </form>
    <div class="coach-results-bar"><p id="directory-results" role="status" aria-live="polite"></p><p id="shortlist-status" role="status" aria-live="polite"></p></div>
    <div id="coaching-provider-list" class="provider-grid"></div>
    <nav class="directory-pagination" id="directory-pagination" aria-label="Coach directory pages"></nav>
  </section>
  <section class="compare-panel" id="coach-comparison" hidden aria-label="Compare coaches"></section>
  <section id="arena-lessons" class="market-panel booking-panel"><p class="premium-kicker">BOOK THROUGH YOUR ARENA ACCOUNT</p>
    <h2>NexArenaverse live lessons</h2><p>Approved coaches publish available lesson times here. Each listed lesson is ${money(catalog.prices[currency])}. Arrange adult supervision for a child’s live lesson.</p>
    <div id="approved-coaches"><p role="status">Loading lesson times…</p></div>
    <div class="hero-actions">${button('Try a free sample booking','/test-checkout/?product=coaching',true)}${button('Apply to teach','/coaches/apply/',true)}</div>
  </section>
  <section class="market-panel" id="coaching-directories"><p class="premium-kicker">KEEP EXPLORING</p><h2>Coaching directories and local academies</h2>
    <p>Look for more providers and venues using these public directories. Each site manages its own listings and contact details.</p>
    <div class="directory-link-grid">${directories.map(d=>`<a href="${esc(d.url)}" target="_blank" rel="noopener noreferrer"><strong>${esc(d.name)}</strong><span>${esc(d.region)}</span></a>`).join('')}</div>
  </section>`;
  const form = app.querySelector('#directory-search');
  for (const key of Object.keys(filters)) {
    const field = form.elements.namedItem(key);
    field.value = filters[key];
    if (field.tagName === 'SELECT' && !field.value) filters[key] = '';
  }
  const list = app.querySelector('#coaching-provider-list');
  const pagination = app.querySelector('#directory-pagination');
  const status = app.querySelector('#shortlist-status');
  const initial = name => name.split(/\s+/).slice(0,2).map(word=>word[0]).join('').toUpperCase();
  const sourceLinks = coach => [
    [coach.website,coach.youtube === coach.website ? 'YouTube channel' : coach.tiktok === coach.website ? 'TikTok profile' : 'Official profile'],
    coach.youtube !== coach.website && [coach.youtube,'YouTube'],
    coach.tiktok !== coach.website && [coach.tiktok,'TikTok']
  ].filter(pair=>pair && pair[0]).map(([url,label])=>`<a class="source-link" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${label}</a>`).join('');
  const card = coach => `<article class="provider-card" data-sport="${coach.sport}">
    <div class="provider-cover"><span class="sport-label">${sportName(coach.sport)}</span><div class="provider-monogram" aria-hidden="true">${esc(initial(coach.name))}</div>
      <button class="save-coach" type="button" data-save="${coach.id}" aria-pressed="${saved.includes(coach.id)}" aria-label="${saved.includes(coach.id)?'Unsave':'Save'} ${esc(coach.name)}">${saved.includes(coach.id)?'Saved':'Save'}</button>
    </div>
    <div class="provider-content"><p class="provider-meta">${typeLabels[coach.type]} · ${esc(coach.country)}</p>
      <h3>${esc(coach.name)}</h3><p class="provider-focus">${esc(coach.focus)}</p>
      <div class="provider-formats">${coach.delivery.map(d=>'<span>'+deliveryLabels[d]+'</span>').join('')}</div>
      <div class="provider-actions"><button class="button compact secondary" type="button" data-profile="${coach.id}">View profile</button>
      <label class="compare-choice"><input type="checkbox" data-compare="${coach.id}" ${compared.includes(coach.id)?'checked':''}><span>Compare</span></label></div>
    </div></article>`;
  function updateUrl() {
    const values = new URLSearchParams(Object.entries(filters).filter(([,value])=>value));
    if (directoryView === 'saved') values.set('view','saved');
    history.replaceState(null,'',location.pathname + (values.size?'?'+values:'') + location.hash);
  }
  function renderComparison() {
    const section = app.querySelector('#coach-comparison');
    section.hidden = !compared.length;
    section.innerHTML = `<div class="comparison-heading"><div><p class="premium-kicker">YOUR SHORTLIST</p><h2>Compare ${compared.length} of 3 coaches</h2></div><button class="reset-filters" id="clear-comparison" type="button">Clear comparison</button></div><div class="compare-grid">${compared.map(id=>{
      const coach = coachingProviders.find(c=>c.id===id);
      return `<article><h3>${esc(coach.name)}</h3><p>${sportName(coach.sport)} · ${esc(coach.country)}</p><p>${esc(coach.focus)}</p><p>${coach.delivery.map(d=>deliveryLabels[d]).join(' · ')}</p>${sourceLinks(coach)}<button class="reset-filters" type="button" data-remove-compare="${id}">Remove</button></article>`;
    }).join('')}</div>`;
    section.querySelector('#clear-comparison').onclick = ()=>{compared=[];renderList();};
    section.querySelectorAll('[data-remove-compare]').forEach(button=>button.onclick=()=>{compared=compared.filter(id=>id!==button.dataset.removeCompare);renderList();});
  }
  function showProfile(id) {
    const coach = coachingProviders.find(c=>c.id===id);
    const dialog = document.querySelector('#market-dialog');
    document.querySelector('#dialog-content').innerHTML = `<p class="premium-kicker">${sportName(coach.sport)} · ${typeLabels[coach.type]}</p>
      <h2 id="dialog-title">${esc(coach.name)}</h2><p>${esc(coach.country)}</p><p>${esc(coach.focus)}</p>
      <p>${coach.delivery.map(d=>deliveryLabels[d]).join(' · ')}</p><div class="hero-actions">${sourceLinks(coach)}</div>
      ${coach.email?'<p><a href="mailto:'+encodeURIComponent(coach.email)+'">'+esc(coach.email)+'</a></p>':''}
      ${coach.phone?'<p><a href="tel:'+esc(coach.phone.replace(/[^+0-9]/g,''))+'">'+esc(coach.phone)+'</a></p>':''}
      ${coach.businessAddress?'<p>'+esc(coach.businessAddress)+'</p>':''}
      <p class="muted">Check lesson availability, prices and age requirements with the provider. Listing a public profile does not indicate a partnership.</p>
      <details><summary>Listing sources</summary><ul class="profile-sources">${coach.sources.map(s=>`<li><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.title)}</a></li>`).join('')}</ul>
      <small>Sources checked ${esc(coach.checkedAt)}. Contact details are shown where published for business enquiries.</small></details>`;
    dialog.showModal();
  }
  function renderList() {
    const found = filterCoaches(coachingProviders,{...filters,saved:directoryView==='saved'},saved);
    const pages = Math.max(1,Math.ceil(found.length/pageSize));
    page = Math.min(page,pages);
    const start = (page-1)*pageSize;
    app.querySelector('#directory-results').textContent = found.length ? `Showing ${start+1}–${Math.min(start+pageSize,found.length)} of ${found.length} profiles` : 'No coaches match your filters.';
    app.querySelector('#saved-count').textContent = saved.length;
    list.innerHTML = found.length ? found.slice(start,start+pageSize).map(card).join('') :
      '<div class="directory-empty"><h3>'+ (directoryView==='saved'?'Build your own coaching shortlist':'Try another search') +'</h3><p>'+ (directoryView==='saved'?'Tap Save on any coach to find them here later.':'Clear a filter or search for a different sport, name or skill.') +'</p></div>';
    pagination.innerHTML = pages>1 ? `<button type="button" class="button compact secondary" data-page="previous" ${page===1?'disabled':''}>Previous</button><span>Page ${page} of ${pages}</span><button type="button" class="button compact secondary" data-page="next" ${page===pages?'disabled':''}>Next</button>` : '';
    pagination.querySelectorAll('button').forEach(button=>button.onclick=()=>{
      page += button.dataset.page==='next'?1:-1;
      renderList();
      app.querySelector('#directory-results').scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
      list.querySelector('button')?.focus({preventScroll:true});
    });
    list.querySelectorAll('[data-profile]').forEach(button=>button.onclick=()=>showProfile(button.dataset.profile));
    list.querySelectorAll('[data-save]').forEach(button=>button.onclick=()=>{
      const id = button.dataset.save;
      saved = saved.includes(id) ? saved.filter(x=>x!==id) : [...saved,id];
      try { localStorage.setItem(storageKey,JSON.stringify(saved)); status.textContent='Shortlist saved on this device.'; }
      catch { status.textContent='Shortlist is available for this visit. Browser storage is unavailable.'; }
      renderList();
      list.querySelector('[data-save="'+id+'"]')?.focus();
    });
    list.querySelectorAll('[data-compare]').forEach(checkbox=>checkbox.onchange=()=>{
      const id=checkbox.dataset.compare;
      if (checkbox.checked && compared.length>=3) { checkbox.checked=false;status.textContent='Compare up to three coaches at a time.';return; }
      compared=checkbox.checked?[...compared,id]:compared.filter(x=>x!==id);
      status.textContent=compared.length?'Your comparison is below the coach list.':'';
      renderComparison();
    });
    renderComparison();
  }
  form.onsubmit = event=>event.preventDefault();
  form.oninput = event=>{
    if (!event.target.name) return;
    filters[event.target.name]=event.target.value;
    page=1;updateUrl();renderList();
  };
  form.onreset = event=>{
    event.preventDefault();
    for (const key of Object.keys(filters)) {filters[key]='';form.elements.namedItem(key).value='';}
    page=1;updateUrl();renderList();
  };
  const switchView = view => {
    directoryView=view;
    page=1;
    app.querySelectorAll('[data-directory-view]').forEach(button=>{
      const active=button.dataset.directoryView===view;
      button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
    });
    updateUrl();renderList();
  };
  app.querySelectorAll('[data-directory-view]').forEach(button=>button.onclick=()=>switchView(button.dataset.directoryView));
  switchView(query.get('view')==='saved'?'saved':'all');
  renderApprovedLessons(context);
}

async function renderApprovedLessons({app,api,esc,date,button,money,catalog,currency,purchase}) {
  const root = app.querySelector('#approved-coaches');
  try {
    const {coaches,sessions} = await api('coaches');
    if (!root.isConnected) return;
    if (!coaches.length) {
      root.innerHTML='<p class="note">Applications are open. Approved coach profiles and available lesson times will appear here.</p>';
      return;
    }
    root.innerHTML='<div class="market-grid">'+coaches.map(coach=>`<article class="market-card"><p class="premium-kicker">${esc(sportName(coach.sport))} · ${esc(coach.country)}</p>
      <h3>${esc(coach.name)}</h3><p>${esc(coach.bio)}</p><small>${esc(coach.languages)}</small>
      ${coach.business?'<div class="coach-contacts">'+[
        coach.business.email&&'<a href="mailto:'+encodeURIComponent(coach.business.email)+'">'+esc(coach.business.email)+'</a>',
        coach.business.phone&&'<a href="tel:'+esc(coach.business.phone.replace(/[^+0-9]/g,''))+'">'+esc(coach.business.phone)+'</a>',
        coach.business.address&&'<p>'+esc(coach.business.address)+'</p>',
        coach.business.website&&button('Coaching website',coach.business.website,true)
      ].filter(Boolean).join(' ')+'</div>':''}
      ${sessions.filter(s=>s.coach_id===coach.id).map(s=>`<div class="lesson"><h4>${esc(s.title)}</h4><p>${date(s.starts)} · ${s.duration} minutes</p><button type="button" class="button" data-lesson="${esc(s.id)}">Book lesson · ${money(catalog.prices[currency])}</button></div>`).join('')||'<p>No lesson times currently listed.</p>'}
    </article>`).join('')+'</div>';
    root.querySelectorAll('[data-lesson]').forEach(button=>button.onclick=()=>purchase('coaching',{session:button.dataset.lesson}));
  } catch {
    if (root.isConnected) root.innerHTML='<p>Lesson times could not load. You can still explore the public coach directory above.</p>';
  }
}
