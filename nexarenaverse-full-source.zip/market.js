import {serviceFetch, serviceOrigin, githubHosted, playerToken} from './service.js';
import {prices, sports, worlds} from './market-world-data.js';
import {renderDemo} from './market-demo.js';
import {showPlans, showWorld, showCoaches, showCoachApplication, showAdvertising} from './market-worlds.js';
import {renderPremiumLab} from './premium-labs.js';
import './data-saver.js';
const app=document.querySelector('#market-app');
const dialog=document.querySelector('#market-dialog');
const path = '/' + location.pathname.split('/').filter(Boolean).join('/') + '/';
const page = path.split('/')[1] || 'plus';
const world = Object.keys(worlds).find(key => worlds[key].path === path);
const isDemo = page === 'test-checkout';
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let currency=localStorage.getItem('na-market-currency')||'NGN';
if(!['NGN','USD','GBP'].includes(currency))currency='NGN';
let catalog = {prices, sports, checkout:{}, products:worlds};
let me = null;
const money=(amount,c=currency)=>({NGN:'₦',USD:'$',GBP:'£'}[c]||c)+new Intl.NumberFormat('en',{minimumFractionDigits:c==='NGN'&&amount%100===0?0:2,maximumFractionDigits:2}).format(amount/100);
const date=value=>new Date(value).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
async function api(path,data){const response=await serviceFetch('/api/market/'+path,{method:data?'POST':'GET',headers:{'Content-Type':'application/json','X-Player-Token':playerToken()},body:data?JSON.stringify(data):undefined});const body=await response.json();if(!response.ok){const e=Error(body.error||'Please try again.');e.status=response.status;throw e;}return body;}
function notice(text,error=false,root=app){let node=root.querySelector('[role="status"]');if(!node){node=document.createElement('p');node.role='status';root.append(node);}node.className='status'+(error?' error':'');node.textContent=text;}
function hero(eyebrow,title,description,actions=''){return `<section class="market-hero"><p class="eyebrow">${eyebrow}</p><h1>${title}</h1><p>${description}</p>${actions?'<div class="hero-actions">'+actions+'</div>':''}</section>`;}
function button(text,href,secondary=false){text=text.replace(/[←→↗]/g,'').trim();return `<a class="button ${secondary?'secondary':''}" href="${href}">${text}</a>`;}
function loggedOut(){return `<section class="market-panel"><h2>Bring your existing account.</h2><p>Connect your NexArenaverse account to keep purchases, coach bookings and enquiries together.</p><button class="button" data-connect>Sign in →</button><p role="status"></p></section>`;}
function bindConnect(){document.querySelectorAll('[data-connect]').forEach(b=>b.onclick=signIn);}
const signInPath = '/sign-in/?return_to=' + encodeURIComponent(location.pathname + location.search + location.hash);
function signIn() { location.assign(signInPath); }
document.querySelector('#market-signin').href = signInPath;
if (isDemo) document.querySelector('#market-signin').hidden = true;
document.querySelector('.dialog-close').onclick=()=>dialog.close();
dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});
function showDialog(html){document.querySelector('#dialog-content').innerHTML=html;dialog.showModal();}
async function submit(form,action){const b=form.querySelector('button[type="submit"]');if(b)b.disabled=true;try{await action(Object.fromEntries(new FormData(form)));}catch(error){notice(error.message,true,form);}finally{if(b)b.disabled=false;}}
function priceControl(){return `<div class="currency-bar"><div><h2>Choose your next level.</h2><small>Fixed regional prices. Choose one currency for each purchase.</small></div><label>Display currency<select id="market-currency"><option value="NGN">NGN · ₦1,500</option><option value="USD">USD · $2.00</option><option value="GBP">GBP · £1.50</option></select></label></div>`;}
function wireCurrency(){const select=document.querySelector('#market-currency');if(!select)return;select.value=currency;select.onchange=()=>{currency=select.value;localStorage.setItem('na-market-currency',currency);render();};}
function purchase(product,extra={}){
  if(!me){showDialog('<h2 id="dialog-title">Connect your account.</h2><p>Your purchase will belong to your signed-in NexArenaverse account.</p><button class="button" data-connect>Sign in →</button><p role="status"></p>');bindConnect();return;}
  const c=extra.currency||currency;
  if(product==='coaching'&&!extra.session){location.href='/coaches/';return;}
  const enabled=catalog.checkout[c];
  const price=extra.amount||catalog.prices[c];
  const name=product==='advertising'?'Your approved advertising quote':catalog.products[product].name;
  showDialog(`<p class="eyebrow">${enabled?'SECURE CHECKOUT':'EARLY ACCESS'}</p><h2 id="dialog-title">${esc(name)}</h2><div class="price">${money(price,c)}</div><p>${product==='advertising'?'For the dates set in your quote.':esc(catalog.products[product].period)}</p><p>${enabled?'Payment is confirmed by the server before access is added to your account.': 'Payments in this currency are being connected. Register your interest and keep playing while we prepare launch.'}</p><form id="purchase-form">${!enabled?'<label>Your name<input name="name" autocomplete="name" required maxlength="80"></label>':''}<label>Email for this ${enabled?'payment':'request'}<input type="email" name="email" autocomplete="email" required maxlength="160"></label><button type="submit" class="button">${enabled?'Continue to payment →':'Register my interest →'}</button><p role="status"></p></form>`);
  const form=document.querySelector('#purchase-form');form.onsubmit=e=>{e.preventDefault();submit(form,async data=>{
    if(enabled){const result=await api('checkout',{product,currency:c,email:data.email,...extra});location.assign(result.url);}
    else if(product==='advertising'){notice('Live checkout is pending setup. Try the sample quote from the Advertising Studio.',false,form);}
    else{const result=await api('enquiry',{...data,kind:'interest',product,currency:c});notice(result.message,false,form);}
  });};
}
async function account(){
  if(!me){app.innerHTML=hero('YOUR NEXARENAVERSE ACCOUNT','All your extras, together.','Manage paid benefits, enquiries, coach lessons and your Circle.')+loggedOut();bindConnect();return;}
  app.innerHTML=hero('MY ACCOUNT','Your arena, connected.','Find your purchases, save supported practice progress and manage your lessons.',button('Explore plans','/plus/',true))+`<div class="market-grid"><article class="market-card"><span class="tag">ARENA PLUS</span><h2>${me.premium?'Active on your account':'Ready when you are'}</h2><p>${me.premium?'Cloud saves and Plus training tools are available below.':'Choose a Plus pass or join an active Circle.'}</p>${button('View plans','/plus/',true)}</article><article class="market-card"><span class="tag">PRISM DESIGN PACK</span><h2>${me.design?'Your designs are unlocked':'A new look awaits'}</h2><p>Aurora, Obsidian and Solstice palettes for supported local boards.</p>${me.design?'<button class="button" id="open-pack">Choose my designs →</button>':button('Explore the pack','/plus/',true)}</article><article class="market-card"><span class="tag">FAMILY & SCHOOL CIRCLE</span><h2>Bring your group.</h2><p>Manage an active five-seat Circle or join with your organiser’s invite code.</p><button class="button" id="open-group">Open Circle controls →</button></article></div><div id="account-tools"></div><section class="market-panel"><h2>Your coach lessons.</h2>${me.bookings.length?me.bookings.map(b=>`<article class="lesson"><h3>${esc(b.title)}</h3><p>${date(b.starts)} · ${b.duration} minutes</p><a class="button" href="${esc(b.meeting)}" target="_blank" rel="noopener noreferrer">Open private lesson link ↗</a></article>`).join(''):'<p>Available lessons and reviewed coach profiles appear in Coach Corner.</p>'+button('Find a coach','/coaches/',true)}</section>${requestList()}<section class="market-panel"><h2>Purchases and passes.</h2>${me.orders.length?'<div class="table-wrap"><table><tr><th>Purchase</th><th>Amount</th><th>Status</th><th>Access ends</th><th></th></tr>'+me.orders.map(o=>`<tr><td>${esc(catalog.products[o.product]?.name||'Advertising')}</td><td>${money(o.amount,o.currency)}</td><td>${esc(o.status)}</td><td>${o.expires?date(o.expires):'—'}</td><td>${o.status==='pending'?'<button class="button compact" data-verify="'+o.reference+'">Check payment</button>':''}</td></tr>`).join('')+'</table></div>':'<p>Your verified purchases will appear here.</p>'}</section><p role="status"></p>`;
  if(me.premium)plusTools();
  document.querySelector('#open-group').onclick=groupTools;
  if(me.design)document.querySelector('#open-pack').onclick=packTools;
  document.querySelectorAll('[data-verify]').forEach(b=>b.onclick=async()=>{b.disabled=true;try{const r=await api('verify',{reference:b.dataset.verify});if(r.paid){await loadMe();await account();}else notice('Payment is still pending. Complete your provider checkout or check again shortly.');}catch(e){notice(e.message,true);}finally{b.disabled=false;}});
  document.querySelectorAll('[data-quote]').forEach(b=>{const r=me.applications.find(x=>x.id===b.dataset.quote);b.onclick=()=>purchase('advertising',{quote:r.id,amount:r.quote,currency:r.currency});});
  if(me.applications.some(a=>a.kind==='coach'&&a.status==='approved'))sessionTools();
}
function requestList(){return '<section class="market-panel"><h2>Your enquiries and applications.</h2>'+(me.applications.length?me.applications.map(a=>`<article class="lesson"><span class="tag">${esc(a.kind)} · ${esc(a.status)}</span><h3>${esc(a.details.brand||a.details.name)}</h3>${a.note?'<p>'+esc(a.note)+'</p>':''}${a.kind==='advertising'&&a.quote?'<p>'+money(a.quote,a.currency)+' · '+date(a.starts)+' – '+date(a.ends)+'</p>':''}${a.kind==='advertising'&&a.status==='quoted'?'<button class="button" data-quote="'+a.id+'">Accept quote and pay →</button>':''}</article>`).join(''):'<p>Coach applications, advertising enquiries and launch-list requests appear here.</p>')+'</section>';}
function plusTools(){
  const read=(key)=>{try{return JSON.parse(localStorage.getItem(key)||'{}');}catch{return {};}};
  const victories=Object.values(read('ma-scores')).reduce((sum,value)=>sum+(Number(value)||0),0);
  document.querySelector('#account-tools').innerHTML='<section class="market-panel"><p class="eyebrow">YOUR PRACTICE SUMMARY · THIS DEVICE</p><div class="market-grid"><div><div class="price">'+victories+'</div><p>Recorded practice wins</p></div><div><div class="price">'+Object.keys(read('na-education-progress')).length+'</div><p>Learning games with saved progress</p></div><div><div class="price">'+Object.keys(read('na-kids-progress')).length+'</div><p>Children’s games with saved progress</p></div></div></section>';
  document.querySelector('#account-tools').insertAdjacentHTML('beforeend','<section class="market-panel"><p class="eyebrow">ARENA PLUS · CLOUD SAVE</p><h2>Take your practice with you.</h2><p>Save supported practice scores, learning progress and appearance preferences. Restoring replaces those saved items on this device.</p><div class="hero-actions"><button class="button" id="cloud-save">Save this device →</button><button class="button secondary" id="cloud-restore">Restore my cloud save →</button></div><p id="backup-status" role="status"></p></section><section class="market-panel"><p class="eyebrow">PLUS TRAINING PLANS</p><h2>A little structure for your next session.</h2><p>Use these self-reported practice plans. Tick a plan after completing the activities.</p>'+['Play a chess practice game, then review five moves.','Complete a maths round and read every explanation.','Work through a football or basketball skill tutorial.','Play one reaction game and one sports knowledge challenge.','Try Word Builder, Word Links and Grammar Quest.','Finish a memory game, a pattern puzzle and a Sudoku.'].map((m,i)=>'<label class="check mission-check"><input type="checkbox" data-mission="'+i+'"><span>'+m+'</span></label>').join('')+'</section>');
  let missions={};try{missions=JSON.parse(localStorage.getItem('na-plus-missions')||'{}');}catch{}
  document.querySelectorAll('[data-mission]').forEach(b=>{b.checked=!!missions[b.dataset.mission];b.onchange=()=>{missions[b.dataset.mission]=b.checked;localStorage.setItem('na-plus-missions',JSON.stringify(missions));};});
  const root=document.querySelector('#cloud-save').closest('section');
  document.querySelector('#cloud-save').onclick=async()=>{try{const keys=['ma-game-prefs','ma-background','ma-motion','ma-journey','ma-scores','ma-openings','ma-done','na-kids-progress','na-education-progress','na-plus-missions','na-premium-labs','na-arena-looks','na-data-saver','na-adventure-mode','na-premium-world-tools','na-world-atmosphere'];const data=Object.fromEntries(keys.map(k=>[k,localStorage.getItem(k)]).filter(([,v])=>v!==null));await api('backup',data);notice('Cloud save updated for your account.',false,root);}catch(e){notice(e.message,true,root);}};
  document.querySelector('#cloud-restore').onclick=async()=>{try{const data=await api('backup');if(!data.backup){notice('You do not have a cloud save yet.',false,root);return;}showDialog('<h2 id="dialog-title">Restore your saved practice?</h2><p>This replaces the supported practice data and preferences on this device with your cloud save from '+date(data.updated)+'.</p><button class="button" id="confirm-restore">Restore this save →</button>');document.querySelector('#confirm-restore').onclick=()=>{for(const[k,v]of Object.entries(data.backup))localStorage.setItem(k,v);dialog.close();notice('Save restored. Open a game to continue.',false,root);};}catch(e){notice(e.message,true,root);}};
}
async function packTools(){try{const {themes}=await api('pack');showDialog('<h2 id="dialog-title">Your Prism designs.</h2><p>Choose a palette for your next supported local game.</p>'+Object.entries(themes).map(([name,t])=>`<article class="market-panel"><div class="swatch-board" style="--light:${t.colors[0]};--dark:${t.colors[1]}"></div><h3>${name}</h3><button class="button" data-pack="${name}">Apply ${name} →</button></article>`).join('')+'<p role="status"></p>');document.querySelectorAll('[data-pack]').forEach(b=>b.onclick=()=>{let prefs={};try{prefs=JSON.parse(localStorage.getItem('ma-game-prefs')||'{}');}catch{}localStorage.setItem('ma-game-prefs',JSON.stringify({...prefs,style:b.dataset.pack}));const looks={Aurora:{color:'#102e40',pattern:'stars'},Obsidian:{color:'#211b32',pattern:'velvet'},Solstice:{color:'#392337',pattern:'grid'}};localStorage.setItem('ma-background',JSON.stringify({name:b.dataset.pack,...looks[b.dataset.pack]}));notice(b.dataset.pack+' selected. Open a local game to use your design.',false,dialog);});}catch(e){notice(e.message,true);}}
async function groupTools(){try{const g=await api('group');showDialog('<h2 id="dialog-title">Your Circle.</h2>'+(g.own?'<h3>'+esc(g.own.name)+'</h3><p>'+(g.active?'Your invite code':'Circle pass expired')+'</p><p class="join-code">'+(g.active?esc(g.own.code):'Renew to invite')+'</p><p>'+g.members.length+' / 4 invited seats used, plus your organiser seat.</p>'+g.members.map(m=>'<p>'+esc(m.alias)+' <button class="button compact secondary" data-remove="'+esc(m.player)+'">Remove</button></p>').join(''):me.group?'<form id="circle-create"><label>Name your Circle<input name="name" minlength="3" maxlength="80" required></label><button type="submit" class="button">Create my Circle →</button><p role="status"></p></form>':'<p>An active Circle pass lets the organiser invite four more accounts.</p>')+(g.joined?'<p>You joined '+esc(g.joined.name)+'.</p><button id="circle-leave" class="button secondary">Leave Circle</button>':'<form id="circle-join"><h3>Have an invite code?</h3><label>Your display name<input name="alias" minlength="2" maxlength="40" required></label><label>Circle code<input name="code" minlength="12" maxlength="12" required autocomplete="off"></label><button type="submit" class="button">Join Circle →</button><p role="status"></p></form>')+'<p role="status"></p>');for(const [id,action]of [['circle-create','create'],['circle-join','join']]){const form=document.getElementById(id);if(form)form.onsubmit=e=>{e.preventDefault();submit(form,async data=>{await api('group',{...data,action});await loadMe();dialog.close();await account();await groupTools();});};}document.querySelectorAll('[data-remove]').forEach(b=>b.onclick=async()=>{try{await api('group',{action:'remove',player:b.dataset.remove});await groupTools();}catch(e){notice(e.message,true,dialog);}});const leave=document.querySelector('#circle-leave');if(leave)leave.onclick=async()=>{try{await api('group',{action:'leave'});await loadMe();dialog.close();await account();}catch(e){notice(e.message,true,dialog);}};}catch(e){notice(e.message,true);}}
function sessionTools(){app.insertAdjacentHTML('beforeend',`<section class="market-panel"><p class="eyebrow">APPROVED COACH DASHBOARD</p><h2>Publish an available lesson.</h2><form id="session-form"><div class="form-grid"><label>Lesson title<input name="title" minlength="6" maxlength="90" required></label><label>Your local date and time<input name="starts" type="datetime-local" required></label><label>Duration<select name="duration"><option value="20">20 minutes</option><option value="30">30 minutes</option><option value="45">45 minutes</option><option value="60">60 minutes</option></select></label><label>Private meeting link<input type="url" name="meeting" placeholder="https://…" required></label><label class="check form-wide"><input type="checkbox" name="terms" required><span>I can deliver this lesson at the listed fixed price of $2, ₦1,500 or £1.50 under the delivery and payout terms agreed with the owner.</span></label></div><button class="button" type="submit">Publish lesson time →</button><p role="status"></p></form><h3>Your published lesson times.</h3>${me.mySessions.map(s=>'<p>'+esc(s.title)+' · '+date(s.starts)+' · '+esc(s.status)+'</p>').join('')||'<p>No lesson times published yet.</p>'}</section>`);const form=document.querySelector('#session-form');form.onsubmit=e=>{e.preventDefault();submit(form,async d=>{await api('sessions',{...d,starts:new Date(d.starts).toISOString(),terms:form.terms.checked});await loadMe();await account();});};}
async function completed(){app.innerHTML=hero('PAYMENT CONFIRMATION','Let’s check your purchase.','Your payment provider confirms the amount, currency and transaction before we unlock access.')+(me?'<section class="market-panel"><p role="status">Checking payment…</p></section>':loggedOut());bindConnect();if(!me)return;try{const reference=new URLSearchParams(location.search).get('reference');if(!reference)throw Error('No payment reference was provided. Open My account to check your purchases.');const result=await api('verify',{reference});app.innerHTML=hero('PAYMENT CONFIRMATION',result.paid?'Your purchase is confirmed.':'Your payment is still pending.',result.paid?'Open your account to use your new benefits.':'Finish your payment provider checkout, then check again from My account.',button('Open My account →','/account/'));}catch(e){notice(e.message,true);}}
async function ownerDesk(){
  if(githubHosted){app.innerHTML=hero('OWNER DESK','Manage the arena.','Review coach applications and set your own advertising quotes from the protected owner account.',button('Open protected owner desk ↗',serviceOrigin+'/owner/'));return;}
  if(!me){app.innerHTML=hero('OWNER DESK','Sign in as the website owner.','The owner account can review applications and set advertising prices.')+loggedOut();bindConnect();return;}
  const data=await api('admin');
  app.innerHTML=hero('OWNER DESK','Your partners. Your decisions.','Review coach experience and agree teaching terms before publishing a profile. Set each advertising quote yourself.')+'<section class="market-panel"><h2>Payment connections.</h2><p>'+Object.entries(data.checkout).map(([c,ok])=>c+' · '+(ok?'connected':'awaiting payment provider')).join(' / ')+'</p><p>The server needs a live Paystack connection for NGN, approved USD collection for dollars, and a GBP-capable connection for pounds. Provider secrets stay on the server.</p></section>'+data.requests.map(r=>`<section class="market-panel"><span class="tag">${esc(r.kind)} · ${esc(r.status)}</span><h2>${esc(r.details.brand||r.details.name)}</h2><p>Private contact · ${esc(r.details.email)}</p>${Object.entries(r.details).filter(([k])=>!['name','brand','email'].includes(k)).map(([k,v])=>'<p class="request-detail"><b>'+esc(k)+'</b><br>'+esc(v)+'</p>').join('')}<form class="review-form" data-id="${r.id}"><div class="review-grid"><label>Action<select name="status">${(r.kind==='coach'?['approved','declined','paused']:r.kind==='advertising'?['quoted','declined','paused','closed']:['closed']).map(s=>'<option>'+s+'</option>').join('')}</select></label>${r.kind==='advertising'?'<label>Price you choose<input name="amount" type="number" min="1" step="0.01" value="'+(r.quote?r.quote/100:'')+'"></label><label>Currency<select name="currency"><option>NGN</option><option>USD</option><option>GBP</option></select></label><label>Campaign starts<input name="starts" type="datetime-local"></label><label>Campaign ends<input name="ends" type="datetime-local"></label>':''}<label class="form-wide">Private note to the applicant<textarea name="note" maxlength="600">${esc(r.note||'')}</textarea></label></div><button class="button" type="submit">Save decision →</button><p role="status"></p></form></section>`).join('')+(data.requests.length?'':'<div class="empty-state"><h2>Your inbox is ready.</h2><p>Coach applications and advertising enquiries will appear here.</p></div>');
  document.querySelectorAll('.review-form').forEach(form=>form.onsubmit=e=>{e.preventDefault();submit(form,async d=>{const body={...d,id:form.dataset.id};if(d.starts)body.starts=new Date(d.starts).toISOString();if(d.ends)body.ends=new Date(d.ends).toISOString();await api('review',body);await ownerDesk();});});
}
async function loadMe(){try{me=await api('me');document.querySelector('#market-signin').textContent='My account';document.querySelector('#market-signin').href='/account/';}catch(e){if(e.status!==401)throw e;me=null;document.querySelector('#market-signin').textContent='Sign in';document.querySelector('#market-signin').href=signInPath;}}
async function render() {
  app.className = '';
  const context = {app, hero, button, money, catalog, currency, priceControl, wireCurrency, purchase,
    api, esc, date, me, loggedOut, bindConnect, submit, notice};
  try {
    if (isDemo) renderDemo(context);
    else if (path === '/coaches/apply/') showCoachApplication(context);
    else if (page === 'coaches') showCoaches(context);
    else if (page === 'advertise') showAdvertising(context);
    else if (page === 'account') await account();
    else if (page === 'owner') await ownerDesk();
    else if (page === 'purchase-complete') await completed();
    else if (renderPremiumLab(path,context)) {}
    else if (world) showWorld(world, context);
    else showPlans(context);
    document.querySelectorAll('.market-header nav a').forEach(a => {
      if (a.getAttribute('href') === '/' + page + '/') a.setAttribute('aria-current', 'page');
    });
  } catch (error) {
    notice(error.message, true);
  }
}
async function refreshAccount() {
  try { await loadMe(); }
  catch { if (['owner','account','purchase-complete'].includes(page)) notice('Your account could not load. Please retry.', true); }
}
if (!isDemo) {
  window.addEventListener('storage', async event => {
    if (event.key !== 'na-account-session') return;
    await refreshAccount();
    if (dialog.open) dialog.close();
    await render();
  });
  try { catalog = await api('catalog'); } catch {}
  await refreshAccount();
}
await render();
