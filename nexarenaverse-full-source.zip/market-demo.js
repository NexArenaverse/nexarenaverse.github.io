import {paymentMethods, prices, worlds, designPreviews} from './market-world-data.js';
import {adForm, coachForm} from './market-forms.js';

const query = new URLSearchParams(location.search);
const product = Object.hasOwn(worlds, query.get('product')) ? query.get('product') : 'premium';
const world = worlds[product];
const application = query.get('flow') === 'application' && ['coaching', 'advertising'].includes(product);
const sampleQuotes = {NGN: 2500000, USD: 2500, GBP: 2000};
const choices = {success: 'Approved', pending: 'Pending', declined: 'Declined'};

const samples = {
  coaching: {
    name:'Sample Coach', email:'coach@example.com', phone:'+1 202 555 0100', country:'Nigeria',
    sport:'basketball', languages:'English', credentials:'https://example.com/coach', offer:'both',
    tutorialTitle:'Change of pace for beginners', tutorialUrl:'https://example.com/tutorial',
    bio:'I help beginners build confident footwork and ball control.',
    experience:'Sample experience includes several seasons teaching beginner sessions.',
    terms:'I would like to offer short drills, video tutorials and live feedback.', adult:true, consent:true
  },
  advertising: {
    name:'Sample Advertiser', email:'advertiser@example.com', phone:'+1 202 555 0101',
    brand:'Example Sports Gear', productName:'Training cones', url:'https://example.com/product',
    placement:'sports', method:'bank_transfer', audience:'Sports Academy learners',
    message:'We would like to introduce our training cones in a sample one-week campaign.'
  }
};

export function boardPreview(name) {
  const design = designPreviews[name];
  return `<div class="board-stage" style="--board-backdrop:${design.backdrop}"><div class="prism-board" role="img" aria-label="${name} chessboard preview" style="--light:${design.light};--dark:${design.dark};--edge:${design.edge}"><span aria-hidden="true">♜ ♞ ♝ ♚<br>♙ ♙ ♙ ♙</span></div></div>`;
}

export function bindDesignPreview(root) {
  const select = root.querySelector('[data-preview-design]');
  if (select) select.onchange = () => {
    root.querySelector('[data-board-stage]').innerHTML = boardPreview(select.value);
  };
}

export function designPicker() {
  return `<label>Board design<select data-preview-design>${Object.keys(designPreviews).map(n => `<option>${n}</option>`).join('')}</select></label><div data-board-stage>${boardPreview('Aurora')}</div>`;
}

export function circleSeats() {
  return `<ul class="circle-seats" aria-label="Five Circle seats"><li>Organiser</li>${[1,2,3,4].map(n => `<li>Guest ${n}</li>`).join('')}</ul>`;
}

function demoOutcome() {
  if (product === 'design') return designPicker();
  if (product === 'group') return circleSeats();
  if (product === 'premium') return '<label class="check mission-check"><input type="checkbox"><span>Sample practice mission · Complete three chess puzzles</span></label>';
  if (product === 'coaching') return '<p class="note">Sample booking · 30-minute basketball footwork lesson · Online</p>';
  return '<p class="note">Sample campaign · Example Sports Gear · Sports Academy · 7 days</p>';
}

export function renderDemo({app, hero, button, money, currency}) {
  let state = {currency, method:'card', result:'success'};
  const header = hero('TEST MODE · NO REAL MONEY', 'Test ' + world.name,
    'Try the flow with sample information. No account, card number or bank details are needed.',
    button('← Back to ' + world.heading, world.path, true));
  const show = content => {
    app.dataset.world = world.accent;
    app.innerHTML = header + '<section class="market-panel sandbox-panel">' + content + '</section>';
  };
  const changeStep = content => {
    show(content);
    const heading = app.querySelector('.sandbox-panel h2');
    heading.tabIndex = -1;
    heading.focus();
  };
  function applicationStep() {
    const formHtml = product === 'coaching' ? coachForm('demo-form', true) : adForm('demo-form', true);
    show(`<h2>${product === 'coaching' ? 'Practice a coach application' : 'Practice an advertising request'}</h2>
      <p>Sample details are filled in for you. This form stays in this browser tab and sends nothing to the owner.</p>${formHtml}`);
    const form = app.querySelector('#demo-form');
    for (const [name, value] of Object.entries(samples[product])) {
      const field = form.elements.namedItem(name);
      if (field.type === 'checkbox') field.checked = value;
      else field.value = value;
    }
    form.onsubmit = event => {
      event.preventDefault();
      changeStep(product === 'coaching'
        ? '<h2>Sample application received</h2><p>A real submission would appear in My account for the owner to review. The tutorial sample and private contact details would go to the owner.</p><button type="button" class="button secondary" id="restart-test">Try again</button>'
        : '<h2>Sample campaign request received</h2><p>A real campaign needs a quote from the owner. For this test, a sample quote is ready now.</p><button type="button" class="button" id="sample-quote">Open sample quote →</button> <button type="button" class="button secondary" id="restart-test">Try again</button>');
      app.querySelector('#restart-test').onclick = applicationStep;
      const quote = app.querySelector('#sample-quote');
      if (quote) quote.onclick = () => { state.method = 'bank_transfer'; checkoutStep(true); };
    };
  }
  function checkoutStep(moveFocus = false) {
    const display = moveFocus ? changeStep : show;
    display(`<h2>Choose a test payment</h2><p>${product === 'advertising' ? 'This is a sample price. The owner sets all live campaign prices.' : 'The price below is shown for practice. The test charge is zero.'}</p>
      <form id="demo-payment"><div class="form-grid">
      <label>Currency<select name="currency">${Object.keys(prices).map(c => `<option>${c}</option>`).join('')}</select></label>
      <label>Payment method<select name="method"></select></label>
      <label class="form-wide">Simulate a result<select name="result">${Object.entries(choices).map(([id,label]) => `<option value="${id}">${label}</option>`).join('')}</select></label>
      </div><div class="demo-total" aria-live="polite"></div><button class="button" type="submit">Review test payment →</button></form>`);
    const form = app.querySelector('#demo-payment');
    const fields = form.elements;
    fields.currency.value = state.currency;
    fields.result.value = state.result;
    const setMethods = () => {
      const current = fields.method.value || state.method;
      const available = fields.currency.value === 'NGN' ? Object.entries(paymentMethods) : [['card',paymentMethods.card]];
      fields.method.innerHTML = available.map(([id,label]) => `<option value="${id}">${label}</option>`).join('');
      if (available.some(([id]) => id === current)) fields.method.value = current;
      const c = fields.currency.value;
      const amount = (product === 'advertising' ? sampleQuotes : prices)[c];
      app.querySelector('.demo-total').innerHTML = `<span>Sample amount <strong>${money(amount,c)}</strong></span><span>Actual charge <strong>${money(0,c)}</strong></span>`;
    };
    fields.currency.onchange = setMethods;
    setMethods();
    form.onsubmit = event => {
      event.preventDefault();
      state = Object.fromEntries(new FormData(form));
      reviewStep();
    };
  }
  function reviewStep() {
    const instructions = {
      card: 'The demo will simulate card authorisation without asking for a card number.',
      bank_transfer: 'The demo will simulate a bank transfer confirmation. There is no account to send money to.',
      ussd: 'The demo will simulate a USSD response. You do not need to dial a code.'
    };
    changeStep(`<h2>Review your test payment</h2><p>${instructions[state.method]}</p>
      <dl class="demo-summary"><div><dt>Product</dt><dd>${world.name}</dd></div><div><dt>Method</dt><dd>${paymentMethods[state.method]}</dd></div>
      <div><dt>Simulated result</dt><dd>${choices[state.result]}</dd></div><div><dt>Actual charge</dt><dd>${money(0,state.currency)}</dd></div></dl>
      <div class="hero-actions"><button type="button" class="button" id="run-test">Run test payment →</button><button type="button" class="button secondary" id="edit-test">Change test details</button></div>`);
    app.querySelector('#run-test').onclick = receiptStep;
    app.querySelector('#edit-test').onclick = () => checkoutStep(true);
  }
  function receiptStep() {
    const messages = {
      pending: 'A live order would wait for a verified payment before anything is unlocked.',
      declined: 'The simulated payment was declined. You can retry with a different method or result.'
    };
    const success = state.result === 'success';
    const reference = 'TEST-' + crypto.randomUUID().slice(0,8).toUpperCase();
    changeStep(`<p class="eyebrow">SIMULATED RECEIPT</p><h2>Test payment ${choices[state.result].toLowerCase()}</h2>
      <p>${success ? world.demo : messages[state.result]}</p>
      <dl class="demo-summary"><div><dt>Test reference</dt><dd>${reference}</dd></div><div><dt>Method</dt><dd>${paymentMethods[state.method]}</dd></div><div><dt>Amount charged</dt><dd>${money(0,state.currency)}</dd></div></dl>
      ${success ? demoOutcome() : ''}
      <div class="hero-actions"><button type="button" class="button secondary" id="retry-test">Try another test</button>${button('Return to ' + world.heading,world.path,true)}</div>`);
    bindDesignPreview(app);
    app.querySelector('#retry-test').onclick = () => checkoutStep(true);
  }
  if (application) applicationStep();
  else checkoutStep();
}
