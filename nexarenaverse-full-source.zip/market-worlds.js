import {directories, worlds, sports} from './market-world-data.js';
import {adForm, coachForm} from './market-forms.js';
import {bindDesignPreview, circleSeats, designPicker} from './market-demo.js';

export function testPath(product, application = false) {
  return '/test-checkout/?product=' + product + (application ? '&amp;flow=application' : '');
}

const sportLabel = value => value.replaceAll('-', ' ');
const asList = entries => '<ul>' + entries.map(([label, detail]) => `<li><strong>${label}</strong> · ${detail}</li>`).join('') + '</ul>';

export function showPlans({app, hero, button, priceControl, wireCurrency, money, catalog, currency}) {
  delete app.dataset.world;
  app.innerHTML = hero('NEXARENAVERSE PREMIUM', 'Choose your next world.',
    'Explore practice tools, private groups, new boards, coaching and advertising. Each world has a free test you can try before payments are connected.',
    button('Explore the worlds', '#premium-worlds') + button('My account', '/account/', true)) +
    `<section id="premium-worlds">${priceControl()}<div class="market-grid worlds-grid">${Object.entries(worlds).map(([id,w]) =>
      `<article class="market-card world-card" data-world="${w.accent}"><p class="eyebrow">${w.label}</p><h2>${w.heading}</h2><p>${w.summary}</p>
      <p class="world-price">${id === 'advertising' ? 'Request a quote' : money(catalog.prices[currency])} <small>· ${w.period}</small></p>
      ${button('Explore ' + w.heading + ' →', w.path)}</article>`).join('')}</div></section>`;
  wireCurrency();
}

export function showWorld(product, {app, hero, button, money, catalog, currency, priceControl, wireCurrency, purchase}) {
  const w = worlds[product];
  app.dataset.world = w.accent;
  const preview = product === 'design' ? designPicker()
    : product === 'group' ? circleSeats()
    : '<label class="check mission-check"><input type="checkbox"><span>Sample mission · Complete three chess puzzles</span></label>';
  const previewName = {design:'Preview your board', group:'Your five Circle seats', premium:'Try a sample mission'}[product];
  app.innerHTML = hero(w.label, w.heading, w.summary,
    button('Try free test checkout →', testPath(product)) + button('← All premium worlds', '/plus/', true)) +
    `<div class="world-layout"><section class="market-panel"><h2>What you get</h2>${asList(w.highlights)}
      ${priceControl()}<div class="price">${money(catalog.prices[currency])}</div><p class="period">${w.period}</p>
      <button class="button secondary" id="live-buy" type="button">${catalog.checkout[currency] ? w.action : 'Register purchase interest'} →</button>
      <p class="muted">${catalog.checkout[currency] ? 'Live access starts after payment is verified.' : 'Live checkout for this currency is pending setup.'}</p>
    </section><section class="market-panel"><h2>${previewName}</h2>${preview}</section></div>`;
  app.querySelector('#live-buy').onclick = () => purchase(product);
  wireCurrency();
  bindDesignPreview(app);
}

export function showCoaches({app, hero, button, api, esc, date, money, catalog, currency, purchase}) {
  const w = worlds.coaching;
  app.dataset.world = w.accent;
  app.innerHTML = hero(w.label, w.heading, w.summary, button('Find a coach', '#find-coaches') +
    button('Apply to teach →', '/coaches/apply/', true) + button('Try a sample booking', testPath('coaching'), true)) +
    `<section id="find-coaches" class="market-panel"><h2>Find a coach</h2>
      <div class="filter-row"><label>Sport<select id="coach-sport"><option value="">All sports</option>${sports.map(s => `<option value="${s}">${sportLabel(s)}</option>`).join('')}</select></label>
      <label>Name, country or language<input id="coach-search" type="search" placeholder="Search approved coaches"></label></div>
      <p>Book available NexArenaverse lessons for ${money(catalog.prices[currency])} each. Arrange adult supervision for a child’s live lesson.</p>
      <div id="coach-list" aria-live="polite"></div></section>
    <section class="market-panel" id="external-directory"><h2>Public coaching directories and academies</h2><p>Open a directory to choose a coach or find a local training venue. Check its listings for public addresses, email and phone details. External lessons are arranged on those sites.</p><div class="market-grid" id="directory-list"></div></section>`;
  const list = app.querySelector('#coach-list');
  const search = app.querySelector('#coach-search');
  const sport = app.querySelector('#coach-sport');
  const external = app.querySelector('#directory-list');
  let data, failed = false;
  const render = () => {
    const filteredDirectories = directories.filter(d => !sport.value || d.sports.includes(sport.value));
    external.innerHTML = filteredDirectories.map(d => `<article class="market-card directory-card"><span class="tag">${d.region}</span><h3>${d.name}</h3><p>${d.detail}</p>${button('Open directory ↗', d.url, true)}</article>`).join('');
    if (!data) {
      list.innerHTML = failed ? '<p>Approved coach profiles could not load. You can still use the public directories below.</p>' : '<p role="status">Loading NexArenaverse coach profiles…</p>';
      return;
    }
    const term = search.value.trim().toLowerCase();
    const filtered = data.coaches.filter(c => (!sport.value || c.sport === sport.value) &&
      [c.name, c.country, c.languages].join(' ').toLowerCase().includes(term));
    if (!filtered.length) {
      list.innerHTML = '<p class="note">' + (data.coaches.length ? 'No approved profiles match these filters.' : 'Approved NexArenaverse coaches will appear here as their profiles are reviewed.') + '</p>';
      return;
    }
    const contacts = c => {
      if (!c.business) return '';
      const {email, phone, address, website} = c.business;
      return `<ul class="coach-contacts">${[
        address && esc(address),
        email && `<a href="mailto:${encodeURIComponent(email)}">${esc(email)}</a>`,
        phone && `<a href="tel:${esc(phone.replace(/[^+0-9]/g,''))}">${esc(phone)}</a>`,
        website && `<a href="${esc(website)}" rel="noopener noreferrer">Coaching website ↗</a>`
      ].filter(Boolean).map(x => '<li>' + x + '</li>').join('')}</ul>`;
    };
    const sessionsByCoach = new Map();
    for (const session of data.sessions) {
      if (!sessionsByCoach.has(session.coach_id)) sessionsByCoach.set(session.coach_id, []);
      sessionsByCoach.get(session.coach_id).push(session);
    }
    list.innerHTML = '<div class="market-grid">' + filtered.map(c => `<article class="market-card"><div class="coach-avatar" aria-hidden="true">${esc(c.name.slice(0,1))}</div>
      <h3>${esc(c.name)}</h3><span class="tag">${esc(sportLabel(c.sport))} · ${esc(c.country)}</span><p>${esc(c.bio)}</p><small>${esc(c.languages)}</small>${contacts(c)}
      ${(sessionsByCoach.get(c.id)||[]).map(s => `<div class="lesson"><h4>${esc(s.title)}</h4><p>${date(s.starts)} · ${s.duration} minutes</p>
      <button class="button" data-lesson="${esc(s.id)}">Book lesson · ${money(catalog.prices[currency])}</button></div>`).join('') || '<p>No lesson times currently listed.</p>'}</article>`).join('') + '</div>';
    list.querySelectorAll('[data-lesson]').forEach(b => b.onclick = () => purchase('coaching', {session:b.dataset.lesson}));
  };
  sport.onchange = search.oninput = render;
  render();
  api('coaches').then(result => { data = result; render(); }, () => { failed = true; render(); });
}

export function showCoachApplication({app, hero, button, me, loggedOut, bindConnect, submit, api, notice}) {
  app.dataset.world = worlds.coaching.accent;
  app.innerHTML = hero('COACH CENTRE', 'Teach on NexArenaverse',
    'Apply to teach live lessons, contribute tutorials or do both. The owner reviews your experience and sample material before anything is published.',
    button('Try the sample application', testPath('coaching', true)) + button('← Coach Centre', '/coaches/', true)) +
    `<section class="market-panel"><h2>Coach application</h2><p>There is no application fee. Use the private contact fields for your direct details and the optional public fields for your professional contacts.</p>
    ${me ? coachForm('coach-form') : loggedOut()}</section>`;
  bindConnect();
  const form = app.querySelector('#coach-form');
  if (!form) return;
  form.onsubmit = event => {
    event.preventDefault();
    submit(form, async data => {
      const result = await api('enquiry', {...data, kind:'coach', adult:form.elements.adult.checked,
        consent:form.elements.consent.checked, publishContacts:form.elements.publishContacts.checked});
      notice(result.message, false, form);
      form.reset();
    });
  };
}

export function showAdvertising({app, hero, button, me, loggedOut, bindConnect, submit, api, notice}) {
  const w = worlds.advertising;
  app.dataset.world = w.accent;
  app.innerHTML = hero(w.label, w.heading, w.summary, button('Request a quote', '#campaign') +
    button('Test request and payment →', testPath('advertising', true), true)) +
    `<div class="market-grid worlds-steps">
      <article class="market-card"><h2>Choose your audience</h2><p>Request placement in games, the Sports Academy or both. Children’s games do not carry ads.</p></article>
      <article class="market-card"><h2>Get your quote</h2><p>The owner reviews your product and requested placement, then sets your price and dates. Find the quote in My account.</p></article>
      <article class="market-card"><h2>Pay after approval</h2><p>Once live checkout is connected, approved quotes can be paid using the methods available for the quote’s currency. Try card, bank transfer or USSD in the NGN demo.</p>${button('Test an approved quote', testPath('advertising'), true)}</article>
    </div><section class="market-panel" id="campaign"><h2>Tell us about your campaign</h2><p>Your contact details and quote are visible to you and the site owner.</p>${me ? adForm('ad-form') : loggedOut()}</section>`;
  bindConnect();
  const form = app.querySelector('#ad-form');
  if (!form) return;
  form.onsubmit = event => {
    event.preventDefault();
    submit(form, async data => {
      const result = await api('enquiry', {...data, kind:'advertising'});
      notice(result.message, false, form);
      form.reset();
    });
  };
}
