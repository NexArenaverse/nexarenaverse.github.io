import {premiumFeatures} from './premium-lab-data.js';
import {worlds} from './market-world-data.js';
import {renderCoachCentre} from './coach-directory.js';
import {coachingProviders} from './coaching-providers.js';
import {adForm, coachForm} from './market-forms.js';
import {bindDesignPreview, circleSeats, designPicker} from './market-demo.js';

export function testPath(product, application = false) {
  return '/test-checkout/?product=' + product + (application ? '&amp;flow=application' : '');
}

const sportLabel = value => value.replaceAll('-', ' ');
const asList = entries => '<ul>' + entries.map(([label, detail]) => `<li><strong>${label}</strong> · ${detail}</li>`).join('') + '</ul>';

export function showPlans({app, button, priceControl, wireCurrency, money, catalog, currency}) {
  app.className = 'premium-app';
  delete app.dataset.world;
  app.innerHTML = `<section class="premium-hero">
    <img class="premium-hero-art" src="/premium-worlds-hero.jpg" alt="Sculpted glass chess pieces and a basketball on a dark chessboard" width="1536" height="1024" fetchpriority="high">
    <div class="premium-hero-copy"><p class="premium-kicker">NEXARENAVERSE PREMIUM</p><h1>More play.<br>More possibility.<br><em>Your next world.</em></h1>
    <p>Find your coach. Make the board your own. Bring your people. Build an arena that feels like you.</p>
    <div class="hero-actions">${button('Explore Premium','#premium-worlds')}${button('Meet the coaches','/coaches/',true)}</div>
    <div class="hero-facts"><span>Play, learn & personalise</span><span>Free checkout demos</span></div></div>
  </section>
  <nav class="premium-subnav" aria-label="Explore premium"><a href="/plus/membership/">Arena Plus</a><a href="/coaches/">Coach Centre</a><a href="/plus/designs/">Design Studio</a><a href="/plus/circle/">Your Circle</a><a href="/advertise/">Advertising</a></nav>
  <section class="premium-feature" aria-labelledby="coach-feature-title"><div><p class="premium-kicker">THE COACH CENTRE</p><h2 id="coach-feature-title">Better guidance.<br>A better game.</h2><p>Find your next teacher among ${coachingProviders.length} personal coaches, academies and video creators. Search by sport, location and teaching format.</p>${button('Explore all coaches','/coaches/')}</div>
    <div class="coaching-disciplines" aria-label="Available disciplines">${['Basketball','Football','Tennis','Badminton','Table tennis','Athletics','Chess'].map(s=>'<a href="/coaches/?sport='+s.toLowerCase().replace(' ','-')+'">'+s+'</a>').join('')}</div>
  </section>
  <section id="premium-worlds"><div class="premium-section-heading"><div><p class="premium-kicker">BUILT AROUND THE WAY YOU PLAY</p><h2>Choose your world</h2></div>${priceControl()}</div>
    <div class="premium-products">${Object.entries(worlds).map(([id,w])=>
      `<article class="premium-product ${id==='premium'?'product-wide':''}" data-world="${w.accent}">
        <div class="product-art product-art-${id}" aria-hidden="true">${{
          premium:'<span class="plus-symbol">✦</span><span class="orbital-ring"></span>',
          group:'<div class="circle-orbit"><span>●</span><span>●</span><span>●</span><span>●</span><span>●</span></div>',
          design:'<div class="prism-mini-board"><span>♞</span><span>♟</span></div>',
          coaching:'<span class="coaching-words">TRAIN<br>LEARN<br>GROW</span>',
          advertising:'<div class="ad-mock"><span>YOUR BRAND</span><strong>Make your<br>next move.</strong></div>'
        }[id]}</div>
        <div class="premium-product-copy"><p class="premium-kicker">${w.label}</p><h3>${w.heading}</h3><p>${w.summary}</p>
        <p class="product-price">${id==='advertising'?'Owner-set quote':money(catalog.prices[currency])}<small>${id==='coaching'?'Per available NexArenaverse lesson':w.period}</small></p>
        ${button('Explore '+w.heading,w.path,true)}</div></article>`).join('')}</div>
  </section>
  <section class="premium-expansion"><p class="premium-kicker">YOUR NEXT CHAPTER STARTS HERE</p><h2>Five new ways to make it yours</h2><p>Review your games, create an arena, bring your friends, build your skills and explore learning adventures. These new activities are open for practice previews during launch.</p><div class="market-grid">${premiumFeatures.map(f=>`<article class="premium-new-card"><span aria-hidden="true">${f.symbol}</span><p class="premium-kicker">${f.tag}</p><h3>${f.name}</h3><p>${f.text}</p>${button("Explore "+f.name,f.path,true)}</article>`).join('')}<article class="premium-new-card"><span aria-hidden="true">◈</span><p class="premium-kicker">BOARDS · PIECES · ATMOSPHERE</p><h3>Create Your Own Arena</h3><p>Make Lava Kingdom, Ice World or Cyber City your home. Save favourite looks and apply them to your next supported game.</p>${button("Open Arena Studio","/plus/designs/",true)}</article></div></section><aside class="premium-data-banner"><div><strong>Keep the play. Use less data.</strong><p>Save selected practice pages for offline use. Videos and live games still need a connection.</p></div>${button("Explore Data Saver","/plus/data-saver/",true)}</aside><section class="premium-test-banner"><div><p class="premium-kicker">TAKE IT FOR A TEST RUN</p><h2>See the flow. Try every step.</h2><p>Explore a sample purchase with a simulated card, transfer or USSD payment. Every demo shows a zero charge.</p></div>${button('Try the free demo','/test-checkout/?product=premium')}</section>`;
  wireCurrency();
}

export function showWorld(product, {app, hero, button, money, catalog, currency, priceControl, wireCurrency, purchase}) {
  const w = worlds[product];
  app.className = 'premium-app';
  app.dataset.world = w.accent;
  const preview = product === 'design' ? designPicker()
    : product === 'group' ? circleSeats()
    : '<label class="check mission-check"><input type="checkbox"><span>Sample mission · Complete three chess puzzles</span></label>';
  const previewName = {design:'Preview your board', group:'Your five Circle seats', premium:'Try a sample mission'}[product];
  app.innerHTML = hero(w.label, w.heading, w.summary,
    button('Try free test checkout →', testPath(product)) + button('← All premium worlds', '/plus/', true)) +
    `<div class="world-layout"><section class="market-panel"><h2>What you get</h2>${asList(w.highlights)}
      ${priceControl()}<div class="price">${money(catalog.prices[currency])}</div><p class="period">${w.period}</p>
      <button class="button secondary" id="live-buy" type="button">${catalog.checkout[currency] ? w.action : 'Register purchase interest'} →</button>
      <p class="muted">${catalog.checkout[currency] ? 'Live access starts after payment is verified.' : 'Live checkout for this currency is pending setup.'}</p>
    </section><section class="market-panel"><h2>${previewName}</h2>${preview}</section></div>`;
  app.querySelector('#live-buy').onclick = () => purchase(product);
  wireCurrency();
  bindDesignPreview(app);
}

export function showCoaches(context) {
  renderCoachCentre(context);
}

export function showCoachApplication({app, hero, button, me, loggedOut, bindConnect, submit, api, notice}) {
  app.className = 'premium-app';
  app.dataset.world = worlds.coaching.accent;
  app.innerHTML = hero('COACH CENTRE', 'Teach on NexArenaverse',
    'Apply to teach live lessons, contribute tutorials or do both. The owner reviews your experience and sample material before anything is published.',
    button('Try the sample application', testPath('coaching', true)) + button('← Coach Centre', '/coaches/', true)) +
    `<section class="market-panel"><h2>Coach application</h2><p>There is no application fee. Use the private contact fields for your direct details and the optional public fields for your professional contacts.</p>
    ${me ? coachForm('coach-form') : loggedOut()}</section>`;
  bindConnect();
  const form = app.querySelector('#coach-form');
  if (!form) return;
  form.onsubmit = event => {
    event.preventDefault();
    submit(form, async data => {
      const result = await api('enquiry', {...data, kind:'coach', adult:form.elements.adult.checked,
        consent:form.elements.consent.checked, publishContacts:form.elements.publishContacts.checked});
      notice(result.message, false, form);
      form.reset();
    });
  };
}

export function showAdvertising({app, hero, button, me, loggedOut, bindConnect, submit, api, notice}) {
  const w = worlds.advertising;
  app.className = 'premium-app';
  app.dataset.world = w.accent;
  app.innerHTML = hero(w.label, w.heading, w.summary, button('Request a quote', '#campaign') +
    button('Test request and payment →', testPath('advertising', true), true)) +
    `<div class="market-grid worlds-steps">
      <article class="market-card"><h2>Choose your audience</h2><p>Request placement in games, the Sports Academy or both. Children’s games do not carry ads.</p></article>
      <article class="market-card"><h2>Get your quote</h2><p>The owner reviews your product and requested placement, then sets your price and dates. Find the quote in My account.</p></article>
      <article class="market-card"><h2>Pay after approval</h2><p>Once live checkout is connected, approved quotes can be paid using the methods available for the quote’s currency. Try card, bank transfer or USSD in the NGN demo.</p>${button('Test an approved quote', testPath('advertising'), true)}</article>
    </div><section class="market-panel" id="campaign"><h2>Tell us about your campaign</h2><p>Your contact details and quote are visible to you and the site owner.</p>${me ? adForm('ad-form') : loggedOut()}</section>`;
  bindConnect();
  const form = app.querySelector('#ad-form');
  if (!form) return;
  form.onsubmit = event => {
    event.preventDefault();
    submit(form, async data => {
      const result = await api('enquiry', {...data, kind:'advertising'});
      notice(result.message, false, form);
      form.reset();
    });
  };
}
