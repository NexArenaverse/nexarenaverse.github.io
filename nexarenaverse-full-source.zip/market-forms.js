import {paymentMethods, sports} from './market-world-data.js';

const input = (label, name, attributes = '') => `<label>${label}<input name="${name}" ${attributes}></label>`;
const textarea = (label, name, attributes) => `<label class="form-wide">${label}<textarea name="${name}" ${attributes}></textarea></label>`;
const check = (label, name, required = '') => `<label class="check form-wide"><input type="checkbox" name="${name}" ${required}><span>${label}</span></label>`;
const sportOptions = sports.map(s => `<option value="${s}">${s.replace('-', ' ')}</option>`).join('');

export function coachForm(id, test = false) {
  return `<form id="${id}" method="post"><div class="form-grid">
    ${input('Public coach name', 'name', 'maxlength="80" required autocomplete="name"')}
    ${input('Private contact email', 'email', 'type="email" maxlength="160" required autocomplete="email"')}
    ${input('Private phone number', 'phone', 'type="tel" maxlength="40" required autocomplete="tel" placeholder="+234 …"')}
    ${input('Country', 'country', 'maxlength="70" required')}
    <label>Sport<select name="sport">${sportOptions}</select></label>
    ${input('Teaching languages', 'languages', 'maxlength="100" required placeholder="English, French…"')}
    ${input('Credentials or professional profile', 'credentials', 'type="url" maxlength="1200" required placeholder="https://…"')}
    <label>What would you like to offer?<select name="offer"><option value="lessons">Live lessons</option><option value="tutorials">Tutorials and training videos</option><option value="both">Live lessons and tutorials</option></select></label>
    ${input('Tutorial or video sample (optional)', 'tutorialUrl', 'type="url" maxlength="1200" placeholder="https://…"')}
    ${input('Tutorial title (optional)', 'tutorialTitle', 'maxlength="120"')}
    ${textarea('Public introduction', 'bio', 'minlength="30" maxlength="1200" required')}
    ${textarea('Experience and qualifications for review', 'experience', 'minlength="15" maxlength="1200" required')}
    ${textarea('Teaching proposal and payment terms', 'terms', 'minlength="10" maxlength="600" required placeholder="What you would teach and how you would like to deliver it."')}
    </div><fieldset class="market-fields"><legend>Optional public business contact</legend><div class="form-grid">
    ${input('Business email', 'businessEmail', 'type="email" maxlength="160"')}
    ${input('Business phone', 'businessPhone', 'type="tel" maxlength="40"')}
    ${input('Public venue address', 'businessAddress', 'maxlength="240" placeholder="Club, training venue or office"')}
    ${input('Coaching website', 'businessWebsite', 'type="url" maxlength="1200" placeholder="https://…"')}
    ${check('I want these business contacts displayed if the owner approves my profile.', 'publishContacts')}
    </div></fieldset><div class="form-grid">
    ${check('I am at least 18 and have permission to share the material I submit.', 'adult', 'required')}
    ${check('I agree that my name, sport, country, languages and introduction may be shown after approval. My private contact and review details are for the owner.', 'consent', 'required')}
    </div><button class="button" type="submit">${test ? 'Preview sample application' : 'Send coach application'} →</button><p role="status"></p></form>`;
}

export function adForm(id, test = false) {
  return `<form id="${id}" method="post"><div class="form-grid">
    ${input('Your name', 'name', 'maxlength="80" required autocomplete="name"')}
    ${input('Contact email', 'email', 'type="email" maxlength="160" required autocomplete="email"')}
    ${input('Contact phone (optional)', 'phone', 'type="tel" maxlength="40" autocomplete="tel"')}
    ${input('Business or brand', 'brand', 'maxlength="100" required')}
    ${input('Product or service', 'productName', 'maxlength="120" required')}
    ${input('Website to promote', 'url', 'type="url" maxlength="1200" required placeholder="https://…"')}
    <label>Preferred placement<select name="placement"><option value="games">Games</option><option value="sports">Sports Academy</option><option value="both">Games and Sports Academy</option></select></label>
    <label>Preferred payment method<select name="method">${Object.entries(paymentMethods).map(([id,label]) => `<option value="${id}">${label}</option>`).join('')}</select></label>
    ${input('Audience (optional)', 'audience', 'maxlength="240"')}
    ${input('Preferred campaign start (optional)', 'startDate', 'type="date"')}
    ${input('Artwork or media kit link (optional)', 'mediaUrl', 'type="url" maxlength="1200" placeholder="https://…"')}
    ${textarea('About your product and campaign', 'message', 'minlength="15" maxlength="1600" required placeholder="What you offer, campaign goals, preferred run length and anything else the owner should know."')}
    </div><button class="button" type="submit">${test ? 'Preview sample campaign' : 'Request my advertising quote'} →</button><p role="status"></p></form>`;
}
