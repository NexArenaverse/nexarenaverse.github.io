import {githubHosted, serviceFetch, connectAccount, playerToken, accountDestination} from './service.js';

const installing = location.pathname.replace(/\/$/, '') === '/install';
const signInPanel = document.querySelector('#sign-in-panel');
const installPanel = document.querySelector('#install-panel');
const nav = document.querySelector(installing ? 'nav a[href="/install/"]' : 'nav a[href="/sign-in/"]');
nav.setAttribute('aria-current', 'page');
signInPanel.hidden = installing;
installPanel.hidden = !installing;

if (installing) {
  const button = document.querySelector('#install-prompt');
  const status = document.querySelector('#install-status');
  const instructions = document.querySelector('#install-instructions');
  let promptEvent;
  function installed() {
    button.hidden = true;
    instructions.hidden = true;
    status.textContent = 'NexArenaverse is installed on this device.';
  }
  if (matchMedia('(display-mode: standalone)').matches || navigator.standalone === true) {
    installed();
  } else {
    const device = /Android/i.test(navigator.userAgent) ? 'android' : /iPhone|iPad|iPod/i.test(navigator.userAgent) ? 'iphone' : 'desktop';
    document.querySelector('#' + device + '-install').open = true;
    window.addEventListener('beforeinstallprompt', event => {
      event.preventDefault();
      promptEvent = event;
      button.hidden = false;
    });
    window.addEventListener('appinstalled', installed);
    button.onclick = async () => {
      if (!promptEvent) return;
      const event = promptEvent;
      promptEvent = undefined;
      button.hidden = true;
      try {
        const result = await event.prompt();
        if (result.outcome === 'accepted') installed();
        else status.textContent = 'You can install later using the browser steps below.';
      } catch {
        status.textContent = 'Use the browser steps below to install NexArenaverse.';
      }
    };
  }
} else {
  const status = document.querySelector('#sign-in-status');
  const link = document.querySelector('#continue-sign-in');
  const destination = accountDestination(new URLSearchParams(location.search).get('return_to'));
  const continuePath = '/sign-in/?return_to=' + encodeURIComponent(destination);
  if (githubHosted) {
    link.onclick = event => {
      event.preventDefault();
      try { connectAccount(playerToken(), {sameTab: true, returnTo: destination}); }
      catch { status.textContent = 'Allow this browser to store site data, then try again.'; }
    };
  } else {
    link.href = '/signin-with-chatgpt?return_to=' + encodeURIComponent(continuePath);
  }
  try {
    const response = await serviceFetch('/api/market/me', {headers: {'x-player-token': playerToken()}});
    if (response.ok && (await response.json()).signedIn) {
      document.querySelector('h1').textContent = 'You’re signed in';
      status.textContent = 'Your NexArenaverse account is ready.';
      link.href = destination;
      link.onclick = null;
      link.textContent = destination === '/account/' ? 'Open My account →' : 'Continue to NexArenaverse →';
    }
  } catch {
    // Keep the sign-in action available when the account status is unreachable.
  }
}
