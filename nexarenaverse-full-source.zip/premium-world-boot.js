// Refresh an existing opt-in offline worker before loading a new release.
// New visitors do not download an offline pack without choosing it.
async function refreshPracticeWorker(){
 if(!('serviceWorker' in navigator)||!navigator.onLine)return;
 try{
  const existing=await navigator.serviceWorker.getRegistration('/');if(!existing)return;
  const registration=await navigator.serviceWorker.register('/practice-sw.js',{scope:'/',updateViaCache:'none'});
  const waiting=registration.installing||registration.waiting;
  if(waiting&&waiting.state!=='activated')await Promise.race([new Promise(resolve=>{const changed=()=>{if(['activated','redundant'].includes(waiting.state)){waiting.removeEventListener('statechange',changed);resolve();}};waiting.addEventListener('statechange',changed);changed();}),new Promise(resolve=>setTimeout(resolve,3500))]);
 }catch{}
}
await refreshPracticeWorker();
await import('./market.js');
