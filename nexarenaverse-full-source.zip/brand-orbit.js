// Decorative enhancement only: no navigation, account or game-state handlers.
const selectors='img.brand-mark,.market-brand>img,.welcome-logo';
try{if(!document.documentElement.hasAttribute('data-motion-effects')&&localStorage.getItem('na-motion-effects')==='off')document.documentElement.dataset.motionEffects='off'}catch{}
let scheduled=false;
function mountBrandOrbits(){
  scheduled=false;
  for(const image of document.querySelectorAll(selectors)){
    if(image.closest('.nexa-orbit-badge'))continue;
    const badge=document.createElement('span');
    badge.className='nexa-orbit-badge'+(image.classList.contains('welcome-logo')?' nexa-orbit-large':'');
    const plane=document.createElement('span');plane.className='nexa-orbit-plane';plane.setAttribute('aria-hidden','true');
    const ring=document.createElement('span');ring.className='nexa-orbit-ring';
    const spinner=document.createElement('span');spinner.className='nexa-orbit-spinner';
    for(const colour of ['cyan','red']){const satellite=document.createElement('span');satellite.className='nexa-orbit-satellite nexa-orbit-'+colour;spinner.append(satellite)}
    plane.append(ring,spinner);image.before(badge);image.classList.add('nexa-orbit-mark');badge.append(image,plane);
  }
}
function schedule(){if(scheduled)return;scheduled=true;requestAnimationFrame(mountBrandOrbits)}
// Keep the decoration when entering a game replaces the header.
new MutationObserver(schedule).observe(document.body,{childList:true,subtree:true});
function pageVisibility(){document.documentElement.dataset.logoPageHidden=String(document.hidden)}
document.addEventListener('visibilitychange',pageVisibility);pageVisibility();
mountBrandOrbits();
