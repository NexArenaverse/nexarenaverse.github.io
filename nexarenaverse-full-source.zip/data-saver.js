export function dataSaverEnabled(){try{return JSON.parse(localStorage.getItem('na-data-saver')||'false')===true;}catch{return false;}}
if(typeof document!=='undefined')document.documentElement.dataset.dataSaver=dataSaverEnabled()?'on':'off';
