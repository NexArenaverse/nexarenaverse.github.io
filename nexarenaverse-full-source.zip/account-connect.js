const content = document.querySelector('#account-connect');
const params = new URLSearchParams(location.hash.slice(1));
let pending;
try {
  if (params.has('device')) {
    pending = {device:params.get('device'), state:params.get('state'), expires:Date.now()+600000};
    sessionStorage.setItem('na-github-connect', JSON.stringify(pending));
    history.replaceState(null,'','/account-connect');
  } else {
    pending = JSON.parse(sessionStorage.getItem('na-github-connect') || 'null');
  }
} catch {}

async function request(path, data) {
  const response = await fetch('/api/rankings' + path, {
    method: data ? 'POST' : 'GET',
    headers: {'content-type':'application/json', 'x-player-token':pending.device},
    body: data ? JSON.stringify(data) : undefined
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Sign-in could not finish. Please try again.');
  return result;
}

async function show() {
  if (!pending || pending.expires < Date.now() || !/^[a-f0-9]{64}$/.test(pending.device) || !/^[a-f0-9]{48}$/.test(pending.state)) {
    content.textContent = 'This sign-in request has expired. Go back to NexArenaverse to start again.';
    return;
  }
  try {
    const {signedIn, me} = await request('');
    if (!signedIn) {
      content.innerHTML = '<a class="button" target="_top" href="/signin-with-chatgpt?return_to=%2Faccount-connect">Continue to ChatGPT sign-in →</a>';
      return;
    }
    content.innerHTML = `<form method="post">${me ? '<p>Continue to use your existing player profile.</p>' : '<label>Choose a public player name<input name="alias" autocomplete="nickname" minlength="3" maxlength="24" required></label>'}
      <button type="submit" class="button">Continue to NexArenaverse →</button><p role="status"></p></form>`;
    const form = content.querySelector('form');
    const button = form.querySelector('button');
    const status = form.querySelector('[role=status]');
    form.onsubmit = async event => {
      event.preventDefault();
      button.disabled = true;
      try {
        if (!me) await request('/account', {alias:form.elements.alias.value});
        const {session} = await request('/github-session', {});
        sessionStorage.removeItem('na-github-connect');
        location.replace('https://nexarenaverse.github.io/account-return/#' + new URLSearchParams({state:pending.state, session}));
      } catch (error) {
        status.textContent = error.message;
        button.disabled = false;
      }
    };
  } catch (error) {
    content.textContent = error.message;
  }
}
await show();
