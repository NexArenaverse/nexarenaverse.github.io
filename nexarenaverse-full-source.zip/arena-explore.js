import {worldDirectory,worldCategories,findWorlds} from './world-directory.js';
import {readJSON,writeJSON} from './site-storage.js';
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const valid=new Set(worldDirectory.map(w=>w.id));
const ids=key=>readJSON(key,[]).filter(id=>typeof id==='string'&&valid.has(id));
let saved=ids('na-world-favourites'),recent=ids('na-world-recent'),dialog,trigger,homeHero,category='All',savedOnly=false,limit=18;
const path=location.pathname.replace(/\/+$/,'')||'/';
const current=worldDirectory.find(w=>(w.path.replace(/\/+$/,'')||'/')===path);
if(current&&current.path!=='/'){recent=[current.id,...recent.filter(id=>id!==current.id)].slice(0,8);writeJSON('na-world-recent',recent);}

function resultCard(world){return `<article class="explore-world" data-category="${world.category}"><a href="${world.path}"><span class="explore-icon" aria-hidden="true">${world.icon}</span><div><small>${world.category} · ${world.label}</small><h3>${esc(world.name)}</h3><p>${esc(world.description)}</p></div></a><button type="button" data-save-world="${world.id}" aria-label="Save ${esc(world.name)}" aria-pressed="${saved.includes(world.id)}" title="Save to favourites">${saved.includes(world.id)?'★':'☆'}</button></article>`;}
function renderResults(){
 const query=dialog.querySelector('input').value;
 const found=findWorlds({query,category,savedOnly},saved);
 const hasQuery=!!query.trim();
 const history=!hasQuery&&category==='All'&&!savedOnly?recent.map(id=>worldDirectory.find(w=>w.id===id)).filter(Boolean).slice(0,4):[];
 dialog.querySelector('#explore-status').textContent=`${found.length} ${found.length===1?'world':'worlds'}${savedOnly?' in your favourites':''}${hasQuery?' matching your search':''}`;
 dialog.querySelector('#explore-results').innerHTML=(history.length?`<section class="explore-recent"><h3>Recently explored</h3><div>${history.map(w=>`<a href="${w.path}"><span aria-hidden="true">${w.icon}</span>${esc(w.name)}</a>`).join('')}</div></section>`:'')+(found.length?`<div class="explore-grid">${found.slice(0,limit).map(resultCard).join('')}</div>`:`<div class="explore-empty"><span aria-hidden="true">◇</span><h3>${savedOnly?'Your collection starts here.':'A new world is one search away.'}</h3><p>${savedOnly?'Use the stars on world cards to save your favourites.':'Try a game, sport, subject or skill. You can also clear the filters.'}</p><button type="button" id="explore-reset">Explore all worlds</button></div>`)+(found.length>limit?`<button type="button" class="explore-more">Show more worlds (${found.length-limit} more)</button>`:'');
 dialog.querySelector('.explore-more')?.addEventListener('click',()=>{limit+=18;renderResults();});
 dialog.querySelector('#explore-reset')?.addEventListener('click',()=>{category='All';savedOnly=false;dialog.querySelector('input').value='';limit=18;updateFilters();renderResults();dialog.querySelector('input').focus();});
 for(const button of dialog.querySelectorAll('[data-save-world]'))button.addEventListener('click',()=>{
  const id=button.dataset.saveWorld;saved=saved.includes(id)?saved.filter(x=>x!==id):[id,...saved].slice(0,60);
  writeJSON('na-world-favourites',saved);renderResults();renderHomeStrip(true);
  dialog.querySelector(`[data-save-world="${id}"]`)?.focus();
 });
}
function updateFilters(){for(const b of dialog.querySelectorAll('[data-world-category]'))b.setAttribute('aria-pressed',String(b.dataset.worldCategory===category));dialog.querySelector('#explore-saved').setAttribute('aria-pressed',String(savedOnly));}
function buildDialog(){
 if(dialog?.isConnected)return;
 dialog=document.createElement('dialog');dialog.className='explore-dialog';dialog.setAttribute('aria-labelledby','explore-title');
 dialog.innerHTML=`<div class="explore-heading"><div><p>YOUR NEXT DISCOVERY</p><h2 id="explore-title">Find your next world.</h2></div><button type="button" class="explore-close" aria-label="Close Explore Worlds">×</button></div><label class="explore-search"><span>Search the arena</span><input type="search" placeholder="Chess, drills, science, coaches…" maxlength="100" autocomplete="off"></label><nav class="explore-filters" aria-label="World categories">${worldCategories.map(c=>`<button type="button" data-world-category="${c}" aria-pressed="${c==='All'}">${c}</button>`).join('')}<button type="button" id="explore-saved" aria-pressed="false">★ Favourites</button></nav><p id="explore-status" role="status" aria-live="polite"></p><div id="explore-results"></div><footer><span>${worldDirectory.length} worlds to explore</span><span><kbd>/</kbd> or <kbd>Ctrl K</kbd> to open · <kbd>Esc</kbd> to close</span></footer>`;
 dialog.querySelector('.explore-close').onclick=()=>dialog.close();
 dialog.addEventListener('close',()=>trigger?.setAttribute('aria-expanded','false'));
 dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
 dialog.querySelector('input').addEventListener('input',()=>{limit=18;renderResults();});
 dialog.querySelector('input').addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();dialog.querySelector('.explore-world a')?.focus();}});
 for(const b of dialog.querySelectorAll('[data-world-category]'))b.onclick=()=>{category=b.dataset.worldCategory;limit=18;updateFilters();renderResults();};
 dialog.querySelector('#explore-saved').onclick=()=>{savedOnly=!savedOnly;limit=18;updateFilters();renderResults();};
 document.body.append(dialog);
}
function openExplorer(){
 if(document.querySelector('dialog[open]')||document.querySelector('#overlay .modal'))return;
 buildDialog();saved=ids('na-world-favourites');recent=ids('na-world-recent');renderResults();updateFilters();dialog.showModal();trigger?.setAttribute('aria-expanded','true');dialog.querySelector('input').focus();
}
function renderHomeStrip(force=false){
 if(path!=='/')return;
 const hero=document.querySelector('#app > .hero');if(!hero||!force&&hero===homeHero)return;homeHero=hero;
 let strip=document.querySelector('.arena-quick-worlds');
 if(!strip){strip=document.createElement('section');strip.className='arena-quick-worlds';strip.setAttribute('aria-label','Your world shortcuts');hero.after(strip);}
 const selected=[...new Set([...saved,...recent])].map(id=>worldDirectory.find(w=>w.id===id)).filter(Boolean).slice(0,4);
 const items=selected.length?selected:['chess','today','education','adventures'].map(id=>worldDirectory.find(w=>w.id===id));
 strip.innerHTML=`<div><span>${selected.length?'YOUR COLLECTION':'QUICK DISCOVERIES'}</span><h2>${selected.length?'Your next visit starts here.':'A whole arena to discover.'}</h2><button type="button">Explore all worlds</button></div><nav aria-label="World shortcuts">${items.map(w=>`<a href="${w.path}" data-category="${w.category}"><i aria-hidden="true">${w.icon}</i><span>${esc(w.name)}<small>${w.category}</small></span></a>`).join('')}</nav>`;
 strip.querySelector('button').onclick=openExplorer;
}
function mount(){
 if(!trigger?.isConnected){const header=document.querySelector('header');if(header){trigger=document.createElement('button');trigger.className='arena-explore-open';trigger.type='button';trigger.setAttribute('aria-label','Explore all worlds');trigger.setAttribute('aria-haspopup','dialog');trigger.setAttribute('aria-expanded','false');trigger.innerHTML='<span aria-hidden="true">◇</span> Explore';trigger.onclick=openExplorer;(header.querySelector('.na-motion-controls')||header).append(trigger);}}
 if(document.documentElement.dataset.boot!=='loading')renderHomeStrip();
}
mount();
let queued=false;new MutationObserver(()=>{if(trigger?.isConnected&&(path!=='/'||homeHero===document.querySelector('#app>.hero')))return;if(!queued){queued=true;requestAnimationFrame(()=>{queued=false;mount();});}}).observe(document.body,{childList:true,subtree:true});
new MutationObserver(mount).observe(document.documentElement,{attributes:true,attributeFilter:['data-boot']});
document.addEventListener('keydown',e=>{const typing=e.target instanceof Element&&e.target.closest('input,textarea,select,[contenteditable="true"]');if((e.key==='/'&&!typing&&!e.ctrlKey&&!e.metaKey&&!e.altKey)||((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'&&!e.altKey)){e.preventDefault();openExplorer();}});
addEventListener('storage',e=>{if(['na-world-favourites','na-world-recent'].includes(e.key)){saved=ids('na-world-favourites');recent=ids('na-world-recent');if(dialog?.open)renderResults();renderHomeStrip(true);}});
