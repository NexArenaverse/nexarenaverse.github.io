export const coachingProviders = [
  {
    "id": "drew-hanlen-pure-sweat",
    "name": "Drew Hanlen · Pure Sweat Basketball",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Structured basketball skill workouts, shooting development, and training courses.",
    "website": "https://puresweatbasketball.com/",
    "sources": [
      {
        "url": "https://puresweatbasketball.com/",
        "title": "Pure Sweat Basketball | Train Like The Pros"
      },
      {
        "url": "https://puresweatbasketball.com/skills",
        "title": "Virtual Skills School"
      },
      {
        "url": "https://www.youtube.com/channel/UCENoE4SyCBqzMDxtfJv7T1Q",
        "title": "Drew Hanlen · Pure Sweat Basketball | Official Youtube"
      }
    ],
    "checkedAt": "2026-11-21",
    "youtube": "https://www.youtube.com/channel/UCENoE4SyCBqzMDxtfJv7T1Q"
  },
  {
    "id": "jordan-lawley",
    "name": "Jordan Lawley",
    "sport": "basketball",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Basketball skills sessions and guided workouts for developing players.",
    "website": "https://www.jordanlawley.com/",
    "sources": [
      {
        "url": "https://www.jordanlawley.com/",
        "title": "Jordan Lawley | Basketball Training"
      },
      {
        "url": "https://www.jordanlawley.com/academy",
        "title": "Jordan Lawley Academy"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "dj-sackmann",
    "name": "DJ Sackmann",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "in-person"
    ],
    "focus": "Basketball skill development through camps, clinics, and detailed technical instruction.",
    "website": "https://djsackmann.com/about",
    "sources": [
      {
        "url": "https://djsackmann.com/about",
        "title": "DJ Sackmann | About"
      },
      {
        "url": "https://www.djsackmannevents.com/",
        "title": "DJ Sackmann Events"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "micah-lancaster-impossible",
    "name": "Micah Lancaster · I’m Possible Training",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Detailed basketball skills, footwork, and individual training methods.",
    "website": "https://possibletraining.com/pages/about-micah",
    "sources": [
      {
        "url": "https://possibletraining.com/pages/about-micah",
        "title": "About Micah Lancaster"
      },
      {
        "url": "https://possibletraining.com/pages/train-with-micah",
        "title": "Train With Micah"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "ganon-baker",
    "name": "Ganon Baker",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Basketball skills, game understanding, player clinics, and coach education.",
    "website": "https://www.ganonbakerbasketball.com/",
    "sources": [
      {
        "url": "https://www.ganonbakerbasketball.com/",
        "title": "Ganon Baker Basketball"
      },
      {
        "url": "https://www.ganonbakerbasketball.com/collections/courses",
        "title": "Ganon Baker Courses"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "ryan-razooky-r2bball",
    "name": "Ryan Razooky · R2BBALL",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "in-person"
    ],
    "focus": "Basketball techniques and skill development built around game situations.",
    "website": "https://r2bball.com/",
    "sources": [
      {
        "url": "https://r2bball.com/",
        "title": "R2BBALL"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "tyler-relph",
    "name": "Tyler Relph Basketball Academy",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Online basketball skill development, scoring, and ball handling.",
    "website": "https://www.trbasketballacademy.com/",
    "sources": [
      {
        "url": "https://www.trbasketballacademy.com/",
        "title": "Tyler Relph Basketball Academy"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "phil-handy-94-feet",
    "name": "Phil Handy · 94 Feet of Game",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Ball handling, shooting, passing, and defensive skill development.",
    "website": "https://www.94feetofgame.com/",
    "sources": [
      {
        "url": "https://www.94feetofgame.com/",
        "title": "94 Feet of Game"
      },
      {
        "url": "https://www.youtube.com/channel/UC4UEDK2mADDF550xXq01YpA",
        "title": "Phil Handy · 94 Feet of Game | Official Youtube"
      }
    ],
    "checkedAt": "2026-11-21",
    "youtube": "https://www.youtube.com/channel/UC4UEDK2mADDF550xXq01YpA"
  },
  {
    "id": "chris-johnson-hoops",
    "name": "Chris Johnson Hoops",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Video drills for shooting, ball handling, conditioning, and basketball skills.",
    "website": "https://chrisjohnsonhoops.uscreen.io/",
    "sources": [
      {
        "url": "https://chrisjohnsonhoops.uscreen.io/",
        "title": "Chris Johnson Hoops Training"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "coleman-ayers-by-any-means",
    "name": "Coleman Ayers · By Any Means Basketball",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Basketball decision making, skill acquisition, and game-focused player development.",
    "website": "https://byanymeansbball.com/",
    "sources": [
      {
        "url": "https://byanymeansbball.com/",
        "title": "By Any Means Basketball"
      },
      {
        "url": "https://byanymeansbball.com/about",
        "title": "About By Any Means Basketball"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "devin-williams-in-the-lab",
    "name": "Devin Williams · In The Lab",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "video"
    ],
    "focus": "Basketball development stories, technique demonstrations, and training insights.",
    "website": "https://inthelab.tv/pages/devin",
    "sources": [
      {
        "url": "https://inthelab.tv/pages/devin",
        "title": "Devin Williams | In The Lab"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "collin-castellaw-shotmechanics",
    "name": "Collin Castellaw · ShotMechanics",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Shooting technique, shot development, and basketball training programmes.",
    "website": "https://shotmechanics.com/",
    "sources": [
      {
        "url": "https://shotmechanics.com/",
        "title": "ShotMechanics"
      },
      {
        "url": "https://shotmechanics.mykajabi.com/store",
        "title": "ShotMechanics Training Programmes"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "paul-fabritz-pjf",
    "name": "Paul Fabritz · PJF Performance",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Basketball athletic development, ball handling, and structured skill programmes.",
    "website": "https://www.pjfperformance.com/about-us/",
    "sources": [
      {
        "url": "https://www.pjfperformance.com/about-us/",
        "title": "About PJF Performance"
      },
      {
        "url": "https://www.pjfperformance.com/handles/",
        "title": "PJF Handles Programme"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "chris-oliver-basketball-immersion",
    "name": "Chris Oliver · Basketball Immersion",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Coach education, decision making, and basketball practice design.",
    "website": "https://basketballimmersion.com/",
    "sources": [
      {
        "url": "https://basketballimmersion.com/",
        "title": "Basketball Immersion"
      },
      {
        "url": "https://basketballimmersion.com/chrisoliver/",
        "title": "Chris Oliver"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "jesse-muench-get-handles",
    "name": "Jesse Muench · Get Handles",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Ball handling instruction and detailed basketball skill workouts.",
    "website": "https://gethandles.com/",
    "sources": [
      {
        "url": "https://gethandles.com/",
        "title": "Get Handles Basketball"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "coach-rock-revenge-basketball",
    "name": "Coach Rock · Revenge Basketball",
    "sport": "basketball",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Shooting, ball handling, footwork, and scoring skills for guards.",
    "website": "https://revengebasketball.com/",
    "sources": [
      {
        "url": "https://revengebasketball.com/",
        "title": "Revenge Basketball"
      },
      {
        "url": "https://revengebasketball.com/what-happened-to-coach-rock/",
        "title": "Coach Rock Training"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "ethan-khoza-vision-driven",
    "name": "Ethan Khoza · Vision Driven Basketball",
    "sport": "basketball",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Basketball skill training and guided player development.",
    "website": "https://www.visiondrivenbball.com/about-us",
    "sources": [
      {
        "url": "https://www.visiondrivenbball.com/about-us",
        "title": "About Vision Driven Basketball"
      },
      {
        "url": "https://www.visiondrivenbball.com/training",
        "title": "Vision Driven Basketball Training"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "shot-science",
    "name": "Shot Science Basketball",
    "sport": "basketball",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Basketball shooting instruction, skills demonstrations, and player development videos.",
    "website": "https://shotscience.com/",
    "sources": [
      {
        "url": "https://shotscience.com/",
        "title": "Shot Science Basketball"
      },
      {
        "url": "https://shotscience.com/products/all-access-membership",
        "title": "Shot Science All Access"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "saul-isaksson-hurst",
    "name": "Saul Isaksson-Hurst · My Personal Football Coach",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Individual football technique development and ball mastery training.",
    "website": "https://mypersonalfootballcoach.com/about/",
    "sources": [
      {
        "url": "https://mypersonalfootballcoach.com/about/",
        "title": "About My Personal Football Coach"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "lee-jones-joner-football",
    "name": "Lee Jones · Joner Football",
    "sport": "football",
    "type": "individual",
    "country": "Australia",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Technical football coaching, ball mastery, training drills, and player programmes.",
    "website": "https://jonerfootball.com/",
    "sources": [
      {
        "url": "https://jonerfootball.com/",
        "title": "Joner Football | Training App, Coaching and Camps"
      },
      {
        "url": "https://jonerfootball.com/about",
        "title": "About Joner Football"
      },
      {
        "url": "https://www.youtube.com/@jonerfootball",
        "title": "Lee Jones · Joner Football | Official Youtube"
      },
      {
        "url": "https://www.tiktok.com/@jonerfootball",
        "title": "Lee Jones · Joner Football | Official Tiktok"
      }
    ],
    "checkedAt": "2026-11-21",
    "youtube": "https://www.youtube.com/@jonerfootball",
    "tiktok": "https://www.tiktok.com/@jonerfootball"
  },
  {
    "id": "david-copeland-smith",
    "name": "David Copeland-Smith · Beast Mode Soccer",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Individual football technique, ball mastery, and guided online development sessions.",
    "website": "https://beastmodesoccer.com/david-copeland-smith/",
    "sources": [
      {
        "url": "https://beastmodesoccer.com/david-copeland-smith/",
        "title": "David Copeland-Smith | Beast Mode Soccer"
      },
      {
        "url": "https://beastmodesoccer.com/online-development-academy-sessions/",
        "title": "Online Development Academy Sessions"
      },
      {
        "url": "https://www.youtube.com/channel/UC2VOLCrgkwtINNT-MUv8BSQ",
        "title": "David Copeland-Smith · Beast Mode Soccer | Official Youtube"
      }
    ],
    "checkedAt": "2026-11-21",
    "youtube": "https://www.youtube.com/channel/UC2VOLCrgkwtINNT-MUv8BSQ"
  },
  {
    "id": "7mlc-training",
    "name": "7MLC Training",
    "sport": "football",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "video"
    ],
    "focus": "Football technique tutorials, ball mastery exercises, and training insights.",
    "website": "https://www.7mlctraining.com/",
    "sources": [
      {
        "url": "https://www.7mlctraining.com/",
        "title": "7MLC Training"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "matt-sheldon-become-elite",
    "name": "Matt Sheldon · Become Elite",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Football training programmes and individual online development discussions.",
    "website": "https://www.become-elite.com/",
    "sources": [
      {
        "url": "https://www.become-elite.com/",
        "title": "Become Elite"
      },
      {
        "url": "https://www.become-elite.com/products/skype-session-with-matt-sheldon",
        "title": "Online Session with Matt Sheldon"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "dylan-tooby-progressive-soccer",
    "name": "Dylan Tooby · Progressive Soccer",
    "sport": "football",
    "type": "individual",
    "country": "Canada",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Football skills, fitness, game understanding, and online training.",
    "website": "https://www.progressivesoccertraining.com/about/",
    "sources": [
      {
        "url": "https://www.progressivesoccertraining.com/about/",
        "title": "About Progressive Soccer"
      },
      {
        "url": "https://www.progressivesoccertraining.com/new-live-training/",
        "title": "Progressive Soccer Live Training"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "jared-montz-online-soccer-academy",
    "name": "Jared Montz · Online Soccer Academy",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Football tutorials and virtual group training for improving player technique.",
    "website": "https://www.onlinesocceracademy.com/jaredmontz",
    "sources": [
      {
        "url": "https://www.onlinesocceracademy.com/jaredmontz",
        "title": "Jared Montz | Online Soccer Academy"
      },
      {
        "url": "https://www.onlinesocceracademy.com/virtual-group-training",
        "title": "Online Soccer Academy Virtual Group Training"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "will-john-goluremi",
    "name": "Will John · Goluremi",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Football skills, fitness, mindset, and guided training resources.",
    "website": "https://gowilljohn.com/",
    "sources": [
      {
        "url": "https://gowilljohn.com/",
        "title": "Will John | Goluremi"
      },
      {
        "url": "https://www.skool.com/goluremi-nation/about",
        "title": "Goluremi Nation"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "dave-simply-soccer",
    "name": "Dave · Simply Soccer",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Football technique, confidence, and player development programmes.",
    "website": "https://www.simplysoccer.academy/",
    "sources": [
      {
        "url": "https://www.simplysoccer.academy/",
        "title": "Simply Soccer Academy"
      },
      {
        "url": "https://www.simplysoccer.academy/simply-soccer-mastermind-landing",
        "title": "Simply Soccer Mastermind"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "coerver-coaching",
    "name": "Coerver Coaching",
    "sport": "football",
    "type": "academy",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Football skills development, ball mastery, and courses for players and coaches.",
    "website": "https://www.coervercoaching.com/",
    "sources": [
      {
        "url": "https://www.coervercoaching.com/",
        "title": "Coerver Coaching"
      },
      {
        "url": "https://www.coervercoaching.com/about/",
        "title": "About Coerver Coaching"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "shaun-green-soccercoachtv",
    "name": "Shaun Green · SoccerCoachTV",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Football coaching demonstrations, session ideas, and training exercises.",
    "website": "https://www.soccercoachtv.com/",
    "sources": [
      {
        "url": "https://www.soccercoachtv.com/",
        "title": "SoccerCoachTV"
      },
      {
        "url": "https://www.soccercoachtv.com/Misc/ShaunGreen.html",
        "title": "Shaun Green | SoccerCoachTV"
      },
      {
        "url": "https://www.youtube.com/channel/UCgKCQJCkYrRKwqr-17inQsQ",
        "title": "Shaun Green · SoccerCoachTV | Official Youtube"
      }
    ],
    "checkedAt": "2026-11-21",
    "youtube": "https://www.youtube.com/channel/UCgKCQJCkYrRKwqr-17inQsQ"
  },
  {
    "id": "the-coaching-manual",
    "name": "The Coaching Manual",
    "sport": "football",
    "type": "academy",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Football coach education, session planning, and practical training videos.",
    "website": "https://www.thecoachingmanual.com/",
    "sources": [
      {
        "url": "https://www.thecoachingmanual.com/",
        "title": "The Coaching Manual"
      },
      {
        "url": "https://www.thecoachingmanual.com/services",
        "title": "The Coaching Manual Services"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "train-effective",
    "name": "Train Effective",
    "sport": "football",
    "type": "academy",
    "country": "United Kingdom",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Football training programmes, player development, and training camps.",
    "website": "https://www.traineffective.com/en/about",
    "sources": [
      {
        "url": "https://www.traineffective.com/en/about",
        "title": "About Train Effective"
      },
      {
        "url": "https://www.traineffective.com/en/train-effective-football-camps",
        "title": "Train Effective Football Camps"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "allattack",
    "name": "AllAttack",
    "sport": "football",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "video"
    ],
    "focus": "Football skill breakdowns and technique tutorials.",
    "website": "https://www.youtube.com/channel/UC0Ik25PHaiHCbfGrzu-lBFQ",
    "sources": [
      {
        "url": "https://www.youtube.com/channel/UC0Ik25PHaiHCbfGrzu-lBFQ",
        "title": "AllAttack | Official YouTube"
      }
    ],
    "checkedAt": "2026-11-21",
    "youtube": "https://www.youtube.com/channel/UC0Ik25PHaiHCbfGrzu-lBFQ"
  },
  {
    "id": "unisport-training",
    "name": "Unisport",
    "sport": "football",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "video"
    ],
    "focus": "Football skill tutorials, freestyle moves, and free-kick instruction.",
    "website": "https://www.unisportstore.com/stories/51266-unisport-youtube-celebrating-4-million-subscribers/",
    "sources": [
      {
        "url": "https://www.unisportstore.com/stories/51266-unisport-youtube-celebrating-4-million-subscribers/",
        "title": "Unisport YouTube | Football Skills Tutorials"
      },
      {
        "url": "https://www.youtube.com/user/wwwunisportdk/",
        "title": "Unisport | Official Youtube"
      },
      {
        "url": "https://www.tiktok.com/@unisportstore",
        "title": "Unisport | Official Tiktok"
      }
    ],
    "checkedAt": "2026-11-21",
    "youtube": "https://www.youtube.com/user/wwwunisportdk/",
    "tiktok": "https://www.tiktok.com/@unisportstore"
  },
  {
    "id": "tom-byer-soccer-starts-at-home",
    "name": "Tom Byer · Soccer Starts at Home",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Early football development through parent involvement and ball mastery.",
    "website": "https://soccerstartsathome.thinkific.com/",
    "sources": [
      {
        "url": "https://soccerstartsathome.thinkific.com/",
        "title": "Soccer Starts At Home"
      },
      {
        "url": "https://tomsan.com/en/shop.php",
        "title": "Tom Byer | Soccer Starts At Home"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "thomas-vlaminck",
    "name": "Thomas Vlaminck",
    "sport": "football",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Youth football technique, coaching exercises, and player development resources.",
    "website": "https://www.thomasvlaminck.com/about",
    "sources": [
      {
        "url": "https://www.thomasvlaminck.com/about",
        "title": "About Coach Thomas Vlaminck"
      },
      {
        "url": "https://www.thomasvlaminck.com/",
        "title": "Coach Thomas Vlaminck"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "essential-tennis",
    "name": "Ian Westermann · Essential Tennis",
    "sport": "tennis",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Tennis stroke progressions, match skills and instructional courses.",
    "website": "https://www.essentialtennis.com/",
    "sources": [
      {
        "url": "https://www.essentialtennis.com/about/",
        "title": "Essential Tennis · About the coaching team"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "intuitive-tennis",
    "name": "Nikola Aracic · Intuitive Tennis",
    "sport": "tennis",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Tennis technique lessons, stroke analysis and instructional courses.",
    "website": "https://www.intuitivetennis.com/",
    "youtube": "https://www.youtube.com/channel/UCtak3C1t8k3u8CVzVGYvemA",
    "sources": [
      {
        "url": "https://www.intuitivetennis.com/",
        "title": "Intuitive Tennis"
      },
      {
        "url": "https://www.youtube.com/channel/UCtak3C1t8k3u8CVzVGYvemA",
        "title": "Intuitive Tennis · Official YouTube channel"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "top-tennis-training",
    "name": "Simon Konov & Alex Slabinsky · Top Tennis Training",
    "sport": "tennis",
    "type": "academy",
    "country": "United Kingdom",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Tennis technique, footwork, tactics and structured video courses.",
    "website": "https://www.top-tennis-training.com/",
    "sources": [
      {
        "url": "https://www.top-tennis-training.com/about-us/",
        "title": "Top Tennis Training · About Simon and Alex"
      },
      {
        "url": "https://www.top-tennis-training.com/tennis-serve-masterclass-with-top-tennis-training/",
        "title": "Tennis Serve Masterclass in London"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "online-tennis-instruction",
    "name": "Online Tennis Instruction",
    "sport": "tennis",
    "type": "academy",
    "country": "Location not listed",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Stroke analysis, technical coaching programmes and tennis clinics.",
    "website": "https://www.onlinetennisinstruction.com/",
    "sources": [
      {
        "url": "https://www.onlinetennisinstruction.com/",
        "title": "Online Tennis Instruction · Coaching programmes and clinics"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "feel-tennis",
    "name": "Tomaz Mencinger · Feel Tennis",
    "sport": "tennis",
    "type": "individual",
    "country": "Slovenia",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Feel-based tennis technique, serve development and stroke courses.",
    "website": "https://www.feeltennis.net/",
    "sources": [
      {
        "url": "https://www.feeltennis.net/",
        "title": "Feel Tennis · Tomaz Mencinger"
      },
      {
        "url": "https://www.feeltennis.net/contact/",
        "title": "Feel Tennis · Contact and private lessons"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "fuzzy-yellow-balls",
    "name": "Fuzzy Yellow Balls",
    "sport": "tennis",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Tennis instructional programmes covering serves, strokes and doubles tactics.",
    "website": "https://www.fuzzyyellowballs.com/",
    "sources": [
      {
        "url": "https://www.fuzzyyellowballs.com/",
        "title": "Fuzzy Yellow Balls · Tennis Instruction"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "tennis-evolution",
    "name": "Jeff Salzenstein · Tennis Evolution",
    "sport": "tennis",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Tennis serve and stroke development through instructional programmes.",
    "website": "https://www.jeffsalzenstein.com/tennis-evolution",
    "sources": [
      {
        "url": "https://www.jeffsalzenstein.com/tennis-evolution",
        "title": "Tennis Evolution by Jeff Salzenstein"
      },
      {
        "url": "https://plus.tennisevolution.com/te-plus-sp-v2",
        "title": "Tennis Evolution · Coaching membership"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "meike-babel",
    "name": "Meike Babel",
    "sport": "tennis",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online",
      "in-person"
    ],
    "focus": "Personal tennis instruction and mental skills coaching.",
    "website": "https://www.meikebabel.com/",
    "sources": [
      {
        "url": "https://www.meikebabel.com/",
        "title": "Meike Babel · Tennis and Mental Skills Coaching"
      },
      {
        "url": "https://meikebabel.teachable.com/",
        "title": "Meike Babel Coaching School"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "total-tennis-domination",
    "name": "Kevin Garlington · Total Tennis Domination",
    "sport": "tennis",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Match tactics and stroke feedback for recreational tennis players.",
    "website": "https://totaltennisdomination.org/",
    "sources": [
      {
        "url": "https://totaltennisdomination.org/about",
        "title": "Total Tennis Domination · Meet Kevin Garlington"
      },
      {
        "url": "https://totaltennisdomination.org/one-stroke-analysis-page",
        "title": "One-Stroke Analysis"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "rick-macci",
    "name": "Rick Macci Tennis Academy",
    "sport": "tennis",
    "type": "academy",
    "country": "United States",
    "delivery": [
      "in-person"
    ],
    "focus": "Private tennis lessons and junior and adult training programmes.",
    "website": "https://rickmacci.com/",
    "sources": [
      {
        "url": "https://rickmacci.com/",
        "title": "Rick Macci Tennis Academy"
      },
      {
        "url": "https://rickmacci.com/private-lessons-with-rick/",
        "title": "Private Lessons with Rick"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "emilio-sanchez-academy",
    "name": "Emilio Sánchez Academy",
    "sport": "tennis",
    "type": "academy",
    "country": "Spain",
    "delivery": [
      "in-person"
    ],
    "focus": "Junior and adult tennis training, camps and player development.",
    "website": "https://emiliosanchezacademy.com/",
    "sources": [
      {
        "url": "https://emiliosanchezacademy.com/",
        "title": "Emilio Sánchez Academy"
      },
      {
        "url": "https://emiliosanchezacademy.com/barcelona/programs/adults",
        "title": "Adult Tennis Academy · Barcelona"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "rafa-nadal-academy",
    "name": "Rafa Nadal Academy",
    "sport": "tennis",
    "type": "academy",
    "country": "Spain",
    "delivery": [
      "in-person"
    ],
    "focus": "Junior development, adult tennis camps and individualised training programmes.",
    "website": "https://www.rafanadalacademy.com/en/",
    "sources": [
      {
        "url": "https://www.rafanadalacademy.com/en/",
        "title": "Rafa Nadal Academy · Tennis and Padel Academy"
      },
      {
        "url": "https://www.rafanadalacademy.com/en/adult-camps/tennis-camps/full-week-tennis-camps/tennis-fitness-camp-adult/",
        "title": "Weekly Tennis Camp · Rafa Nadal Academy"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "mouratoglou-academy",
    "name": "Mouratoglou Academy",
    "sport": "tennis",
    "type": "academy",
    "country": "France",
    "delivery": [
      "in-person"
    ],
    "focus": "Personalised tennis coaching and junior and adult training camps.",
    "website": "https://www.mouratoglou.com/en/academy/",
    "sources": [
      {
        "url": "https://www.mouratoglou.com/en/academy/",
        "title": "Mouratoglou Academy · Biot, France"
      },
      {
        "url": "https://www.mouratoglou.com/en/academy/methodology/",
        "title": "The Mouratoglou Coaching Methodology"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "2minute-tennis",
    "name": "Ryan Reidy · 2MinuteTennis",
    "sport": "tennis",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Virtual stroke analysis and accessible tennis technique instruction.",
    "website": "https://www.2minutetennis.net/",
    "sources": [
      {
        "url": "https://www.2minutetennis.net/",
        "title": "2MinuteTennis · Virtual Tennis Coaching"
      },
      {
        "url": "https://www.2minutetennis.net/about",
        "title": "2MinuteTennis · About Ryan Reidy"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "tennis-with-dylan",
    "name": "Dylan Gee · Tennis with Dylan",
    "sport": "tennis",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Tennis serve instruction and technical training resources.",
    "website": "https://tenniswithdylan.com/",
    "youtube": "https://www.youtube.com/channel/UCVaOxihcj9UrvyeKzpklhdQ",
    "sources": [
      {
        "url": "https://tenniswithdylan.com/",
        "title": "Tennis with Dylan · Serve Masterclass"
      },
      {
        "url": "https://www.youtube.com/channel/UCVaOxihcj9UrvyeKzpklhdQ",
        "title": "Tennis with Dylan · YouTube"
      },
      {
        "url": "https://www.middlesex.tennis/event/middlesex-tennis-coach-conference/",
        "title": "Middlesex Tennis · Coach Conference"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "tom-lodziak",
    "name": "Tom Lodziak",
    "sport": "table-tennis",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Table tennis technique, training drills and personal coaching.",
    "website": "https://www.tabletenniscoach.me.uk/",
    "youtube": "https://www.youtube.com/channel/UCqHc12tVGhzBtlMUq7MR7wA",
    "sources": [
      {
        "url": "https://www.tabletenniscoach.me.uk/",
        "title": "Tom Lodziak Table Tennis Coaching"
      },
      {
        "url": "https://www.tabletenniscoach.me.uk/coaching/",
        "title": "Tom Lodziak · Coaching Options"
      },
      {
        "url": "https://www.youtube.com/channel/UCqHc12tVGhzBtlMUq7MR7wA",
        "title": "Tom Lodziak · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "table-tennis-daily",
    "name": "TableTennisDaily · NOVI",
    "sport": "table-tennis",
    "type": "academy",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Structured table tennis lessons, drills and coaching resources.",
    "website": "https://ttnovi.com/",
    "sources": [
      {
        "url": "https://tabletennisdailyacademy.com/",
        "title": "TableTennisDaily Academy · Redirects to NOVI"
      },
      {
        "url": "https://ttnovi.com/",
        "title": "NOVI · Table Tennis Training"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "pingskills",
    "name": "Alois Rosario & Jeff Plumb · PingSkills",
    "sport": "table-tennis",
    "type": "academy",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Table tennis fundamentals, step-by-step video lessons and personalised feedback.",
    "website": "https://www.pingskills.com/",
    "sources": [
      {
        "url": "https://www.pingskills.com/",
        "title": "PingSkills · Learn To Play Table Tennis"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "tao-li-ttu",
    "name": "Tao Li · Table Tennis University",
    "sport": "table-tennis",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Progressive table tennis courses from starter skills to advanced stroke training.",
    "website": "https://tabletennisuniversity.com/",
    "sources": [
      {
        "url": "https://tabletennisuniversity.com/",
        "title": "Table Tennis University · Coach Tao Li"
      },
      {
        "url": "https://courses.tabletennisuniversity.com/p/level-1",
        "title": "Table Tennis University · Starter Skills"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "samson-dubina",
    "name": "Samson Dubina Table Tennis Academy",
    "sport": "table-tennis",
    "type": "academy",
    "country": "United States",
    "delivery": [
      "in-person",
      "video"
    ],
    "focus": "Table tennis coaching, training camps and instructional resources.",
    "website": "https://www.samsondubina.com/",
    "sources": [
      {
        "url": "https://www.samsondubina.com/",
        "title": "Samson Dubina Table Tennis Academy"
      },
      {
        "url": "https://www.samsondubina.com/coaching/coaching",
        "title": "Samson Dubina · Coaching"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "ben-larcombe",
    "name": "Ben Larcombe · Expert Table Tennis",
    "sport": "table-tennis",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Technical, tactical and mental training for developing table tennis players.",
    "website": "https://www.experttabletennis.com/",
    "sources": [
      {
        "url": "https://www.experttabletennis.com/",
        "title": "Expert Table Tennis · Ben Larcombe"
      },
      {
        "url": "https://www.experttabletennis.com/coaching/",
        "title": "Expert Table Tennis · Coaching"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "eli-baraty-ebatt",
    "name": "Eli Baraty · eBaTT",
    "sport": "table-tennis",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "in-person"
    ],
    "focus": "Individual table tennis coaching, training camps and academy development.",
    "website": "https://ebatt.co.uk/",
    "sources": [
      {
        "url": "https://ebatt.co.uk/",
        "title": "eBaTT · Table Tennis Club and Coaching in London"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "ti-long",
    "name": "Ti Long Club",
    "sport": "table-tennis",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "video"
    ],
    "focus": "Table tennis technique demonstrations and professional training videos.",
    "website": "https://www.youtube.com/channel/UCIyhoU4jcjFWkeelzga-2qA",
    "youtube": "https://www.youtube.com/channel/UCIyhoU4jcjFWkeelzga-2qA",
    "sources": [
      {
        "url": "https://www.youtube.com/channel/UCIyhoU4jcjFWkeelzga-2qA",
        "title": "Ti Long Club · Professional Table Tennis Training"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "seth-pech-pechpong",
    "name": "Seth Pech · PechPong",
    "sport": "table-tennis",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "video"
    ],
    "focus": "Table tennis training videos, technique explanations and practice guidance.",
    "website": "https://www.pechpongtt.com/",
    "sources": [
      {
        "url": "https://www.pechpongtt.com/",
        "title": "PechPong · Table Tennis"
      },
      {
        "url": "https://www.pechpongtt.com/about",
        "title": "PechPong · About Seth Pech"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "larry-hodges",
    "name": "Larry Hodges",
    "sport": "table-tennis",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Table tennis coaching articles, tactical advice and practice guidance.",
    "website": "https://www.tabletenniscoaching.com/",
    "sources": [
      {
        "url": "https://www.tabletenniscoaching.com/about",
        "title": "TableTennisCoaching.com · About Larry Hodges"
      },
      {
        "url": "https://www.larrytt.com/",
        "title": "Larry Hodges Table Tennis Page"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "badminton-insight",
    "name": "Greg & Jenny Mairs · Badminton Insight",
    "sport": "badminton",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Badminton technique, tactical drills and training weekends.",
    "website": "https://badminton-insight.com/",
    "youtube": "https://www.youtube.com/channel/UCk2gRC4RewYvvXXqXZxaTbQ",
    "sources": [
      {
        "url": "https://badminton-insight.com/about-us/",
        "title": "Badminton Insight · Greg and Jenny Mairs"
      },
      {
        "url": "https://badminton-insight.com/coaching/",
        "title": "Badminton Insight · Coaching"
      },
      {
        "url": "https://www.youtube.com/channel/UCk2gRC4RewYvvXXqXZxaTbQ",
        "title": "Badminton Insight · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "tobias-wadenka",
    "name": "Tobias Wadenka",
    "sport": "badminton",
    "type": "individual",
    "country": "Germany",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Badminton fundamentals, footwork courses and training camps.",
    "website": "https://tobiaswadenka.com/",
    "youtube": "https://www.youtube.com/@tobiaswadenka8435",
    "sources": [
      {
        "url": "https://tobiaswadenka.com/aboutme",
        "title": "Tobias Wadenka · Coaching Background"
      },
      {
        "url": "https://www.youtube.com/@tobiaswadenka8435",
        "title": "Tobias Wadenka · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "badminton-famly",
    "name": "Badminton Famly",
    "sport": "badminton",
    "type": "academy",
    "country": "Denmark",
    "delivery": [
      "online",
      "in-person",
      "video"
    ],
    "focus": "Badminton technique, tactical lessons, exercise plans and training camps.",
    "website": "https://badmintonfamly.com/",
    "email": "hello@badmintonfamly.com",
    "sources": [
      {
        "url": "https://badmintonfamly.com/",
        "title": "Badminton Famly · Coaching Videos and Camps"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "shuttle-life",
    "name": "Shuttle Life",
    "sport": "badminton",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Badminton technique courses, footwork training and match video feedback.",
    "website": "https://shuttle-life.com/",
    "sources": [
      {
        "url": "https://shuttle-life.com/",
        "title": "Shuttle Life · Badminton Coaching"
      },
      {
        "url": "https://shuttle-life.com/match-analysis",
        "title": "Shuttle Life · Personal Match Analysis"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "swift-badminton",
    "name": "Swift Badminton",
    "sport": "badminton",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Badminton footwork training through structured online lessons.",
    "website": "https://www.swiftbadminton.com/ff-open",
    "sources": [
      {
        "url": "https://www.swiftbadminton.com/ff-open",
        "title": "Swift Badminton · Footwork Fastlane"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "badminton-andy",
    "name": "Andy · Badminton Andy",
    "sport": "badminton",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online"
    ],
    "focus": "Badminton coaching explanations, practical drills and player-development resources.",
    "website": "https://badmintonandy.com/",
    "sources": [
      {
        "url": "https://badmintonandy.com/",
        "title": "Badminton Andy · Tutorials and Coaching Resources"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "lee-jae-bok",
    "name": "Lee Jae Bok · LJB Badminton",
    "sport": "badminton",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "in-person",
      "video"
    ],
    "focus": "Badminton stroke technique, footwork and structured coaching programmes.",
    "website": "https://ljb-badminton.com/programs",
    "sources": [
      {
        "url": "https://ljb-badminton.com/programs",
        "title": "LJB Badminton Club · Programmes"
      },
      {
        "url": "https://www.youtube.com/watch?v=zTVRdmeJW00",
        "title": "Coaching Badminton · Lee Jae Bok Teaching Video"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "kc-badminton-club",
    "name": "KC Badminton Club",
    "sport": "badminton",
    "type": "academy",
    "country": "Canada",
    "delivery": [
      "in-person"
    ],
    "focus": "Badminton coaching programmes for juniors and developing players.",
    "website": "https://kcbadmintonclub.com/",
    "sources": [
      {
        "url": "https://kcbadmintonclub.com/",
        "title": "KC Badminton Club · Canada"
      },
      {
        "url": "https://kcbadmintonclub.com/our-coaches/",
        "title": "KC Badminton Club · Coaching Team"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "kowi-chandra",
    "name": "Kowi Chandra · KC Badminton",
    "sport": "badminton",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "video"
    ],
    "focus": "Badminton stroke demonstrations, footwork and tactical training lessons.",
    "website": "https://www.youtube.com/channel/UCKC32CMidCkwaEMzyfA5LcQ",
    "youtube": "https://www.youtube.com/channel/UCKC32CMidCkwaEMzyfA5LcQ",
    "sources": [
      {
        "url": "https://www.youtube.com/channel/UCKC32CMidCkwaEMzyfA5LcQ",
        "title": "Kowi Chandra · KC Badminton YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "aylex-badminton",
    "name": "Aylex Badminton Academy",
    "sport": "badminton",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Badminton learning videos and structured instructional courses.",
    "website": "https://aylexbadminton.com/pages/memberships",
    "youtube": "https://www.youtube.com/channel/UCnVfEREu3C1_CV_lg3iRAog",
    "sources": [
      {
        "url": "https://aylexbadminton.com/pages/memberships",
        "title": "Aylex Badminton Academy · Courses and Membership"
      },
      {
        "url": "https://www.youtube.com/channel/UCnVfEREu3C1_CV_lg3iRAog",
        "title": "Aylex Badminton Academy · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "joshua-posthuma",
    "name": "Joshua Posthuma",
    "sport": "chess",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Chess lessons for different ages and playing levels.",
    "website": "https://lichess.org/coach/jposthuma",
    "sources": [
      {
        "url": "https://lichess.org/coach/jposthuma",
        "title": "IM Joshua Posthuma coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "koosha-jaferian",
    "name": "Koosha Jaferian",
    "sport": "chess",
    "type": "individual",
    "country": "Canada",
    "delivery": [
      "online"
    ],
    "focus": "Chess lessons and training games with analysis.",
    "website": "https://lichess.org/coach/MrKooshaJ",
    "sources": [
      {
        "url": "https://lichess.org/coach/MrKooshaJ",
        "title": "FM Koosha Jaferian coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "aakash-dalvi",
    "name": "Aakash Dalvi",
    "sport": "chess",
    "type": "individual",
    "country": "India",
    "delivery": [
      "online"
    ],
    "focus": "Individual chess training, openings and tournament preparation.",
    "website": "https://lichess.org/coach/aakash-dalvi",
    "sources": [
      {
        "url": "https://lichess.org/coach/aakash-dalvi",
        "title": "IM Aakash Sharadchandra Dalvi coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "yangfan-zhou",
    "name": "Yangfan Zhou",
    "sport": "chess",
    "type": "individual",
    "country": "China",
    "delivery": [
      "online"
    ],
    "focus": "Structured chess training with positional play and endgame study.",
    "website": "https://lichess.org/coach/yfsmurf",
    "sources": [
      {
        "url": "https://lichess.org/coach/yfsmurf",
        "title": "IM Yangfan Zhou coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "ilja-zaragatski",
    "name": "Ilja Zaragatski",
    "sport": "chess",
    "type": "individual",
    "country": "Germany",
    "delivery": [
      "online"
    ],
    "focus": "Chess strategy, decision making and independent study methods.",
    "website": "https://lichess.org/coach/carl2000",
    "sources": [
      {
        "url": "https://lichess.org/coach/carl2000",
        "title": "GM Ilja Zaragatski coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "james-coleman",
    "name": "James Coleman",
    "sport": "chess",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "online",
      "in-person"
    ],
    "focus": "Chess coaching for players of different ages and abilities.",
    "website": "https://lichess.org/coach/JamesColeman",
    "sources": [
      {
        "url": "https://lichess.org/coach/JamesColeman",
        "title": "CM James Coleman coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "valentin-baidetskyi",
    "name": "Valentin Baidetskyi",
    "sport": "chess",
    "type": "individual",
    "country": "Austria",
    "delivery": [
      "online"
    ],
    "focus": "Structured improvement for experienced junior, club and tournament chess players.",
    "website": "https://lichess.org/coach/Baidetskyi_Valentin",
    "sources": [
      {
        "url": "https://lichess.org/coach/Baidetskyi_Valentin",
        "title": "GM Valentin Baidetskyi coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "viktoria-ni",
    "name": "Viktoria Ni",
    "sport": "chess",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Chess instruction combining strategy and creative learning.",
    "website": "https://lichess.org/coach/inakiv",
    "sources": [
      {
        "url": "https://lichess.org/coach/inakiv",
        "title": "WIM Viktoria Ni coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "yeison-gutierrez",
    "name": "Yeison Gutiérrez",
    "sport": "chess",
    "type": "individual",
    "country": "Venezuela",
    "delivery": [
      "online"
    ],
    "focus": "Systematic chess improvement with English and Spanish instruction.",
    "website": "https://lichess.org/coach/yjjga",
    "sources": [
      {
        "url": "https://lichess.org/coach/yjjga",
        "title": "FM Yeison Gutiérrez coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "aleksei-sorokin",
    "name": "Aleksei Sorokin",
    "sport": "chess",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Chess instruction using a systematic approach to improvement.",
    "website": "https://lichess.org/coach/AVS2000",
    "sources": [
      {
        "url": "https://lichess.org/coach/AVS2000",
        "title": "GM Aleksei Sorokin coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "ashley-stewart",
    "name": "Ashley Stewart",
    "sport": "chess",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "online"
    ],
    "focus": "Individual chess lessons and practical playing improvement.",
    "website": "https://lichess.org/coach/aceas",
    "sources": [
      {
        "url": "https://lichess.org/coach/aceas",
        "title": "NM Ashley Stewart coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "josiah-stearman",
    "name": "Josiah Stearman",
    "sport": "chess",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Chess instruction for beginners through advanced competitive players.",
    "website": "https://lichess.org/coach/lezgo",
    "sources": [
      {
        "url": "https://lichess.org/coach/lezgo",
        "title": "IM Josiah Stearman coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "daniel-barria-zuniga",
    "name": "Daniel Barria Zuñiga",
    "sport": "chess",
    "type": "individual",
    "country": "Chile",
    "delivery": [
      "online"
    ],
    "focus": "Chess repertoire development and competition preparation.",
    "website": "https://lichess.org/coach/manitodeplomo",
    "phone": "+56 976740666",
    "sources": [
      {
        "url": "https://lichess.org/coach/manitodeplomo",
        "title": "IM Daniel Barria Zuñiga coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "derek-wu",
    "name": "Derek Wu",
    "sport": "chess",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Openings, middlegame plans, endgames and training games.",
    "website": "https://lichess.org/coach/ChessSwole",
    "sources": [
      {
        "url": "https://lichess.org/coach/ChessSwole",
        "title": "FM Derek Wu coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "pete-karagianis",
    "name": "Pete Karagianis",
    "sport": "chess",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Chess lessons, opening preparation, positional study and endgames.",
    "website": "https://lichess.org/coach/kathiyitis",
    "email": "Karagianis@gmail.com",
    "sources": [
      {
        "url": "https://lichess.org/coach/kathiyitis",
        "title": "NM Pete Karagianis coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "michael-takahashi",
    "name": "Michael Takahashi",
    "sport": "chess",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Individual tournament-player training, game analysis and learning habits.",
    "website": "https://lichess.org/coach/UncleRogerJr",
    "sources": [
      {
        "url": "https://lichess.org/coach/UncleRogerJr",
        "title": "NM Michael Takahashi coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "mackenzie-molner",
    "name": "Mackenzie Molner",
    "sport": "chess",
    "type": "individual",
    "country": "United States",
    "delivery": [
      "online"
    ],
    "focus": "Private chess lessons, group classes and video learning.",
    "website": "https://lichess.org/coach/MacMolner",
    "sources": [
      {
        "url": "https://lichess.org/coach/MacMolner",
        "title": "GM Mackenzie Molner coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "jonathan-speelman",
    "name": "Jonathan Speelman",
    "sport": "chess",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "online"
    ],
    "focus": "Chess understanding, calculation and endgame instruction.",
    "website": "https://lichess.org/coach/Jon_Speelman",
    "email": "jonathan@jspeelman.co.uk",
    "sources": [
      {
        "url": "https://lichess.org/coach/Jon_Speelman",
        "title": "GM Jonathan Speelman coaches chess students · Lichess"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "greg-mcmillan",
    "name": "Greg McMillan",
    "sport": "athletics",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online"
    ],
    "focus": "Individual running plans for new runners, race goals and experienced competitors.",
    "website": "https://www.mcmillanrunning.com/product/greg-mcmillan-coaching/",
    "youtube": "https://www.youtube.com/channel/UCPxN_M0wSx7ss7ktxeGV6Ig",
    "email": "support@McMillanRunning.com",
    "sources": [
      {
        "url": "https://www.mcmillanrunning.com/product/greg-mcmillan-coaching/",
        "title": "Greg McMillan Coaching · McMillan Running"
      },
      {
        "url": "https://www.youtube.com/channel/UCPxN_M0wSx7ss7ktxeGV6Ig",
        "title": "McMillan Running · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "jason-fitzgerald",
    "name": "Jason Fitzgerald · Strength Running",
    "sport": "athletics",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online"
    ],
    "focus": "Distance-running training, strength routines and running education.",
    "website": "https://strengthrunning.com/coaching/",
    "sources": [
      {
        "url": "https://strengthrunning.com/coaching/",
        "title": "Coaching · Strength Running"
      },
      {
        "url": "https://strengthrunning.com/about/",
        "title": "About Jason Fitzgerald · Strength Running"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "sage-canaday",
    "name": "Sage Canaday",
    "sport": "athletics",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Road, marathon, mountain and ultra running training.",
    "website": "https://higherrunning.com/the-team/coach-sage-canaday/",
    "youtube": "https://www.youtube.com/channel/UC32z512BnUYYwouJ6IpuMuA",
    "sources": [
      {
        "url": "https://higherrunning.com/the-team/coach-sage-canaday/",
        "title": "Coach Sage Canaday · Higher Running"
      },
      {
        "url": "https://www.youtube.com/channel/UC32z512BnUYYwouJ6IpuMuA",
        "title": "Higher Running · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "sandi-nypaver",
    "name": "Sandi Nypaver",
    "sport": "athletics",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Marathon and trail-running coaching with structured training plans.",
    "website": "https://higherrunning.com/the-team/coach-sandi-nypaver/",
    "youtube": "https://www.youtube.com/channel/UC32z512BnUYYwouJ6IpuMuA",
    "sources": [
      {
        "url": "https://higherrunning.com/the-team/coach-sandi-nypaver/",
        "title": "Coach Sandi Nypaver · Higher Running"
      },
      {
        "url": "https://www.youtube.com/channel/UC32z512BnUYYwouJ6IpuMuA",
        "title": "Higher Running · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "amanda-brooks",
    "name": "Amanda Brooks · Run To The Finish",
    "sport": "athletics",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online"
    ],
    "focus": "Personal running coaching and plans tailored to individual goals.",
    "website": "https://runtothefinish.com/online-running-coach/",
    "sources": [
      {
        "url": "https://runtothefinish.com/online-running-coach/",
        "title": "Online Running Coach · Run To The Finish"
      },
      {
        "url": "https://runtothefinish.com/about-amanda-brooks/",
        "title": "About Amanda Brooks · Run To The Finish"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "lisa-dobriskey",
    "name": "Lisa Dobriskey",
    "sport": "athletics",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online"
    ],
    "focus": "Personal running coaching and training plans through RunDoyen.",
    "website": "https://www.rundoyen.com/running-coaches/lisa-dobriskey/",
    "sources": [
      {
        "url": "https://www.rundoyen.com/running-coaches/lisa-dobriskey/",
        "title": "Coach Lisa Dobriskey · RunDoyen"
      },
      {
        "url": "https://www.rundoyen.com/shop/personal-coaching/personal-coaching-with-lisa-dobriskey/",
        "title": "Personal Coaching with Lisa Dobriskey · RunDoyen"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "the-run-experience",
    "name": "The Run Experience",
    "sport": "athletics",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Guided running workouts, technique videos and progressive training programmes.",
    "website": "https://therunexperience.com/",
    "youtube": "https://www.youtube.com/channel/UCjGZ6D8hJFvLur5K_p9vKAA",
    "email": "support@ongo.app",
    "sources": [
      {
        "url": "https://therunexperience.com/",
        "title": "The Run Experience"
      },
      {
        "url": "https://www.youtube.com/channel/UCjGZ6D8hJFvLur5K_p9vKAA",
        "title": "The Run Experience · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "chris-twiggs",
    "name": "Chris Twiggs · Galloway Coaching",
    "sport": "athletics",
    "type": "individual",
    "country": "Location not listed",
    "delivery": [
      "online"
    ],
    "focus": "Custom running plans using the Run-Walk-Run method.",
    "website": "https://www.jeffgalloway.com/galloway-coaching/",
    "sources": [
      {
        "url": "https://www.jeffgalloway.com/galloway-coaching/",
        "title": "Galloway Customized Training · Coaching with Chris Twiggs"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "hal-higdon-programmes",
    "name": "Hal Higdon Training",
    "sport": "athletics",
    "type": "creator",
    "country": "Location not listed",
    "delivery": [
      "online",
      "video"
    ],
    "focus": "Running plans for beginners, 5K, 10K, half marathon and marathon distances.",
    "website": "https://www.halhigdon.com/",
    "youtube": "https://www.youtube.com/channel/UCEdweySTUt5U9qmi9Fu9qVQ",
    "sources": [
      {
        "url": "https://www.halhigdon.com/",
        "title": "Hal Higdon · Training Programs"
      },
      {
        "url": "https://www.youtube.com/channel/UCEdweySTUt5U9qmi9Fu9qVQ",
        "title": "Run With Hal · YouTube"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "ben-parkes",
    "name": "Ben Parkes Running",
    "sport": "athletics",
    "type": "creator",
    "country": "United Kingdom",
    "delivery": [
      "online"
    ],
    "focus": "Running training plans spanning 5K to ultra distances.",
    "website": "https://benparkes.com/collections/training-plans",
    "sources": [
      {
        "url": "https://benparkes.com/collections/training-plans",
        "title": "Parkes Running Training Plans · Ben Parkes Running"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "james-dunne",
    "name": "James Dunne · Kinetic Revolution",
    "sport": "athletics",
    "type": "individual",
    "country": "United Kingdom",
    "delivery": [
      "online"
    ],
    "focus": "Running technique, strength and training education for distance runners.",
    "website": "https://kinetic-revolution.com/about-me",
    "sources": [
      {
        "url": "https://kinetic-revolution.com/about-me",
        "title": "About James Dunne · Kinetic Revolution"
      },
      {
        "url": "https://kinetic-revolution.com/get-started",
        "title": "Free Running Resources · Kinetic Revolution"
      }
    ],
    "checkedAt": "2026-11-21"
  },
  {
    "id": "runna-coaching",
    "name": "Runna Coaching",
    "sport": "athletics",
    "type": "academy",
    "country": "Location not listed",
    "delivery": [
      "online"
    ],
    "focus": "Personalised running plans supported by a team of running coaches.",
    "website": "https://www.runna.com/coaches",
    "sources": [
      {
        "url": "https://www.runna.com/coaches",
        "title": "Our Coaches · Runna"
      },
      {
        "url": "https://www.runna.com/training/training-plans",
        "title": "Personalized training plans for runners · Runna"
      }
    ],
    "checkedAt": "2026-11-21"
  }
];
