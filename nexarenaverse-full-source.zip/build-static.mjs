import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const releaseHash=createHash('sha256');
for(const name of fs.readdirSync('.').sort()) if(fs.statSync(name).isFile() && /\.(?:js|css|html)$/.test(name)) releaseHash.update(fs.readFileSync(name));
const release=releaseHash.digest('hex').slice(0,12);
function versionAssets(text) {
  return text.replace(/(["'])(\.{0,2}\/[a-zA-Z0-9_./-]+\.(?:js|css))\1/g,(_,quote,asset)=>quote+asset+'?v='+release+quote);
}
const origin = 'https://nexarenaverse.github.io';
const output = '_site';
fs.rmSync(output, {recursive: true, force: true});
fs.mkdirSync(output);
for (const name of fs.readdirSync('.')) {
  if (name === 'build-static.mjs' || name === 'account-connect.html' || name === 'sitemap.xml' || name === 'robots.txt') continue;
  if (fs.statSync(name).isFile() && /\.(?:js|css|html|svg|webmanifest|txt)$/.test(name)) fs.writeFileSync(path.join(output,name), versionAssets(fs.readFileSync(name,'utf8')));
}
const routes = JSON.parse(fs.readFileSync('routes.json', 'utf8'));
const source = fs.readFileSync('index.html', 'utf8');
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
for (const [route, title, description] of routes) {
  const dir = path.join(output, route);
  fs.mkdirSync(dir, {recursive: true});
  const canonical = origin + (route === '/' ? '/' : route + '/');
  const metadata = '<meta name="description" content="'+escape(description)+'"><link rel="canonical" href="'+canonical+'"><meta property="og:title" content="'+escape(title)+'"><meta property="og:description" content="'+escape(description)+'"><meta property="og:url" content="'+canonical+'"><meta property="og:image" content="'+origin+'/brand.svg"><meta property="og:site_name" content="NexArenaverse">';
  const pageSource = /^\/(?:plus|coaches|advertise|account|owner|purchase-complete)$/.test(route) ? fs.readFileSync('market.html','utf8') : source;
  let html = pageSource.replace(/<title>[^<]*<\/title>/, '<title>'+escape(title)+'</title>').replace('<meta charset="utf-8">','<meta charset="utf-8">'+metadata).replace(/<meta name="google-site-verification"[^>]*>/, '<meta name="google-site-verification" content="gtryvxWUvbZqFB3-2chAlFHBjTuTdC_djnxDtd_V4Gg">');
  html = html.replace('<main id="app"></main>', '<main id="app"><section><h1>'+escape(title)+'</h1><p>'+escape(description)+'</p><nav aria-label="Explore"><a href="/">Games</a> <a href="/education/">Education Centre</a> <a href="/kids/">Children’s games</a> <a href="/sports/">Sports Academy</a></nav></section></main>');
  if(['/account','/owner','/purchase-complete'].includes(route)) html=html.replace('</head>','<meta name="robots" content="noindex"></head>');
  fs.writeFileSync(path.join(dir, 'index.html'), versionAssets(html));
}
fs.mkdirSync(path.join(output,'account-return'),{recursive:true});
fs.writeFileSync(path.join(output,'account-return/index.html'),versionAssets(fs.readFileSync('account-return.html','utf8')));
fs.writeFileSync(path.join(output,'404.html'),fs.readFileSync(path.join(output,'index.html'),'utf8'));
fs.writeFileSync(path.join(output,'robots.txt'),'User-agent: *\nAllow: /\nDisallow: /account-return/\nSitemap: '+origin+'/sitemap.xml\n');
fs.writeFileSync(path.join(output,'sitemap.xml'),'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+routes.map(([route])=>'<url><loc>'+origin+(route==='/'?'/':route+'/')+'</loc></url>').join('')+'</urlset>');
fs.writeFileSync(path.join(output,'.nojekyll'),'');
console.log('Built '+routes.length+' complete game and learning pages for GitHub Pages.');
