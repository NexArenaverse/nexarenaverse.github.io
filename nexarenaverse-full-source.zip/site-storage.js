// Invalid or unavailable browser storage must not stop a game from opening.
const sessionValues = new Map();
export function readJSON(key, fallback) {
 try {
  const raw = sessionValues.has(key) ? sessionValues.get(key) : localStorage.getItem(key);
  if (raw === null || raw === undefined) return fallback;
  const value = JSON.parse(raw);
  if (value === null) return fallback;
  if (Array.isArray(fallback)) return Array.isArray(value) ? value : fallback;
  if (fallback && typeof fallback === 'object') return typeof value === 'object' && !Array.isArray(value) ? value : fallback;
  if (fallback !== null && fallback !== undefined && typeof value !== typeof fallback) return fallback;
  return value;
 } catch { return fallback; }
}
export function writeJSON(key, value) {
 const raw = JSON.stringify(value);
 try { localStorage.setItem(key, raw); sessionValues.delete(key); return true; }
 catch { sessionValues.set(key, raw); return false; }
}
