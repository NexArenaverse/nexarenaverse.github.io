// Opt-in cache. Never store private APIs, account pages, payments or third-party media.
const PRACTICE_CACHE='nexa-practice-2026-11-21-v2';
const practicePages=['/plus/coach/','/plus/designs/','/plus/challenges/','/plus/adventures/','/plus/data-saver/'];
const practiceAssets=['/market.js','/market.css','/premium.css','/premium-labs.css','/premium-labs.js','/premium-lab-data.js','/coach-review-worker.js','/chess.js','/chess-engine.js','/service.js','/market-world-data.js','/market-demo.js','/market-forms.js','/market-worlds.js','/coach-directory.js','/coaching-providers.js','/data-saver.js','/logo.svg','/manifest.webmanifest'];
const isPractice=url=>practicePages.includes(url.pathname);
const assetPaths=practiceAssets.map(path=>new URL(path,self.location.origin).pathname);
const isAsset=url=>assetPaths.includes(url.pathname);
self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith('nexa-practice-')&&key!==PRACTICE_CACHE)await caches.delete(key);await self.clients.claim();})()));
self.addEventListener('message',event=>{if(event.data?.type!=='SAVE_PRACTICE')return;event.waitUntil((async()=>{try{const cache=await caches.open(PRACTICE_CACHE),urls=[...practicePages,...practiceAssets];for(const path of urls){const response=await fetch(path,{cache:'reload',credentials:'omit'});if(!response.ok)throw Error('A practice page could not be downloaded. Reconnect and try again.');await cache.put(new URL(path,self.location.origin).pathname,response);}event.ports[0]?.postMessage({ok:true});}catch(error){event.ports[0]?.postMessage({ok:false,error:error.message});}})());});
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin||(!isPractice(url)&&!isAsset(url)))return;event.respondWith((async()=>{const cache=await caches.open(PRACTICE_CACHE),cached=await cache.match(url.pathname);if(isAsset(url)&&cached)return cached;try{const response=await fetch(event.request);return response;}catch(error){if(cached)return cached;throw error;}})());});
