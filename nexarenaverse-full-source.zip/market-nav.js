import {serviceFetch} from './service.js';
import {realmNames,realmThemes} from './realms-data.js';
let themes=null;
let queued=false;
function decorateMarket(){
  const header=document.querySelector('header');
  if(header&&!document.querySelector('#arena-plus-link')){
    const link=document.createElement('a');link.id='arena-plus-link';link.href='/plus/';link.textContent='✦ Arena Plus & Coaches';link.className='arena-plus-link';header.append(link);
  }
  if(!themes)return;
  for(const select of document.querySelectorAll('#lobby-theme,#style,#studio-theme')){
    for(const name of Object.keys(themes))if(![...select.options].some(o=>o.value===name)){const option=document.createElement('option');option.value=name;option.textContent=name+' · Prism';select.append(option);}
  }
}
const style=document.createElement('style');
style.textContent='.arena-plus-link{display:inline-flex;align-items:center;justify-content:center;padding:11px 15px;border:1px solid #aa93ec!important;border-radius:12px;background:linear-gradient(135deg,#254550,#423052)!important;color:#e9fffa!important;text-decoration:none;font:750 12px system-ui;white-space:nowrap}.arena-ad-strip{max-width:1180px;margin:18px auto;padding:12px 20px;display:flex;gap:16px;flex-wrap:wrap;background:#142338;border:1px solid #4e668b;border-radius:12px;font:13px system-ui;color:#b4c5da}.arena-ad-strip a{color:#91f4dd}.arena-ad-strip small{font-size:10px;letter-spacing:1px}body[data-realm=Aurora] .real-board .sq.light{background:#cafde5!important}body[data-realm=Aurora] .real-board .sq.dark{background:#284970!important}body[data-realm=Obsidian] .real-board .sq.light{background:#c9bbdd!important}body[data-realm=Obsidian] .real-board .sq.dark{background:#211f35!important}body[data-realm=Solstice] .real-board .sq.light{background:#ffe5a9!important}body[data-realm=Solstice] .real-board .sq.dark{background:#593b62!important}body[data-realm=Aurora] .studio-board,body[data-realm=Obsidian] .studio-board,body[data-realm=Solstice] .studio-board{box-shadow:0 0 0 2px #9e86dd,0 18px 55px #0009}';
document.head.append(style);
decorateMarket();
new MutationObserver(()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;decorateMarket();});}).observe(document.body,{childList:true,subtree:true});
async function loadDesigns(){
  try{const response=await serviceFetch('/api/market/pack');if(!response.ok)return;themes=(await response.json()).themes;
    Object.assign(realmThemes,themes);for(const name of Object.keys(themes))if(!realmNames.includes(name))realmNames.push(name);
    decorateMarket();window.dispatchEvent(new CustomEvent('ma-realm-changed',{detail:'Prism'}));
  }catch{}
}
loadDesigns();
window.addEventListener('storage',e=>{if(e.key==='na-account-session')location.reload();});
if(!/^\/kids(?:\/|$)/.test(location.pathname)){
  serviceFetch('/api/market/ads').then(async response=>{if(!response.ok)return;const data=await response.json();if(!data.ads.length)return;const strip=document.createElement('aside');strip.className='arena-ad-strip';strip.setAttribute('aria-label','Advertisements');const label=document.createElement('small');label.textContent='ADVERTISEMENT';strip.append(label);for(const ad of data.ads){const link=document.createElement('a');link.href=ad.url;link.textContent=ad.brand;link.target='_blank';link.rel='sponsored noopener noreferrer';strip.append(link);}document.querySelector('main')?.after(strip);}).catch(()=>{});
}
