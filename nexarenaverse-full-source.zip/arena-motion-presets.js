// One catalogue drives selection, saved preferences and real entrance frames.
export const motionStyles = [
 ['zoom','Zoom','Big camera push. Bold text.','Cinematic zoom entrance'],
 ['slide','Slide','Fast movement. Clean landing.','Slide entrance'],
 ['prism','Prism Wipe','A sharp reveal across the scene.','Prism wipe entrance'],
 ['soft','Soft','A quieter, gentle arrival.','Soft entrance'],
 ['bounce','Bounce','Pop in and land with a bounce.','Bounce entrance'],
 ['rise','Fly Up','Lift into view from below.','Fly up entrance'],
 ['drop','Drop In','Descend, then settle into place.','Drop in entrance'],
 ['spin','Spin','A quick twist into the spotlight.','Spin entrance'],
 ['flip','Flip','Turn into view in three dimensions.','Flip entrance'],
 ['curtain','Curtain','Open the scene from its centre.','Curtain entrance'],
 ['iris','Iris','Expand a circular spotlight.','Iris entrance'],
 ['diamond','Diamond','Unfold a geometric reveal.','Diamond entrance'],
 ['stretch','Stretch','Grow wide with an elastic finish.','Stretch entrance'],
 ['swing','Swing','Swing down, then find your balance.','Swing entrance']
];
export const motionStyleIds = motionStyles.map(([id])=>id);
export function entranceFrames(id, {card=false,direction=-1}={}) {
 const settled={opacity:1,transform:'none'};
 switch(id) {
  case 'zoom': return [{opacity:0,transform:`translateY(32px) scale(${card ? .87 : .78})`,offset:0},{opacity:1,transform:'translateY(-3px) scale(1.025)',offset:.76},{...settled,offset:1}];
  case 'slide': return [{opacity:0,transform:`translateX(${card?direction*55:-100}px) skewX(-3deg)`},{opacity:1,transform:'translateX(5px) skewX(0)',offset:.8},settled];
  case 'prism': return [{opacity:.1,clipPath:'inset(0 100% 0 0)',transform:'translateX(-24px)'},{...settled,clipPath:'inset(0 0 0 0)'}];
  case 'bounce': return [{opacity:0,transform:'translateY(58px) scale(.7)'},{opacity:1,transform:'translateY(-12px) scale(1.035)',offset:.65},{opacity:1,transform:'translateY(4px) scale(.99)',offset:.84},settled];
  case 'rise': return [{opacity:0,transform:`translateY(${card?60:110}px)`},settled];
  case 'drop': return [{opacity:0,transform:`translateY(${card?-55:-100}px) scale(.95)`},{opacity:1,transform:'translateY(6px) scale(1)',offset:.8},settled];
  case 'spin': return [{opacity:0,transform:`rotate(${card?-18:-120}deg) scale(.65)`},{opacity:1,transform:'rotate(3deg) scale(1.01)',offset:.82},settled];
  case 'flip': return [{opacity:0,transform:`perspective(900px) rotateY(${card?45:70}deg) scale(.9)`},settled];
  case 'curtain': return [{opacity:1,clipPath:'inset(0 50% 0 50%)'},{opacity:1,clipPath:'inset(0 0% 0 0%)'}];
  case 'iris': return [{opacity:1,clipPath:'circle(0% at 50% 50%)'},{opacity:1,clipPath:'circle(100% at 50% 50%)'}];
  case 'diamond': return [{opacity:1,clipPath:'polygon(50% 50%,50% 50%,50% 50%,50% 50%)'},{opacity:1,clipPath:'polygon(50% -50%,150% 50%,50% 150%,-50% 50%)'}];
  case 'stretch': return [{opacity:0,transform:'scaleX(.2) scaleY(.85)'},{opacity:1,transform:'scaleX(1.04) scaleY(1)',offset:.8},settled];
  case 'swing': return [{opacity:0,transform:'rotate(-14deg) translateY(-24px)',transformOrigin:'50% 0%'},{opacity:1,transform:'rotate(2deg)',transformOrigin:'50% 0%',offset:.8},{...settled,transformOrigin:'50% 0%'}];
  default: return [{opacity:.25,transform:'translateY(22px)'},settled];
 }
}
