import {accountDestination, githubHosted} from './service.js';

const params = new URLSearchParams(location.hash.slice(1));
history.replaceState(null, '', '/account-return/');
const title = document.querySelector('#title');
const message = document.querySelector('#message');
const link = document.querySelector('#return-link');
let pending;
try { pending = JSON.parse(localStorage.getItem('na-account-pending') || 'null'); } catch {}
const session = params.get('session') || '';
if (githubHosted && pending?.expires > Date.now() && pending.state === params.get('state') && /^\d{13}\.[a-f0-9]{64}$/.test(session)) {
  const destination = accountDestination(pending.returnTo);
  try {
    localStorage.setItem('na-account-session', session);
    localStorage.removeItem('na-account-pending');
    if (pending.sameTab) location.replace(destination);
    title.textContent = 'You’re signed in';
    message.textContent = 'You can now open your NexArenaverse account or return to your game.';
    link.href = destination;
    link.textContent = 'Continue to NexArenaverse →';
    if (!pending.sameTab) {
      const close = document.querySelector('#close-window');
      close.hidden = false;
      close.onclick = () => window.close();
    }
  } catch {
    title.textContent = 'Your browser could not save this sign-in';
    message.textContent = 'Allow site data in your browser, then try again.';
  }
} else {
  title.textContent = 'This sign-in link has expired';
  message.textContent = 'Start again from the NexArenaverse sign-in page.';
}
