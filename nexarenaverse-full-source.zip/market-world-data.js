export const prices = {NGN: 150000, USD: 200, GBP: 150};
export const sports = ['football', 'basketball', 'tennis', 'table-tennis', 'badminton', 'athletics', 'chess'];
export const worlds = {
  premium: {
    name: 'Arena Plus', path: '/plus/membership/', accent: 'mint', label: 'Practice & progress',
    heading: 'Arena Plus', summary: 'Keep your practice progress, training plans and goals together as you play across the arena.',
    period: '30 days', action: 'Get Arena Plus', demo: 'Your sample 30-day membership is ready. Preview your first practice mission.',
    highlights: [
      ['Cloud saves', 'Save supported practice progress and restore it on another device.'],
      ['Practice missions', 'Work through goals for tactics, learning and sports skills.'],
      ['Progress summary', 'See your recorded practice wins and completed goals in My account.']
    ]
  },
  group: {
    name: 'Family & School Circle', path: '/plus/circle/', accent: 'blue', label: 'Private groups',
    heading: 'Family & School Circle', summary: 'Invite family, friends or classmates to share Arena Plus in a private five-person group.',
    period: '30 days · five seats', action: 'Get a Circle pass', demo: 'Your sample Circle has one organiser seat and four seats ready for invitations.',
    highlights: [
      ['Set up your Circle', 'Give your group a name and manage membership from My account.'],
      ['Invite four people', 'Share your private invite code with the people you want to join.'],
      ['Practice together', 'Every active member gets Arena Plus during the 30-day pass.']
    ]
  },
  design: {
    name: 'Prism Design Pack', path: '/plus/designs/', accent: 'violet', label: 'Boards & pieces',
    heading: 'Prism Design Studio', summary: 'Preview three sets of colours for your boards, pieces and arena background.',
    period: 'One-time purchase', action: 'Get the Prism Design Pack', demo: 'Your sample pack is ready. Try Aurora, Obsidian and Solstice on the preview board.',
    highlights: [
      ['Aurora', 'Cool mint squares with a blue-green frame and a deep blue background.'],
      ['Obsidian', 'Lavender highlights, dark violet squares and a shaded background.'],
      ['Solstice', 'Warm amber pieces, rich plum squares and a sunset backdrop.']
    ]
  },
  coaching: {
    name: 'Coach lesson', path: '/coaches/', accent: 'amber', label: 'Live lessons',
    heading: 'Coach Centre', summary: 'Find sports and chess coaches, explore public directories or apply to teach on NexArenaverse.',
    period: 'Per booked lesson', action: 'Browse coaches', demo: 'Your sample lesson appears below. It does not reserve a real time or send an invitation.'
  },
  advertising: {
    name: 'Advertising campaign', path: '/advertise/', accent: 'pink', label: 'Brand partnerships',
    heading: 'Advertising Studio', summary: 'Tell us what you want to promote and where you want it to appear. The owner reviews every campaign and sets its price.',
    period: 'Owner-set quote', action: 'Request a quote', demo: 'Your sample quote is marked paid in the demo. Live ads require owner review and verified payment.'
  }
};

export const directories = [
  {name:'Alliance Academy Nigeria', sports:['basketball','football'], region:'Ikeja, Lagos · training academy', url:'https://allianceacademynigeria.com/', detail:'Explore basketball and football training in Ikeja and contact the academy through its website.'},
  {name:'Paddysco Sports Academy', sports:['football'], region:'Nigeria · training academy', url:'https://paddyscosportsng.com/', detail:'Explore football development programmes and contact the academy about training.'},
  {name:'Lichess Coaches', sports:['chess'], region:'Worldwide · online', url:'https://lichess.org/coach', detail:'Browse chess coaches by language, rating and lesson availability.'},
  {name:'Chess.com Coaches', sports:['chess'], region:'Worldwide · online', url:'https://www.chess.com/coaches', detail:'Compare chess teachers and open their profiles to discuss lessons.'},
  {name:'LTA Coach Finder', sports:['tennis'], region:'Great Britain', url:'https://www.lta.org.uk/play/find-a-coach/', detail:'Find accredited tennis coaches by postcode or venue.'},
  {name:'USTA Coach Directory', sports:['tennis'], region:'United States', url:'https://www.usta.com/en/home/play/coach-search.html', detail:'Use USTA’s public directory to look up tennis coaches.'},
  {name:'England Football Find Football', sports:['football'], region:'England', url:'https://find.englandfootball.com/', detail:'Find clubs and organised football sessions near you.'},
  {name:'UK Athletics Find a Coach', sports:['athletics'], region:'United Kingdom', url:'https://find-a-coach.myathletics.uk/', detail:'Search for licensed athletics coaches by discipline and location.'},
  {name:'Badminton England Coaching', sports:['badminton'], region:'England', url:'https://www.badmintonengland.co.uk/coaches/', detail:'Explore coach resources and links to local badminton opportunities.'},
  {name:'Table Tennis England Table Finder', sports:['table-tennis'], region:'England', url:'https://www.tabletennisengland.co.uk/table-finder/', detail:'Find table tennis clubs and venues and contact them about coaching.'},
  {name:'Basketball England Club Finder', sports:['basketball'], region:'England', url:'https://basketballengland.co.uk/get-involved/clubs/find-a-club', detail:'Look up nearby basketball clubs and contact them about training.'}
];

export const designPreviews = {
  Aurora: {light:'#edfff3',dark:'#24334e',edge:'#67ccb9', backdrop:'#183941'},
  Obsidian: {light:'#f9edff',dark:'#292137',edge:'#a88acc', backdrop:'#352a47'},
  Solstice: {light:'#fff3d3',dark:'#3d294b',edge:'#ce8d63', backdrop:'#54344a'}
};

export const paymentMethods = {
  card: 'Card', bank_transfer: 'Bank transfer', ussd: 'USSD'
};
