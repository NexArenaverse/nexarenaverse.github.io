// The game interface can live on GitHub Pages while the existing match service
// remains on its current host. Never send browser cookies across origins.
export const githubHosted = location.hostname === 'nexarenaverse.github.io';
export const serviceOrigin = githubHosted ? 'https://nexarenaverse.ojulari-ls.chatgpt.site' : location.origin;
let transientPlayerToken;
export function serviceFetch(path, options = {}) {
  if (!/^\/api\/(?:rooms|lounge|rankings|sports|market)(?:[/?]|$)/.test(path)) throw Error('Unknown game service.');
  const headers = new Headers(options.headers);
  if (githubHosted) {
    let session; try { session = localStorage.getItem('na-account-session'); } catch {}
    if (session) headers.set('x-arena-account', session);
  }
  const {timeoutMs = 12000, signal: parentSignal, ...requestOptions} = options;
  const controller = new AbortController();
  let timedOut = false;
  const abort = () => controller.abort(parentSignal?.reason);
  if (parentSignal?.aborted) abort(); else parentSignal?.addEventListener('abort', abort, {once:true});
  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, Math.max(100,Math.min(Number(timeoutMs)||12000,45000)));
  const cleanup = () => { clearTimeout(timer); parentSignal?.removeEventListener('abort',abort); };
  return fetch(serviceOrigin + path, {...requestOptions, headers, signal:controller.signal, credentials: githubHosted ? 'omit' : 'same-origin'})
   .catch(error => { if (timedOut) throw Error('The connection took too long. Check your internet connection and try again.'); throw error; })
   .finally(cleanup);
}
export function playerToken() {
  let token; try { token = localStorage.getItem('ma-player-session'); } catch {}
  if (!token && transientPlayerToken) return transientPlayerToken;
  if (!/^[a-f0-9]{64}$/.test(token || '')) {
    token = [...crypto.getRandomValues(new Uint8Array(32))].map(x => x.toString(16).padStart(2,'0')).join('');
    try { localStorage.setItem('ma-player-session', token); } catch { transientPlayerToken = token; }
  }
  return token;
}
export function accountDestination(path) {
  if (typeof path !== 'string' || !path.startsWith('/') || path.startsWith('//') || path.includes('\\')) return '/account/';
  const destination = new URL(path, location.origin);
  const allowed = /^\/(?:account|plus|coaches|advertise|purchase-complete|owner|sports|sport|game|kids|education)(?:\/|$)/;
  return destination.origin === location.origin && (destination.pathname === '/' || allowed.test(destination.pathname))
    ? destination.pathname + destination.search + destination.hash : '/account/';
}
export function connectAccount(playerToken, {sameTab = false, returnTo = '/account/'} = {}) {
  const state = [...crypto.getRandomValues(new Uint8Array(24))].map(x => x.toString(16).padStart(2, '0')).join('');
  localStorage.setItem('na-account-pending', JSON.stringify({state, expires: Date.now() + 600000, returnTo:accountDestination(returnTo), sameTab}));
  const url = serviceOrigin + '/account-connect#' + new URLSearchParams({state, device: playerToken});
  if (sameTab) {
    location.assign(url);
    return true;
  }
  const popup = window.open(url, 'nexarenaverse-account', 'width=560,height=720');
  if (!popup) {
    localStorage.removeItem('na-account-pending');
    return false;
  }
  return true;
}
export async function disconnectAccount() {
  try { await serviceFetch('/api/rankings/github-signout', {method: 'POST'}); }
  finally { localStorage.removeItem('na-account-session'); localStorage.removeItem('na-account-pending'); }
}
