// The game interface can live on GitHub Pages while the existing match service
// remains on its current host. Never send browser cookies across origins.
export const githubHosted = location.hostname === 'nexarenaverse.github.io';
export const serviceOrigin = githubHosted ? 'https://nexarenaverse.ojulari-ls.chatgpt.site' : location.origin;
export function serviceFetch(path, options = {}) {
  if (!/^\/api\/(?:rooms|lounge|rankings|sports)(?:[/?]|$)/.test(path)) throw Error('Unknown game service.');
  const headers = new Headers(options.headers);
  if (githubHosted) {
    const session = localStorage.getItem('na-account-session');
    if (session) headers.set('x-arena-account', session);
  }
  return fetch(serviceOrigin + path, {...options, headers, credentials: githubHosted ? 'omit' : 'same-origin'});
}
export function connectAccount(playerToken) {
  const state = [...crypto.getRandomValues(new Uint8Array(24))].map(x => x.toString(16).padStart(2, '0')).join('');
  localStorage.setItem('na-account-pending', JSON.stringify({state, expires: Date.now() + 600000}));
  const url = serviceOrigin + '/account-connect#' + new URLSearchParams({state, device: playerToken});
  const popup = window.open(url, 'nexarenaverse-account', 'width=560,height=720');
  if (!popup) {
    localStorage.removeItem('na-account-pending');
    return false;
  }
  return true;
}
export async function disconnectAccount() {
  try { await serviceFetch('/api/rankings/github-signout', {method: 'POST'}); }
  finally { localStorage.removeItem('na-account-session'); localStorage.removeItem('na-account-pending'); }
}
