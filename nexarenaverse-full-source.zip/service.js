// The game interface can live on GitHub Pages while the existing match service
// remains on its current host. Never send browser cookies across origins.
export const githubHosted = location.hostname === 'nexarenaverse.github.io';
export const serviceOrigin = githubHosted ? 'https://nexarenaverse.ojulari-ls.chatgpt.site' : location.origin;
export function serviceFetch(path, options = {}) {
  if (!/^\/api\/(?:rooms|lounge|rankings|sports|market)(?:[/?]|$)/.test(path)) throw Error('Unknown game service.');
  const headers = new Headers(options.headers);
  if (githubHosted) {
    const session = localStorage.getItem('na-account-session');
    if (session) headers.set('x-arena-account', session);
  }
  return fetch(serviceOrigin + path, {...options, headers, credentials: githubHosted ? 'omit' : 'same-origin'});
}
export function playerToken() {
  let token = localStorage.getItem('ma-player-session');
  if (!/^[a-f0-9]{64}$/.test(token || '')) {
    token = [...crypto.getRandomValues(new Uint8Array(32))].map(x => x.toString(16).padStart(2,'0')).join('');
    localStorage.setItem('ma-player-session', token);
  }
  return token;
}
export function accountDestination(path) {
  if (typeof path !== 'string' || !path.startsWith('/') || path.startsWith('//') || path.includes('\\')) return '/account/';
  const destination = new URL(path, location.origin);
  const allowed = /^\/(?:account|plus|coaches|advertise|purchase-complete|owner|sports|sport|game|kids|education)(?:\/|$)/;
  return destination.origin === location.origin && (destination.pathname === '/' || allowed.test(destination.pathname))
    ? destination.pathname + destination.search + destination.hash : '/account/';
}
export function connectAccount(playerToken, {sameTab = false, returnTo = '/account/'} = {}) {
  const state = [...crypto.getRandomValues(new Uint8Array(24))].map(x => x.toString(16).padStart(2, '0')).join('');
  localStorage.setItem('na-account-pending', JSON.stringify({state, expires: Date.now() + 600000, returnTo:accountDestination(returnTo), sameTab}));
  const url = serviceOrigin + '/account-connect#' + new URLSearchParams({state, device: playerToken});
  if (sameTab) {
    location.assign(url);
    return true;
  }
  const popup = window.open(url, 'nexarenaverse-account', 'width=560,height=720');
  if (!popup) {
    localStorage.removeItem('na-account-pending');
    return false;
  }
  return true;
}
export async function disconnectAccount() {
  try { await serviceFetch('/api/rankings/github-signout', {method: 'POST'}); }
  finally { localStorage.removeItem('na-account-session'); localStorage.removeItem('na-account-pending'); }
}
